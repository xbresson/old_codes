
Xavier Bresson - June 25 2009


A Short Note for Nonlocal TV Minimization

Read: X. Bresson, A Short Note for Nonlocal TV Minimization
and X. Zhang, M. Burger, X. Bresson, and S. Osher, Bregmanized Nonlocal Regularization for Deconvolution and Sparse Reconstruction, CAM Report 09-03, 2009



How to use this code ?

Open Matlab and compile the mex functions by running:
mex compute_fastNLWeights_mex.c
mex SBNLTV_mex.c
Then run test_nonlocalTV




