
function [clusters,cuts,cheegers] = CheegerTVClustering_comparison(W,criterion,k,numOuter,numInner,uinit,verbosity)
% based on 1-Spectral Clustering of M. Hein and T. B�hler


    if(nargin<7)
        verbosity=2;
    end
    if (nargin< 5)
        numOuter=0;
        numInner=0;
    end
    
    assert(k>=2,'Wrong usage. Number of clusters has to be at least 2.');
    assert(k<=size(W,1), 'Wrong usage. Number of clusters is larger than size of the graph.');
    assert(isnumeric(W) && issparse(W),'Wrong usage. W should be sparse and numeric.');
    assert(sum(sum(W~=W'))==0,'Wrong usage. W should be symmetric.');
    assert(isempty(find(diag(W)~=0,1)),'Wrong usage. Graph contains self loops. W has to have zero diagonal.');
	assert(~(numOuter>0 && numInner==0), sprintf('Wrong usage. numOuter=%d but numInner=%d. numInner has to be positive.',numOuter,numInner));
    
    switch(lower(criterion))
        case 'ncut'    
            criterion_inner=1; normalized=true;
        case 'ncc'     
            criterion_inner=2; normalized=true;
        case 'rcut'    
            criterion_inner=1; normalized=false;
        case 'rcc'     
            criterion_inner=2; normalized=false;
        otherwise
            error('Wrong usage. Unknown clustering criterion. Available clustering criteria are Ncut/NCC/Rcut/RCC.');
    end
    
    
    if (verbosity>=1)
        if(criterion_inner==1)
            critstring='Cut';
        else
            critstring ='Cheeger Cut';
        end
        if(normalized)
            critstring=sprintf('Normalized %s',critstring);
        else
            critstring=sprintf('Ratio %s',critstring);
        end
        fprintf('Optimization criterion: %s\n',critstring);
        fprintf('Number of clusters: %d\n',k);
        tempstring='Performing 1 run initialized with second eigenvector of standard graph Laplacian';
        if (numOuter==0)
            fprintf(strcat(tempstring,'.\n'));
        else
            if(numOuter==1)
                fprintf(strcat(tempstring,'\nand 1 additional run with random initializations. '));
            else
                fprintf(strcat(tempstring,sprintf('\nand %d additional runs with random initializations. ',numOuter)));
            end
            fprintf(' Number of random initializations: %d \n ',numInner);
        end
        fprintf('\n');
    end

    if (verbosity>=1 && numOuter>0) fprintf('STARTING RUN WITH SECOND EIGENVECTOR INITIALIZATION.\n'); end;
        
    try
        [clusters,cuts,cheegers] = computeMultiPartitioningTVC(W,normalized,k,true,0,criterion_inner,criterion_inner,uinit,verbosity);
    catch exc
        %disp(exc.identifier);
        if (strcmp(exc.identifier,'OneSpect:cutinf'))
            if (numOuter>0)
                cuts=inf;
                cheegers=inf;
                fprintf(strcat('WARNING!\t',exc.message,'\n'));
                fprintf('Proceeding with run with random initializations.\n\n');
            else
                cuts=inf;
                cheegers=inf;
                clusters=NaN(size(W,1),1);
                fprintf(strcat('ERROR!\t',exc.message,'\n'));
                fprintf('Rerun with additional random initializations.\n');
                return;
            end
        else
            rethrow(exc);
        end
    end
            
    
    for l=1:numOuter
        if (verbosity>=1) fprintf('STARTING RUN WITH RANDOM INITIALIZATIONS %d OF %d.\n', l,numOuter); end;
        
        [clusters_temp,cuts_temp,cheegers_temp] = computeMultiPartitioningTVC(W,normalized,k,false,numInner,criterion_inner,criterion_inner,uinit,verbosity);

        if ((criterion_inner==1 && cuts_temp(end)<cuts(end)) || (criterion_inner==2 && cheegers_temp(end)<cheegers(end)))
            [clusters,cuts,cheegers]=deal(clusters_temp,cuts_temp,cheegers_temp);
        end
    end
    

    fprintf('Best result:\n');
    if (normalized)
        fprintf('Normalized Cut: %.8g   Normalized Cheeger Cut: %.8g\n',cuts(end),cheegers(end)); 
    else
        fprintf('Ratio Cut: %.8g   Ratio Cheeger Cut: %.8g\n',cuts(end),cheegers(end)); 
    end

end
    
            