

% addpath('01- TVCheeger_comparison');
% addpath('02- OneSpectral_comparison');



function unsupervised_two_moons_comparison

clear


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MOONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


save_data = 2;
if save_data == 1
    
    % 2 moons
    tN=2000;
    sig=.02;
    sig=.015;
    dim=100;
    solution(1:tN/2)=0;
    solution(tN/2+1:tN)=1;
    x=linspace(0,pi,tN/2)';
    T=[cos(x) sin(x)];
    T=cat(1,T,[cos(x)+1 0.5-sin(x)]);
    T(:,3:dim)=0;
    T=T+sqrt(sig)*randn(tN,dim);
    
    
    file = 'two_moons.mat';
    save(file,'T','solution','tN');
    
else
    
    file = 'two_moons.mat';
    load(file,'T','solution','tN');
    
end



display = 2;
if display == 1
    figure(1); clf; s2=3; A=T'; N=size(A); 
    title('graph'); v=zeros(1,tN);
    scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');
    pause
end











%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construct the graph of data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% parameters
opts.kNN=10;
opts.kNNdelta=10;
opts.alpha=1;


file_w = 'weight_.mat';
save_w = 2;
if save_w==1
    tic
    fprintf('building weights... \n');
    [w NNIdxs]=fgf(T,opts);
    toc
    save(file_w,'w');
else
    load(file_w,'w');
end

tN = size(w,2);
Np = 2;
worig = w;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check results: post-processing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

check_results = 2;
if check_results == 1
    
    file = 'results_unsupervised.mat';
    load(file,'resultsUnsupCheeger','resultsUnsupCheegerPerc',...
        'resultsUnsupOneSpectral','resultsUnsupOneSpectralPerc');
    
     
    %meanResultsUnsupCheeger = mean(resultsUnsupCheeger)
    meanResultsUnsupCheegerPerc = mean(resultsUnsupCheegerPerc)
    
    
    %meanResultsUnsupOneSpectral = mean(resultsUnsupOneSpectral)
    meanResultsUnsupOneSpectralPerc = mean(resultsUnsupOneSpectralPerc)
    
    return
    
end














%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test unsupervised learning algorithms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nbTests = 100;

resultsUnsupCheeger = zeros(nbTests,1);
resultsUnsupCheegerPerc = zeros(nbTests,1);
resultsUnsupOneSpectral = zeros(nbTests,1);
resultsUnsupOneSpectralPerc = zeros(nbTests,1);


% Hein-Buhler
wOnespectral=w; for i=1:tN; wOnespectral(i,i)=0; end;


for kTest=1:nbTests
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % initial function
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % init
    uinit = rand(tN,1);
    uinit(uinit>=0.5)=1; uinit(uinit<0.5)=0;
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TV-based Cheeger [our method]
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    criterion='rcc'; % Ratio Cheeger Cut
    kc=2;
    numOuter=1;
    numInner=1;
    
    uinit2 = uinit;
    [clusters,cuts,cheegers] = CheegerTVClustering_comparison(wOnespectral,criterion,kc,numOuter,numInner,uinit2);
    u = clusters;
    
    % thresholding
    C=double(u>1.5); C1=C;
    
    % classification error
    v = zeros(tN,2);
    v(:,1) = C1;
    v(:,2) = 1-C1;
    mincent = zeros(1,tN);
    Np=2;
    for pp=1:Np
        mincent(v(:,pp)==1)=pp;
    end
    
    % confusion matrix
    x = confma(mincent,solution);
    if size(x,1)==2
        for ki=1:Np
            [ju juu]=max(x(ki,:));
            tx=x(ki,:);
            tx(juu)=0;
            ern(ki)=sum(tx);
        end
        classification_error = sum(ern);
    else
        classification_error = inf;
    end
    classification_error_percentage = classification_error*100/tN;
    
    resultsUnsupCheeger(kTest) = classification_error;
    resultsUnsupCheegerPerc(kTest) = classification_error_percentage;
    
    
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % 1-spectral [Hein-Buehler 2010]
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    criterion='rcc'; % Ratio Cheeger Cut
    kc=2;
    numOuter=1;
    numInner=1;
    
    uinit2 = uinit;
    [clusters,cuts,cheegers] = OneSpectralClustering_comparison(wOnespectral,criterion,kc,numOuter,numInner,uinit2);
    u = clusters;
    
    % thresholding
    C=double(u>1.5); C1=C;
    
    % classification error
    v = zeros(tN,2);
    v(:,1) = C1;
    v(:,2) = 1-C1;
    mincent = zeros(1,tN);
    Np=2;
    for pp=1:Np
        mincent(v(:,pp)==1)=pp;
    end
    
    % confusion matrix
    x = confma(mincent,solution);
    if size(x,1)==2
        for ki=1:Np
            [ju juu]=max(x(ki,:));
            tx=x(ki,:);
            tx(juu)=0;
            ern(ki)=sum(tx);
        end
        classification_error = sum(ern);
    else
        classification_error = inf;
    end
    classification_error_percentage = classification_error*100/tN;
    
    resultsUnsupOneSpectral(kTest) = classification_error;
    resultsUnsupOneSpectralPerc(kTest) = classification_error_percentage;
    
    
    
    

    kTest
    resultsUnsupCheeger_k = resultsUnsupCheeger(kTest)
    resultsUnsupOneSpectral_k = resultsUnsupOneSpectral(kTest)
    pause(1)
    %pause
    
    
    file = 'results_unsupervised.mat';
    save(file,'resultsUnsupCheeger','resultsUnsupCheegerPerc',...
        'resultsUnsupOneSpectral','resultsUnsupOneSpectralPerc');
    
    
    
end


meanResultsUnsupCheegerPerc = mean(resultsUnsupCheegerPerc)
meanResultsUnsupOneSpectralPerc = mean(resultsUnsupOneSpectralPerc)



end









