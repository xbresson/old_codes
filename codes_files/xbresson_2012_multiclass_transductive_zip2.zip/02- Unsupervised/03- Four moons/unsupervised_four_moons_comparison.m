
% addpath('01- TVCheeger_comparison2');


function unsupervised_four_moons_comparison

clear


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MOONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


save_data = 1;
if save_data == 1
    
    % 4 moons
    tN=4000;
    dim=100;
    x=linspace(0,pi,tN/4)'; 
    T=[1.5*cos(x) sin(x)];
    T=cat(1,T,[1.5*cos(x)+2 0.35-sin(x)]);
    T=cat(1,T,[1.5*cos(x)-2 0.35-sin(x)]);
    T=cat(1,T,[1.5*cos(x)+4 sin(x)]);
    sig=0.015;
    T(:,3:dim)=0;
    T=T+sqrt(sig)*randn(tN,dim);
    
    solution(1:tN/4)=0;
    solution(tN/4+1:tN/2)=1;
    solution(tN/2+1:3*tN/4)=2;
    solution(3*tN/4+1:tN)=3;
    
    file = 'four_moons.mat';
    save(file,'T','solution','tN');
    
else
    
    file = 'four_moons.mat';
    load(file,'T','solution','tN');
    
end




display = 2;
if display == 1
    figure(1); clf; s2=3; A=T'; N=size(A); 
    title('graph'); v=zeros(1,tN);
    scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');
    pause
end











%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construct the graph of data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% parameters
opts.kNN=10;
opts.alpha=1;
opts.kNNdelta=10;


file_w = 'weight_.mat';
save_w = 2;
if save_w==1
    tic
    fprintf('building weights... \n');
    [w NNIdxs]=fgf(T,opts);
    toc
    save(file_w,'w');
else
    load(file_w,'w');
end

tN = size(w,2);
Np = 4;













    



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TV-based Cheeger [our method]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% parameters

criterion='rcc'; % Ratio Cheeger Cut
k=4;
numOuter=1;
numInner=1;

W=w; for i=1:tN; W(i,i)=0; end;

[clusters,cuts,cheegers] = CheegerTVClustering_comparison2(W,criterion,k,numOuter,numInner);




file = 'result.mat';
save_result = 1;
if save_result==1
    save(file,'clusters','cuts','cheegers');
else
    load(file,'clusters','cuts','cheegers');
end


% show result
figure(4); clf;
s2=3; A=T'; N=size(A);
title('clusters'); v=clusters(:,k-1);
scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute misclassfication error with confusion matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% classification error
v = zeros(tN,4);
t=zeros(tN,1); t(clusters(:,k-1)==1)=1; v(:,1) = t;
t=zeros(tN,1); t(clusters(:,k-1)==2)=1; v(:,2) = t;
t=zeros(tN,1); t(clusters(:,k-1)==3)=1; v(:,3) = t;
t=zeros(tN,1); t(clusters(:,k-1)==4)=1; v(:,4) = t;
mincent = zeros(1,tN);
Np=4;
for pp=1:Np
    mincent(v(:,pp)==1)=pp;
end
% confusion matrix
x = confma(mincent,solution)
sumx = sum(sum(x))
for ki=1:Np
    [ju juu]=max(x(ki,:));
    tx=x(ki,:);
    tx(juu)=0;
    ern(ki)=sum(tx);
end
classification_error = sum(ern)







end











