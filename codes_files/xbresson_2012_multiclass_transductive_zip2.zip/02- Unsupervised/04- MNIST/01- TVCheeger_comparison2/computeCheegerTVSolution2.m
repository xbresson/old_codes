
function [fold,FctValOuter]=computeCheegerTVSolution2(W,fold,normalized,verbose,deg)
% based on 1-Spectral Clustering of M. Hein and T. B�hler

    if(nargin<4)
        verbose=true;
    end
    if nargin<5
        if (normalized)
			deg=full(sum(W,2));
		else
			deg=ones(size(W,1),1);
        end
    else
       deg=full(deg); 
    end
    
    
    assert(isnumeric(W) && issparse(W),'Wrong usage. W should be sparse and numeric.');

	[ix,jx,wval]=find(W);
	W2=triu(W);
	MaxSumSquaredWeights=2*max(sum(W.^2));

	pars.MAXITER=40;
	pars.epsilon = 1E-14; 
	%pars.tv = 'l1';
	maxiterations = 100;

    % Subtract median
    if (~normalized)
		fold = fold - median(fold);
    else
        fold = fold - weighted_median(fold,deg);
    end
    
    
	counter=0;
	diffFunction=inf; 
    rvalold=zeros(length(ix),1); 
	FctValOld=inf;
	FctValOuter=[]; 
    fnew=fold; 

    
    
    
    w = W;
    tN = size(w,1);
    kc = 2;
    
    rd=1e1;
    rv=1e2;
    rm=6*kc/tN;
    ns=150;
    nsi=10;
    maxiter=50;
    V2=tN/kc;
    p=0.4;
    Maxdiffl = 1e-4;
    Maxdiffinner = 1e-7;
    Maxdiffu = 1e-6;
    
    
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % pre-computed function
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    rdinv = 1/rd;
    rvinv = 1/rv;
    
    w=triu(w,1);
    [r c v]=find(w);
    n=length(r);
    Dr=[1:n 1:n];
    Dc(1:n)=r;
    Dc(n+1:2*n)=c;
    Dv(1:n)=2*v;
    Dv(n+1:2*n)=-2*v;
    D=sparse(Dr,Dc,Dv,n,tN);
    Dt=D';
    md=@(x,type) rv*x+rd*(Dt*(D*x));
    
    u1=fnew;
    v1=u1; l1=sum(abs(D*u1))/sum(abs(u1-median(u1)));
    
    
    
    C1 = zeros(tN,1);
    diffl=1; k=0; diffC=1; diffu=1;
    while ( diffl>Maxdiffl && k<maxiter && diffC>0 && diffu>Maxdiffu )
        
        
        % compute current functional value
        fnew = u1; 
        sval = wval.*abs(fnew(ix)-fnew(jx));
        if (~normalized)
            FctVal = 0.5*sum(sval)/norm(fnew,1);
        else
            FctVal = 0.5*sum(sval)/(deg'*abs(fnew));
        end
        
        fold = fnew;
        FctValOuter=[FctValOuter,FctVal];
        foldback=fold;
        FctOld=FctValOld;
        FctValOld = FctVal;
        
        
        k=k+1;
        
        l1old = l1;
        u1Outer = u1;
        C1old = C1;
        if (rem(k,5)==0) C1old = C1; end;
        
        ad1 = zeros(size(D*u1)); av1 = zeros(size(u1)); am1 = 0;
        
        
        diffinner=1; j=0;
        while ( diffinner>Maxdiffinner && j<ns )
            
            j=j+1;
            u1old=u1;
            v1old=v1;
            
            % new d
            d1 = shrink(D*u1-rdinv*ad1,rdinv);
            
            % new u
            [u1 flag]=pcg(md,rv*v1+av1 +rd*Dt*d1+Dt*ad1,1e-6,nsi,[],[],u1);
            
            % new v
            v1 = unshrink(u1-rvinv*av1-rvinv*am1,rvinv*l1); v1(v1>1)=1; v1(v1<0)=0;
            v1 = ( v1-min(v1) )/ ( max(v1)-min(v1) );
            
            % Lagrange multipliers
            ad1 = ad1+rd*(d1-D*u1); av1 = av1+rv*(v1-u1); am1 = max(0,am1+rm*(sum(v1)-V2));
            
            % stopping condition
            diffu1 = sum((u1old-u1).^2)/tN; diffv1 = sum((v1old-v1).^2)/tN;
            diffinner = max([diffu1 diffv1]);
            
        end % END inner iterations
        
        
        % new lagrange multiplier
        l1 = l1- p*(l1-sum(abs(D*u1))/sum(abs(u1)));
        
        % thresholding
        u=u1; C=double(u>median(u)); C1=C;
        
        
        % stopping condition
        diffl1 = abs(l1old-l1); diffl = diffl1;
        diffu = sum((u1Outer-u1).^2)/tN;
        if (rem(k,5)==0) diffC = sum(abs(C1old-C1))/2; end;
        
        fnew = u1;
        
        
        
    end

    
    
    
    

	% compute most recent Functional value
	sval = wval.*abs(fnew(ix)-fnew(jx));
    if(~normalized)
        FctVal = 0.5*sum(sval)/norm(fnew,1);
	else
		FctVal = 0.5*sum(sval)/(deg'*abs(fnew));
    end
    
    if(FctVal<FctValOld)
        fold = fnew;
        FctValOuter=[FctValOuter,FctVal];
    else
        FctVal=FctValOld;
    end
    if(verbose)
        [ac,cut,cheeger]=createClustersGeneral(fold,W,normalized,-1,2,deg);
        disp(['Functional: ',num2str(FctVal,'%1.16f'),' - Cheeger: ',num2str(cheeger,'%1.14f')]);
    end
end






function d = shrink(e,rinv)

s = abs(e);
ss = s-rinv;
ss = ss.*(ss>0);
s = s+(s<rinv);
ss = ss./s;
d = ss.*e;


end


function v=unshrink(e,r)

s = abs(e);
s = s+(s<1e-10);
ss = r./s;
v = e.*(1+ss);


end




