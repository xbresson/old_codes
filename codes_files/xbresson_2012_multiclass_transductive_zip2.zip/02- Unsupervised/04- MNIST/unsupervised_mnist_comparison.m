

% addpath('01- TVCheeger_comparison2');
% addpath('02- OneSpectral_comparison');
% addpath('03- Spectral_comparison');



function unsupervised_mnist_comparison

clear


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MNIST
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

file = 'file_mnist.mat';
load(file,'T','trainingT','labels','traininglabels');





save_graph = 2;
if save_graph == 1
    
    
    % Reorganize 60,000 data points (contiguous re-organization)
    for k=1:10
        id{k}=find(labels==k-1);
    end
    % select the sets for classification
    uid = [id{1} id{2} id{3} id{4} id{5} id{6} id{7} id{8} id{9} id{10}];
    T = T(uid,:);
    labels = labels(uid);
    
    
    % Reorganize 10,000 training points (contiguous re-organization)
    for k=1:10
        id{k}=find(traininglabels==k-1);
    end
    % select the sets for classification
    uid = [id{1} id{2} id{3} id{4} id{5} id{6} id{7} id{8} id{9} id{10}];
    trainingT = trainingT(uid,:);
    traininglabels = traininglabels(uid);
    
    
    % Data + Training points (concatenate data)
    allT = cat(1, double(T), double(trainingT));
    allLabels = [labels traininglabels];
    
        
    solution = allLabels;
    
    display = 2;
    if display == 1
        figure(1); clf; s2=3; A=T'; N=size(A); % MOONS
        title('graph'); v=solution;
        scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');
        pause
    end
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % construct the graph of data
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    opts.kNN=10;
    opts.kNNdelta=10;
    opts.alpha=1;

    tic
    fprintf('building weights... \n');
    [w NNIdxs]=fgf(allT,opts);
    toc
    
    file_w = 'weight_.mat';
    save(file_w,'w','solution');
    1
    %pause
    
    
else
    
    
    file_w = 'weight_.mat';
    load(file_w,'w','solution');
    
    
end



tN = size(w,2);





save_graph = 2;
if save_graph == 1
    
    wBH=w; for i=1:tN; wBH(i,i)=0; end;
    file_wBH = 'weightBH_.mat';
    save(file_wBH,'wBH');
    1
    %pause
    
else
    
    file_wBH = 'weightBH_.mat';
    load(file_wBH,'wBH');
    
end










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check results: post-processing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

check_results = 2;
if check_results == 1
    
    
    file = 'results_unsupervised_mnist.mat';
    load(file,'resultsUnsupCheeger','resultsUnsupCheegerPerc',...
        'resultsUnsupOneSpectral','resultsUnsupOneSpectralPerc');
    
    %meanResultsUnsupCheeger = mean(resultsUnsupCheeger)
    meanResultsUnsupCheegerPerc = mean(resultsUnsupCheegerPerc)
    
    
    %meanResultsUnsupOneSpectral = mean(resultsUnsupOneSpectral)
    meanResultsUnsupOneSpectralPerc = mean(resultsUnsupOneSpectralPerc)
    
    
    return
    
end












 

 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test unsupervised learning algorithms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nbTests = 10;

resultsUnsupCheeger = zeros(nbTests,1);
resultsUnsupCheegerPerc = zeros(nbTests,1);
resultsUnsupOneSpectral = zeros(nbTests,1);
resultsUnsupOneSpectralPerc = zeros(nbTests,1);





for kTest=1:nbTests
    
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TV-based Cheeger [our method]
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    disp(' ');
    disp('---------------------------');
    disp('Cheeger');
    disp('---------------------------');
    
        
    
    % parameters
    
    criterion='rcc'; % Ratio Cheeger Cut
    kc=10;
    numOuter=1;
    numInner=1;
    
    
    [clusters,cuts,cheegers] = CheegerTVClustering_comparison2(wBH,criterion,kc,numOuter,numInner);


    
    % classification error
    v = zeros(tN,10);
    t=zeros(tN,1); t(clusters(:,kc-1)==1)=1; v(:,1) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==2)=1; v(:,2) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==3)=1; v(:,3) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==4)=1; v(:,4) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==5)=1; v(:,5) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==6)=1; v(:,6) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==7)=1; v(:,7) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==8)=1; v(:,8) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==9)=1; v(:,9) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==10)=1; v(:,10) = t;
    mincent = zeros(1,tN);
    Np=10;
    for pp=1:Np
        mincent(v(:,pp)==1)=pp;
    end
    % confusion matrix
    x = confma(mincent,solution);
    for ki=1:Np
        [ju juu]=max(x(ki,:));
        tx=x(ki,:);
        tx(juu)=0;
        ern(ki)=sum(tx);
    end
    classification_error = sum(ern)
    classification_error_percentage = classification_error*100/tN;
    
    
    %kTest
    resultsUnsupCheeger(kTest) = classification_error;
    resultsUnsupCheegerPerc(kTest) = classification_error_percentage;
    
    
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % 1-spectral [Hein-Buehler 2010]
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    disp(' ');
    disp('---------------------------');
    disp('1-spectral');
    disp('---------------------------');
    
    
    
    criterion='rcc'; % Ratio Cheeger Cut
    kc=10;
    numOuter=1;
    numInner=1;
    
    [clusters,cuts,cheegers] = OneSpectralClustering_comparison(wBH,criterion,kc,numOuter,numInner);
   
    
   
    % classification error
    v = zeros(tN,10);
    t=zeros(tN,1); t(clusters(:,kc-1)==1)=1; v(:,1) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==2)=1; v(:,2) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==3)=1; v(:,3) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==4)=1; v(:,4) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==5)=1; v(:,5) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==6)=1; v(:,6) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==7)=1; v(:,7) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==8)=1; v(:,8) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==9)=1; v(:,9) = t;
    t=zeros(tN,1); t(clusters(:,kc-1)==10)=1; v(:,10) = t;
    mincent = zeros(1,tN);
    Np=10;
    for pp=1:Np
        mincent(v(:,pp)==1)=pp;
    end
    % confusion matrix
    x = confma(mincent,solution);
    for ki=1:Np
        [ju juu]=max(x(ki,:));
        tx=x(ki,:);
        tx(juu)=0;
        ern(ki)=sum(tx);
    end
    classification_error = sum(ern)
    classification_error_percentage = classification_error*100/tN;
    
    %kTest
    resultsUnsupOneSpectral(kTest) = classification_error;
    resultsUnsupOneSpectralPerc(kTest) = classification_error_percentage;
    

    
    
    
    kTest
    resultsUnsupCheeger_k = resultsUnsupCheeger(kTest)
    resultsUnsupOneSpectral_k = resultsUnsupOneSpectral(kTest)
    pause(1)
    %pause
    
    
    file = 'results_unsupervised_mnist.mat';
    save(file,'resultsUnsupCheeger','resultsUnsupCheegerPerc',...
        'resultsUnsupOneSpectral','resultsUnsupOneSpectralPerc');
    
    
    



end









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Spectral clustering [Shi-Malik 2000]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(' ');
disp('---------------------------');
disp('Spectral');
disp('---------------------------');




criterion='rcc'; % Ratio Cheeger Cut
kc=10;
numOuter=0; % 0
numInner=0;

[clusters,cuts,cheegers] = SpectralClustering_comparison(wBH,criterion,kc,numOuter,numInner);


% classification error
v = zeros(tN,10);
t=zeros(tN,1); t(clusters(:,kc-1)==1)=1; v(:,1) = t;
t=zeros(tN,1); t(clusters(:,kc-1)==2)=1; v(:,2) = t;
t=zeros(tN,1); t(clusters(:,kc-1)==3)=1; v(:,3) = t;
t=zeros(tN,1); t(clusters(:,kc-1)==4)=1; v(:,4) = t;
t=zeros(tN,1); t(clusters(:,kc-1)==5)=1; v(:,5) = t;
t=zeros(tN,1); t(clusters(:,kc-1)==6)=1; v(:,6) = t;
t=zeros(tN,1); t(clusters(:,kc-1)==7)=1; v(:,7) = t;
t=zeros(tN,1); t(clusters(:,kc-1)==8)=1; v(:,8) = t;
t=zeros(tN,1); t(clusters(:,kc-1)==9)=1; v(:,9) = t;
t=zeros(tN,1); t(clusters(:,kc-1)==10)=1; v(:,10) = t;
mincent = zeros(1,tN);
Np=10;
for pp=1:Np
    mincent(v(:,pp)==1)=pp;
end
% confusion matrix
x = confma(mincent,solution);
for ki=1:Np
    [ju juu]=max(x(ki,:));
    tx=x(ki,:);
    tx(juu)=0;
    ern(ki)=sum(tx);
end
classification_error_spectral = sum(ern)
classification_error_spectral_percentage = classification_error_spectral*100/tN




meanResultsUnsupCheegerPerc = mean(resultsUnsupCheegerPerc)
meanResultsUnsupOneSpectralPerc = mean(resultsUnsupOneSpectralPerc)




end









