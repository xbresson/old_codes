

function unsupervised_cheegerBH2

clear


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MOONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


save_data = 2;
if save_data == 1
    
    % 2 moons
    tN=2000;
    sig=.02;
    sig=.015;
    dim=100;
    solution(1:tN/2)=0;
    solution(tN/2+1:tN)=1;
    x=linspace(0,pi,tN/2)';
    T=[cos(x) sin(x)];
    T=cat(1,T,[cos(x)+1 0.5-sin(x)]);
    T(:,3:dim)=0;
    T=T+sqrt(sig)*randn(tN,dim);
    
    
    file = 'two_moons.mat';
    save(file,'T','solution','tN');
    
else
    
    file = 'two_moons.mat';
    load(file,'T','solution','tN');
    
end



display = 2;
if display == 1
    figure(1); clf; s2=3; A=T'; N=size(A); % MOONS
    title('graph'); v=zeros(1,tN);
    scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');
    pause
end











%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construct the graph of data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% parameters

% MOONS
opts.kNN=10;
opts.alpha=5;
opts.kNNdelta=10;


file_w = 'weight_.mat';
save_w = 2;
if save_w==1
    tic
    fprintf('building weights... \n');
    [w NNIdxs]=fgf(T,opts);
    toc
    save(file_w,'w');
    
    1
    pause
else
    load(file_w,'w');
end

tN = size(w,2);
Np = 2;














% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % initial function
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% % init 1
% r=1; md2=@(x,type) r*x+1*r*(Dt*(D*x)); % ok
% u1=zeros(tN,1); u1(round(rand(1)*tN))=1;
% [u1 flag]=pcg(md2,u1,1e-6,50,[],[],u1); u1=u1-mean(u1); u1(u1>0)=1; u1(u1<=0)=0;
% 
% 
% 
% % init2
% file_init = 'init_.mat';
% save_init = 1;
% if save_init==1
%     u1 = rand(tN,1);
%     save(file_init,'u1');
% else
%     load(file_init,'u1');
% end
% u1(u1>=0.5)=1; u1(u1<0.5)=0;
% 
% 
% 
% display = 2;
% if display == 1
%     figure(2); clf; s=3; A=T'; N=size(A);
%     title('init'); v=u1;
%     scatter(A(1,1:N(2)),A(2,1:N(2)),s*ones(1,N(2)),v,'o', 'filled');
%     pause
% end
% 
% 
% v1=u1; l1=sum(abs(D*u1))/sum(abs(u1-median(u1)));
% 
% sumu1init=sum(u1)
% %pause
% 
%     
% display = 1;
% if display == 1
%     figure(3); clf; s2=3; A=T'; N=size(A); % MOONS
%     title('init'); v=u1;
%     scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');
%     pause
% end

    
    
    
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unsupervised learning algorithm Hein-Buehler
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

W=w; for i=1:tN; W(i,i)=0; end;

criterion='rcc'; % Ratio Cheeger Cut
k=2;
numOuter=1;
numInner=5;
tic
[clusters,cuts,cheegers] = OneSpectralClustering(W,criterion,k,numOuter,numInner); % OK
toc
    

file = 'result.mat';
save_result = 1;
if save_result==1
    save(file,'clusters','cuts','cheegers');
else
    load(file,'clusters','cuts','cheegers');
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute misclassfication error with confusion matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

u1=clusters;


% thresholding
u=u1; C=double(u>1.5); C1=C;




% show intermediate results
figure(4); clf;
subplot(121); s2=3; A=T'; N=size(A);
title('u1'); v=u1;
scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');
subplot(122); s2=3; A=T'; N=size(A);
title('thresholded u1'); v=C1;
scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');


% show histogram
minu1=min(u1);
maxu1=max(u1);
Xu1=minu1:(maxu1-minu1)/1000:maxu1;
Hu1=histc(u1,Xu1);

figure(5); clf;
plot(Xu1,Hu1,'r','LineWidth',2); hold on; title('u1');
%pause





% classification error
v = zeros(tN,2);
v(:,1) = C1;
v(:,2) = 1-C1;
mincent = zeros(1,tN);
Np=2;
for pp=1:Np
    mincent(v(:,pp)==1)=pp;
end
%size(mincent)
%nclasses_mincent=length(unique(mincent))
% confusion matrix
x = confma(mincent,solution)
sumx = sum(sum(x))
for ki=1:Np
    [ju juu]=max(x(ki,:));
    tx=x(ki,:);
    tx(juu)=0;
    ern(ki)=sum(tx);
end
classification_error = sum(ern)







end











