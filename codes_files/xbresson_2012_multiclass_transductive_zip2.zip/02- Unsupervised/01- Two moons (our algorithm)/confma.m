function C=confma(mincent,labels);
%function C=confma(mincent,labels);
%confusion matrix by dominant label
%labels runs form 0 to nclasses-1


[b mlid]=mvi(mincent);

nc=length(mlid);
nclasses=length(unique(labels));

C=zeros(nc,nclasses);
fix=[];

for k=1:nc
    lak=labels(mlid{k})+1;
    l=mode(lak);
    
    if C(l,l)==0
        for j=1:nclasses
            C(l,j)=length(find(lak==j));
        end
    else
        fix(k)=1;
    end
end

nf=length(find(fix));
count=1;

for k=1:length(fix);
    if fix(k)==1
        lak=labels(mlid{k})+1;
        for j=1:nclasses
            C(end-nf+count,j)=length(find(lak==j));
        end
        count=count+1;
    end
end