/*Copyright ESIEE (2009) 

Author :
Camille Couprie (c.couprie@esiee.fr)

Contributors : 
Hugues Talbot (h.talbot@esiee.fr)
Leo Grady (leo.grady@siemens.com)
Laurent Najman (l.najman@esiee.fr)

This software contains some image processing algorithms whose purpose is to be
used primarily for research.

This software is governed by the CeCILL license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/
/*! \file powerwatsurf.c
\defgroup surf Surface Reconstruction

\brief Implements a power watershed-based surface fitting (from a set of points) algorithm 

<B>Usage:</B> ./ powerwatsurf.exe -a algo_number -i points_image 

<B>Description: see the surface reconstruction page </B>

\ingroup surf

\author Camille Couprie
*/

#include <graph_utils.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>
#include <mccodimage.h>
#include <mcimage.h>
#include <MSF_RW.h>
#include <ldist.h>
#include <mesh_toolbox.h>
#include <mcutil.h>
#include <mclistechainee.h>

void AddDistEdges_PW(struct xvimage * image,  char * seed_name,  struct graph <uint32_t>* G, uint32_t *maxi, int32_t *index); 

/* =============================================================== */
int main(int argc, char **argv) 
/* =============================================================== */
/* Input : an image of black dots on a white background,
 and seeds for indicating the inside and outside of a shape fitting the dots.
Output : a object indicator, its curve fitting the dots.
*/
{
  //char *image_name, *seeds_name, *output_name;	
  int  j, k, t1, t2, t3, t4;
  int rs, cs, ds; 
  struct xvimage * image, *img_proba;
  struct graph  <uint32_t> *G;
  unsigned char *Temp2, *s; 
  uint32_t maxi;
  int32_t *index;
  struct xvimage * seeds;

  if (argc!=3)
    { 
      fprintf(stderr, "usage: %s image.pgm seeds_2_labels.pgm \n", argv[0]);
      exit(1);
    }

 // initializes the random number generator
 // init_genrand64(time(0));

  img_proba = readheader(argv[1]);
  rs = rowsize(img_proba);
  cs = colsize(img_proba);
  ds = depth(img_proba);

 //estimate the size of graph for memory allocation
  seeds = readimage(argv[2]);
  int cpt = rs*cs*ds;
  s = UCHARDATA(seeds);
  for(k=0;k<rs*cs*ds;k++) 
    if((s[k]==0)||(s[k]==255)) 
      cpt--;
      
  double alloc_factor = 1;
  freeimage(seeds);

  // Building the graph
  G = (struct graph  <uint32_t>*)malloc(sizeof(struct graph <uint32_t> ));

  // Reading the image
  image = readimage(argv[1]);

  t1=clock();
 
      Allocate_Graph(G, (int)((rs*cs*ds)/alloc_factor),/*Number of nodes*/ 
		     (int)((rs*cs*ds)/alloc_factor), /*Max Number of seeded nodes*/ 
		     (int)((ds*rs*(cs-1)+ds*(rs-1)*cs+(ds-1)*cs*rs)/alloc_factor)); /*Number of edges*/ 
		     
      index = (int32_t*)malloc(sizeof(int32_t)*rs*cs*ds); 
     
      AddDistEdges_PW(image, argv[2], G, &maxi, index);
      
      //Print_Graph_Content(G, 0);
      
      // Solving problem with Power Watersheds
      t3=clock();
      PowerWatershed_q2<uint32_t>(G);
      t4 = clock();
      printf("Computation time PW : %.6lf seconds elapsed\n", ((double)t4-t3)/CLOCKS_PER_SEC);
      printf("Computation time PW starting from graph construction : %.6lf seconds elapsed\n", ((double)t4-t1)/CLOCKS_PER_SEC);
      
    
      // Writing results 
    
      img_proba = allocimage(NULL, rs, cs, ds, VFF_TYP_1_BYTE);
      Temp2 = UCHARDATA(img_proba);
         
      for (j = 0; j < rs*cs*ds; j++)
	if ((index[j]!=-1)&&(index[j]!=-2))
	  Temp2[j] = (unsigned char)(255-255*G->Solution[0][index[j]]);
	else if(index[j]!=-1) Temp2[j] = 255;
	else  Temp2[j] = 0;

      writeimage(img_proba, (char*)"proba.pgm");
      
      //Free memory
      free(index);
      freeimage(img_proba);
      Free_Graph(G, G->N);
  
   
  t2=clock();
  printf("Computation time : %.6lf seconds elapsed\n", ((double)t2-t1)/CLOCKS_PER_SEC);
  return 0;
} 


/* ============================================================================ */
uint32_t * Compute_distance_map(struct xvimage * image) /*IN : image containing a set of points*/
/*OUT : returns the euclidean distance map */			
/* ============================================================================ */
{
  uint32_t *D;
  struct xvimage *dist_map;//, *reduced_map; 
  dist_map = allocimage(NULL, rowsize(image),colsize(image) , depth(image), VFF_TYP_4_BYTE);
  lsedt_meijster(image, dist_map);        
  D = UINT32DATA(dist_map);
  fprintf(stderr,"Distances computed\n");
  if (depth(image)>1) freeimage(image);
  return D;
}


/* ======================================================================================================== */
void AddDistEdges_PW(struct xvimage * image, // IN image containing the set of points 
		     char * seed_name, // IN image containing the seeds/markers
		     struct graph <uint32_t> * G, // IN-OUT : The edge weights and shape of the graph is specified here
		     uint32_t *maxi,  // OUT : maximum number of different weights in the graph
		     int32_t *index)  // OUT : array storing node indexes in a grid
/* ======================================================================================================== */
/* The seed image I contained in seed_name indicates the space of solution research : 
   If I == 200 : foreground seed 
   I == 75   : background seed
   I == 128 : solution space
   I == 0 : ignored background space
   I == 255 : ignored foreground space
  */
{
  int i, j, k, l, M, rs, cs, ds, node1, node2, rs_cs, ind_node1, ind_node2 ;
  int nb_nodes, nb_node_slice;
  uint32_t *D;
  uint8_t * s;
  struct xvimage * seeds;

  rs = rowsize(image);
  cs = colsize(image);
  ds = depth(image);
  rs_cs = rs*cs;
  M = 0;
 
  D = Compute_distance_map(image);

  seeds = readimage(seed_name);
  s = UCHARDATA(seeds);

  fprintf(stderr, "Original grid size :  %d nodes, %d edges \n", G->N, G->M);
  for (i=0;i<rs*cs*ds;i++) index[i]=-1;
  G->P = 1;
  
  G->S = 0;
  nb_nodes=0;
  nb_node_slice =0;
  *maxi = 0;
  for(k=0;k<ds;k++) 
    {
      // fprintf(stderr, "k =  %d %d \n", k, ds);
      nb_nodes =nb_node_slice;
      for(i=0;i<cs;i++) 
	for(j=0;j<rs;j++)
	  {
	    node1 = nb_nodes;
	    ind_node1 = j+i*rs+k*rs_cs;
	    
	    if((s[ind_node1]>0)&&(s[ind_node1]<255))// node is in the solution space
	      {
		nb_nodes++;
	
		index[ind_node1]=node1;
		/*Node 1 is seeded*/
		if(s[ind_node1]==200) 
		  {
		    G->SeededNodes[G->S] = node1;
		    G->Labels[G->S]=2;
		    G->S++;
		  }
		else if(s[ind_node1]==75) 
		  {
		    G->SeededNodes[G->S] = node1;
		    G->Labels[G->S]=1;
		    G->S++;
		  }
		
		if(j<(rs-1))// build horizontal edge
		  {
		    ind_node2 = j+1+i*rs+k*rs_cs;
		    if((s[ind_node2]>0) &&(s[ind_node2]<255))
		      {
			node2 = node1+1;
			AddEdge<uint32_t>(G, node1, node2, min(D[ind_node1],D[ind_node2])+1,M);
			if(D[ind_node1]>*maxi) *maxi = D[ind_node1];
			M++;
		      }
		  }
	      }
	    else
	      if (s[ind_node1]==255)
		index[ind_node1]=-2;
	  }
    
      nb_nodes= nb_node_slice;
      
      //fprintf(stderr, "Apres X %d \n", nb_nodes);
      for(i=0;i<cs;i++) 
	for(j=0;j<rs;j++)
	  {
	    node1 = nb_nodes;
	    ind_node1 = j+i*rs+k*rs_cs;
	    
	    if((s[ind_node1]>0)&&(s[ind_node1]<255)) // node is in the solution space
	      {
		nb_nodes++;
		if(i<(cs-1))// build vertical edge
		  {
		    ind_node2 = j+(1+i)*rs+k*rs_cs;
		    if((s[ind_node2]>0)&&(s[ind_node2]<255))
		      {
			node2 = index[ind_node2];
			AddEdge<uint32_t>(G, node1, node2, min(D[ind_node1],D[ind_node2])+1,M);
			if(D[ind_node1]>*maxi) *maxi = D[ind_node1];
			M++;
		      }
		  }
	      }
	  }
      nb_node_slice = nb_nodes;
    }

  //fprintf(stderr, "Apres Y %d \n", nb_nodes);
  if (ds>1)
    {
      nb_nodes=0;
      for(k=0;k<ds;k++) 
	for(l=k*rs_cs;l<(k+1)*rs_cs;l++) 
	  {
	    node1 = nb_nodes;
	    ind_node1 = l;
	    if((s[ind_node1]>0)&&(s[ind_node1]<255)) // node is in the solution space
	      {
		nb_nodes++;
		if (k<ds-1) // build edge 
		  {
		    ind_node2 = l+rs_cs;
		    if((s[ind_node2]>0)&&(s[ind_node2]<255))
		      {
			
			node2 = index[ind_node2];
			AddEdge<uint32_t>(G, node1, node2, min(D[ind_node1],D[ind_node2])+1,M);
			if(D[ind_node1]>*maxi) *maxi = D[ind_node1];
			M++;
		      }
		  }
	      }
	  }
    }
  free(D);
  freeimage(seeds);
  int nb_max_seeded_nodes = G->N;
  fprintf(stderr, "Graph built, %d nodes, %d edges \n", nb_nodes , M);
  // fprintf(stderr, "Graph built, %d nodes (%f \% ), %d edges (%f \% ) \n", nb_nodes , (float)(nb_nodes)/G->N, M, (float)(M)/G->M);
  G->N = nb_nodes;
  G->M = M;
  Free_Partial_Graph(G,nb_max_seeded_nodes, 0);
  G->RecWeights = (uint32_t*) realloc(G->RecWeights ,sizeof(uint32_t)*G->M);
  G->max_weight= *maxi;
 }



