/*Copyright ESIEE (2009) 

Author :
Camille Couprie (c.couprie@esiee.fr)

Contributors : 
Hugues Talbot (h.talbot@esiee.fr)
Leo Grady (leo.grady@siemens.com)
Laurent Najman (l.najman@esiee.fr)

This software contains some image processing algorithms whose purpose is to be
used primarily for research.

This software is governed by the CeCILL license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mcimage.h"
#include "mccodimage.h"
#include "mesh_toolbox.h"
#include <math.h>

//./fitting_error.exe .txt .txt 
/* =============================== */
double FittingQualityMeasure(const char *points_path, const char * triangle_path)
/* =============================== */
/*Input : 2 filenames of list of points coordinates.*/
/*Output : the average distance from data to the center of mass of the mesh triangles. */
{
  double error = 0;
  int i, j, k,c;
  float step;
  float dims[3];
 float dims2[3];
  float bbox_min[3];
  float bbox_max[3];
  float bbox2_min[3];
  float bbox2_max[3];

  /* struct xvimage * image ;
 
 image = readimage((char*)(points_path));
 uint8_t * I= UCHARDATA(image); 
  float rs = rowsize(image);
  float cs = colsize(image);
  float ds = depth(image);
  int N = rs*ds*cs;
  float *Px= (float*)malloc(sizeof(float)*N);
  float *Py= (float*)malloc(sizeof(float)*N);
  float *Pz= (float*)malloc(sizeof(float)*N);

  bbox_min[0]=0;  bbox_min[1]=0;  bbox_min[2]=0;
  bbox_max[0]=rs;  bbox_max[1]=cs;  bbox_max[2]=ds;
  
  for(k=0;k<ds; k++)
    for(j=0;j<cs; j++)
      for(i=0;i<rs; i++)
	
	if(I[(int)(k*rs*cs+j*rs+i)]==0)
	  {
	    Px[nb_points]=i+0.5;
	    Py[nb_points]=j+0.5;
	    Pz[nb_points]=k+0.5;
	    nb_points++;
	  }
  


 
  for(j = 0; j < 3; j++)
    dims[j] = (bbox_max[j]-bbox_min[j]);
  
  fprintf (stderr,  "bboxmin %f %f %f \n",  bbox_min[0],  bbox_min[1],  bbox_min[2]);
  fprintf (stderr,  "bboxmax %f %f %f \n",  bbox_max[0],  bbox_max[1],  bbox_max[2]);
 
  fprintf(stderr, "Grid dimensions: %f %f %f\n", dims[0], dims[1], dims[2]);
  */
  //----------------
float flux1, flux2, flux3;

FILE * buffer = fopen(points_path, "r");
 
  c = fscanf(buffer, "%f %f %f,\n", &flux1, &flux2, &flux3);
  bbox_min[0]=flux1;  bbox_min[1]=flux2;  bbox_min[2]=flux3;
  bbox_max[0]=flux1;  bbox_max[1]=flux2;  bbox_max[2]=flux3;
  int nb_points=0;
  while(c!=-1)
    {
      c = fscanf(buffer, "%f %f %f,\n", &flux1, &flux2, &flux3);
    if (bbox_min[0]>flux1) bbox_min[0]=flux1;
      if (bbox_max[0]<flux1) bbox_max[0]=flux1;
      if (bbox_min[1]>flux2) bbox_min[1]=flux2;
      if (bbox_max[1]<flux2) bbox_max[1]=flux2;
      if (bbox_min[2]>flux3) bbox_min[2]=flux3;
      if (bbox_max[2]<flux3) bbox_max[2]=flux3;
      nb_points++;
    }
 
  fclose(buffer);
 for(j = 0; j < 3; j++)
    dims[j] = (bbox_max[j]-bbox_min[j]);

 fprintf (stderr,  "bboxmin %f %f %f \n",  bbox_min[0],  bbox_min[1],  bbox_min[2]);
 fprintf (stderr,  "bboxmax %f %f %f \n",  bbox_max[0],  bbox_max[1],  bbox_max[2]);

 fprintf(stderr, "Grid dimensions: %f %f %f\n", dims[0], dims[1], dims[2]);
//reading points 2
  float *Px= (float*)malloc(sizeof(float)*nb_points);
  float *Py= (float*)malloc(sizeof(float)*nb_points);
  float *Pz= (float*)malloc(sizeof(float)*nb_points);
  buffer = fopen(points_path, "r");
  //float f1 =  dims[0]/dims2[2]; 
  //  float f2 = dims[1]/dims2[1];
  //  //  float f3 = dims[2]/dims2[0];
  // float factor = (f2+f3)/2;
 //printf("factor = %f ( %f %f %f )\n", factor, f1, f2, f3);

  FILE * out = fopen("first_surface.txt", "w");
  for(i=0;i<nb_points;i++)
    {
      fscanf(buffer, "%f %f %f,\n",&flux1, &flux2, &flux3);
      Px[i] = flux1; //(flux3 - bbox2_min[2])*factor;
      Py[i] = flux2;//(flux2 - bbox2_min[1])*factor; 
      Pz[i] = flux3;// (bbox_max[2] - bbox_min[2] ) -(flux1 - bbox2_min[0])*factor; 
      fprintf(out, "%f %f %f \n",Px[i], Py[i], Pz[i] );
    }
  fclose(buffer);
fclose(out);
  

  //---------------------


 //reading bounding box 2
  buffer = fopen(triangle_path, "r");
 
  c = fscanf(buffer, "%f %f %f,\n", &flux1, &flux2, &flux3);
  bbox2_min[0]=flux1;  bbox2_min[1]=flux2;  bbox2_min[2]=flux3;
  bbox2_max[0]=flux1;  bbox2_max[1]=flux2;  bbox2_max[2]=flux3;
  int nb_triangles=0;
  while(c!=-1)
    {
      c = fscanf(buffer, "%f %f %f,\n", &flux1, &flux2, &flux3);
    if (bbox2_min[0]>flux1) bbox2_min[0]=flux1;
      if (bbox2_max[0]<flux1) bbox2_max[0]=flux1;
      if (bbox2_min[1]>flux2) bbox2_min[1]=flux2;
      if (bbox2_max[1]<flux2) bbox2_max[1]=flux2;
      if (bbox2_min[2]>flux3) bbox2_min[2]=flux3;
      if (bbox2_max[2]<flux3) bbox2_max[2]=flux3;
      nb_triangles++;
    }
 
  fclose(buffer);
 for(j = 0; j < 3; j++)
    dims2[j] = (bbox2_max[j]-bbox2_min[j]);

printf("nb_points = %d nb_triangles = %d \n",  nb_points, nb_triangles);
 fprintf (stderr,  "bbox2min %f %f %f \n",  bbox2_min[0],  bbox2_min[1],  bbox2_min[2]);
 fprintf (stderr,  "bbox2max %f %f %f \n",  bbox2_max[0],  bbox2_max[1],  bbox2_max[2]);

 fprintf(stderr, "Grid dimensions: %f %f %f\n", dims2[0], dims2[1], dims2[2]);
//reading points 2
  float *Tx= (float*)malloc(sizeof(float)*nb_triangles);
  float *Ty= (float*)malloc(sizeof(float)*nb_triangles);
  float *Tz= (float*)malloc(sizeof(float)*nb_triangles);
  buffer = fopen(triangle_path, "r");
  //float f1 =  dims[0]/dims2[2]; 
  //  float f2 = dims[1]/dims2[1];
  //  //  float f3 = dims[2]/dims2[0];
  // float factor = (f2+f3)/2;
 //printf("factor = %f ( %f %f %f )\n", factor, f1, f2, f3);

  out = fopen("second_surface.txt", "w");
  for(i=0;i<nb_triangles;i++)
    {
      fscanf(buffer, "%f %f %f,\n",&flux1, &flux2, &flux3);
      Tx[i] = flux1; //(flux3 - bbox2_min[2])*factor;
      Ty[i] = flux2;//(flux2 - bbox2_min[1])*factor; 
      Tz[i] = flux3;// (bbox_max[2] - bbox_min[2] ) -(flux1 - bbox2_min[0])*factor; 
      fprintf(out, "%f %f %f \n",Tx[i], Ty[i], Tz[i] );
    }
  fclose(buffer);
fclose(out);
  printf("nb_points = %d nb_triangles = %d \n",  nb_points, nb_triangles);
  // compute error
  float distmin, dist;
  for(i=0;i<nb_triangles;i++)
  
     {
       distmin = 100;
     
       for(j=0;j<nb_points;j++)
	 {
	   dist = (Tx[i] - Px[j])*(Tx[i] - Px[j])+(Ty[i] - Py[j])*(Ty[i] - Py[j]) + (Tz[i] - Pz[j])*(Tz[i] - Pz[j]);
	   if (dist <distmin) distmin=dist;
	 }
       error= error + sqrt(distmin);
     }

  float diag_BB = sqrt(dims2[0]*dims2[0]+dims2[1]*dims2[1]+dims2[2]*dims2[2])  ;
  return (error/nb_triangles)/diag_BB;

}


/* =============================== */
void Mesh2ImageofPoint(const char *points_path, int RESOLUTION, char* outname  )
/* =============================== */
{
  struct xvimage * image ;
  unsigned char *result;
  int grid_size, i, j, c;
  float step;
  int dims[3];
  float bbox_min[3];
  float bbox_max[3];

  //reading bounding box
  // FILE *inbbox = fopen(bbox_path, "r");
  //if(fscanf(inbbox, "%f %f %f %f %f %f", bbox_min, bbox_min+1, bbox_min+2,
  //	    bbox_max, bbox_max+1, bbox_max+2) != 6)
  //  throw "Cannot read bbox!";
  //fclose(inbbox);

  //reading bounding box
  FILE *buffer = fopen(points_path, "r");
  FILE *out = fopen("display.txt", "w");
  float flux1, flux2, flux3;

  c = fscanf(buffer, "%f %f %f\n", &flux1, &flux2, &flux3);
  bbox_min[0]=flux1;  bbox_min[1]=flux2;  bbox_min[2]=flux3;
  bbox_max[0]=flux1;  bbox_max[1]=flux2;  bbox_max[2]=flux3;
  while(c!=-1)
    {
      c = fscanf(buffer, "%f %f %f\n", &flux1, &flux2, &flux3);
      if (bbox_min[0]>flux1) bbox_min[0]=flux1;
      if (bbox_max[0]<flux1) bbox_max[0]=flux1;
      if (bbox_min[1]>flux2) bbox_min[1]=flux2;
      if (bbox_max[1]<flux2) bbox_max[1]=flux2;
      if (bbox_min[2]>flux3) bbox_min[2]=flux3;
      if (bbox_max[2]<flux3) bbox_max[2]=flux3;
      fprintf(out, "%f %f %f \n", flux1, flux2, flux3);
    }
 
  fclose(buffer);
  fclose(out);
  bbox_min[0] = bbox_min[0]-0.1;
 bbox_min[1] = bbox_min[1]-0.1;
 bbox_min[2] = bbox_min[2]-0.1;
 bbox_max[0] = bbox_max[0]+0.1;
 bbox_max[1] = bbox_max[1]+0.1;
 bbox_max[2] = bbox_max[2]+0.1;

  //computing the voxel size
  step = (bbox_max[0]-bbox_min[0])/RESOLUTION;
  fprintf(stderr, "s = %f\n", step);
  for(j = 0; j < 3; j++)
    dims[j] = int((bbox_max[j]-bbox_min[j])/step);
  
  fprintf(stderr, "Grid dimensions: %d %d %d\n", dims[0], dims[1], dims[2]);
  grid_size = dims[0]*dims[1]*dims[2];
 
  //reading points : processing flux term, one-by-one to save memory
  buffer = fopen(points_path, "r");
 
  image = allocimage(NULL, dims[0], dims[1], dims[2], VFF_TYP_1_BYTE);
  result = UCHARDATA(image);
  for(i=0;i<grid_size;i++)
    result[i]=255;


  i=0;
  c=1;
  while(c!=-1)
    {
      c = fscanf(buffer, "%f %f %f\n", &flux1, &flux2, &flux3);
      j = (int)((flux1- bbox_min[0])/step) 
	+ dims[0]* (int)((flux2 - bbox_min[1] )/step)
	+ dims[0]*dims[1]*(int)((flux3 - bbox_min[2] )/step);
      if ((j>=0)&&(j<grid_size))
	result[j] = 0;
      i++;
    }
 
  writeimage(image, outname);
  fclose(buffer);
  /*  for(i=0;i<grid_size;i++)
      fprintf (stderr,  "result[%d] = %d\n", i,result[i]);*/


}

//./fitting_error.exe ~/Images/meshes/list_362272points_bunny.txt test_triangles_coord.txt
/* =============================== */
double FittingQualityMeasureFromDots(const char *points_path, const char * triangle_path)
/* =============================== */
{
  double error = 0;
  int i, j, c;
  float step;
  float dims[3];
 float dims2[3];
  float bbox_min[3];
  float bbox_max[3];
  float bbox2_min[3];
  float bbox2_max[3];

  //reading bounding box 1 
  FILE *buffer = fopen(points_path, "r");
  float flux1, flux2, flux3;

  c = fscanf(buffer, "%f %f %f\n", &flux1, &flux2, &flux3);
  bbox_min[0]=flux1;  bbox_min[1]=flux2;  bbox_min[2]=flux3;
  bbox_max[0]=flux1;  bbox_max[1]=flux2;  bbox_max[2]=flux3;
  int nb_points = 0;
  while(c!=-1)
    {
      c = fscanf(buffer, "%f %f %f\n", &flux1, &flux2, &flux3);
      if (bbox_min[0]>flux1) bbox_min[0]=flux1;
      if (bbox_max[0]<flux1) bbox_max[0]=flux1;
      if (bbox_min[1]>flux2) bbox_min[1]=flux2;
      if (bbox_max[1]<flux2) bbox_max[1]=flux2;
      if (bbox_min[2]>flux3) bbox_min[2]=flux3;
      if (bbox_max[2]<flux3) bbox_max[2]=flux3;
      nb_points++;
    }
  fclose(buffer);
  // bbox_min[0] = -0.1;
 //reading points 1 
  float *Px= (float*)malloc(sizeof(float)*nb_points);
  float *Py= (float*)malloc(sizeof(float)*nb_points);
  float *Pz= (float*)malloc(sizeof(float)*nb_points);
  buffer = fopen(points_path, "r");
 FILE *out = fopen("check1.txt", "w");
  for(i=0;i<nb_points;i++)
    {
      fscanf(buffer, "%f %f %f\n",&flux1, &flux2, &flux3);
      Px[i]= flux1 -  bbox_min[0];
      Py[i]= flux2 -  bbox_min[1];
      Pz[i]= flux3 -  bbox_min[2];
      fprintf(out, "%f %f %f \n",Px[i], Py[i], Pz[i] );
}
  fclose(buffer);
  fclose(out);
 
  for(j = 0; j < 3; j++)
    dims[j] = (bbox_max[j]-bbox_min[j]);
  
  fprintf (stderr,  "bboxmin %f %f %f \n",  bbox_min[0],  bbox_min[1],  bbox_min[2]);
  fprintf (stderr,  "bboxmax %f %f %f \n",  bbox_max[0],  bbox_max[1],  bbox_max[2]);
 
  fprintf(stderr, "Grid dimensions: %f %f %f\n", dims[0], dims[1], dims[2]);
  
 //reading bounding box 2
  buffer = fopen(triangle_path, "r");
 
  c = fscanf(buffer, "%f %f %f,\n", &flux1, &flux2, &flux3);
  bbox2_min[0]=flux1;  bbox2_min[1]=flux2;  bbox2_min[2]=flux3;
  bbox2_max[0]=flux1;  bbox2_max[1]=flux2;  bbox2_max[2]=flux3;
  int nb_triangles=0;
  while(c!=-1)
    {
      c = fscanf(buffer, "%f %f %f,\n", &flux1, &flux2, &flux3);
    if (bbox2_min[0]>flux1) bbox2_min[0]=flux1;
      if (bbox2_max[0]<flux1) bbox2_max[0]=flux1;
      if (bbox2_min[1]>flux2) bbox2_min[1]=flux2;
      if (bbox2_max[1]<flux2) bbox2_max[1]=flux2;
      if (bbox2_min[2]>flux3) bbox2_min[2]=flux3;
      if (bbox2_max[2]<flux3) bbox2_max[2]=flux3;
      nb_triangles++;
    }
 
  fclose(buffer);
 for(j = 0; j < 3; j++)
    dims2[j] = (bbox2_max[j]-bbox2_min[j]);


 fprintf (stderr,  "bbox2min %f %f %f \n",  bbox2_min[0],  bbox2_min[1],  bbox2_min[2]);
 fprintf (stderr,  "bbox2max %f %f %f \n",  bbox2_max[0],  bbox2_max[1],  bbox2_max[2]);

 fprintf(stderr, "Grid dimensions: %f %f %f\n", dims2[0], dims2[1], dims2[2]);
//reading points 2
  float *Tx= (float*)malloc(sizeof(float)*nb_triangles);
  float *Ty= (float*)malloc(sizeof(float)*nb_triangles);
  float *Tz= (float*)malloc(sizeof(float)*nb_triangles);
  buffer = fopen(triangle_path, "r");
  float f1 =  dims[0]/dims2[2]; 
  float f2 = dims[1]/dims2[1];
  float f3 = dims[2]/dims2[0];
  float factor = dims[0]/dims2[0]; //(f2+f3)/2;
    printf("factor = %f ( %f %f %f )\n", factor, f1, f2, f3);

  out = fopen("check.txt", "w");
  for(i=0;i<nb_triangles;i++)
    {
      fscanf(buffer, "%f %f %f,\n",&flux1, &flux2, &flux3);
      Tz[i] = (flux3 - bbox2_min[2])*factor; 
      Ty[i] = (flux2 - bbox2_min[1])*factor; 
      Tx[i] = (flux1 - bbox2_min[0])*factor; 
      fprintf(out, "%f %f %f \n",Tx[i], Ty[i], Tz[i] );
    }
  fclose(buffer);
fclose(out);
  printf("nb_points = %d nb_triangles = %d \n",  nb_points, nb_triangles);
  // compute error
  float distmin, dist;
  for(i=0;i<nb_triangles;i++)
     {
       distmin = 10;
        for(j=0;j<nb_points;j++)
      
	 {
	   dist = (Tx[i] - Px[i])*(Tx[i] - Px[i])+(Ty[i] - Py[i])*(Ty[i] - Py[i]) + (Tz[i] - Pz[i])*(Tz[i] - Pz[i]);
	   if (dist <distmin) distmin=dist;
	 }
       error= error + sqrt(distmin);
     }

  float diag_BB = sqrt(dims2[0]*dims2[0]+dims2[1]*dims2[1]+dims2[2]*dims2[2]) ;
  return (error/nb_triangles)/diag_BB;

}
