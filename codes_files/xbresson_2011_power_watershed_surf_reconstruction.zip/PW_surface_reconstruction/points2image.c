#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <mccodimage.h>
#include <mcimage.h>
#include <unistd.h>


/* =============================================================== */
int main(int argc, char **argv) 
/* =============================================================== */
{
  if (argc < 5)
    {
      fprintf(stderr, "usage: %s points.txt bbox.dat resolution out_name.pgm\n", argv[0]);
      exit(1);
  }
 
  int i, j, N;
  unsigned char *tmp;
  float bbox_min[3];
  float bbox_max[3];
  int dims[3]; 
  float *p=(float*)malloc(sizeof(float)*3);
  int pt[3];
  float P[3];
  char * bbox_path = argv[2];
  FILE *inbbox, *in;
  int RESOLUTION = atoi(argv[3]);
  int32_t d=0;
  struct xvimage * image;
 
  //reading bounding box
  inbbox = fopen(bbox_path, "r");
  if(fscanf(inbbox, "%f %f %f %f %f %f", bbox_min, bbox_min+1, bbox_min+2, bbox_max, bbox_max+1, bbox_max+2) != 6)
    fprintf(stderr,"Cannot read bbox!");
  fclose(inbbox);
  
  //computing the voxel size
  float step = (bbox_max[0]-bbox_min[0])/RESOLUTION;

  for(j = 0; j < 3; j++)
    dims[j] = (int)((bbox_max[j]-bbox_min[j])/step);
    
  fprintf(stderr, "Grid dimensions: %d %d %d\n", dims[0], dims[1], dims[2]);
  N = dims[0]*dims[1]*dims[2];

  // fill the image
  in = fopen(argv[1], "rb");
  image= allocimage(NULL, dims[0], dims[1], dims[2], VFF_TYP_1_BYTE);
  tmp = UCHARDATA(image);
  for (i=0; i<N;i++)
    tmp[i]=255;

  i=0;
  
  // read points
  while(d!=-1)
    {
      d=fscanf(in, "%f %f %f ", p, p+1, p+2);
      for(j = 0; j < 3; j++)
	{
	  P[j] = (p[j]-bbox_min[j])/step;
	  pt[j] = (int)(P[j]);
	  if(pt[j] < 0) pt[j]=0;
	  if(pt[j] >= dims[j]) pt[j]=dims[j]-1;
	}
      i = pt[2]*dims[1]*dims[0]+pt[1]*dims[0]+pt[0];
      tmp[i]=0;
    }
  fclose(in);
  writeimage(image, argv[4]);
}



       

