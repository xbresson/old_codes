function I = im3Dread(image_name)
    fid = fopen(image_name, 'r');
    P = fgets(fid);  % reads the format P5 or P2
   
    %reads the comments
    d = '#';
    while strcmp(d(1),'#')==1
        d = fgets(fid); 
    end
    s = sscanf(d, '%d %d %d');
    x = s(1);
    y = s(2);
    z = s(3);
    
    %color max
    fgets(fid,4);
        
    I = zeros(x,y,z);
    
    if P(2)==50
        for k=1:z
            for i=1:y
                for j=1:x
                   I(j,i,k) = str2num(fscanf(fid, '%s ', 1));
                end
            end
        end
    else
        for k=1:z
            for i=1:y
                tmp = fread(fid, x, 'uint8');
                for j=1:x
                    I(j,i,k) = tmp(j);
                end
            end
        end
    end
    I = uint8(I);
    fclose(fid);
end