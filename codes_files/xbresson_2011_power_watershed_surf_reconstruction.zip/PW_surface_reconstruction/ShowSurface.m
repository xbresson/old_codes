%a simple script that can be used to visualize the result
%produced with Power watershed surface reconstruction code
function ShowSegmentation(image_name)

if nargin == 0
    disp('Enter the image name of the indicator of the object to display (proba.pgm)');
end

result = im3Dread(image_name);


disp('Result read. Now, extracting isosurface (may take a while)...');
[faces, vertices] = isosurface(result,0.5);


disp('Isosurface extracted. Displaying the result');

patch('Faces', faces,'Vertices', vertices,'FaceColor', [1 0 0], 'FaceLighting', 'flat',...
    'EdgeColor', 'none', 'SpecularStrength', 0, 'AmbientStrength', 0.4, 'DiffuseStrength', 0.6);

set(gca,'DataAspectRatio',[1 1 1], 'PlotBoxAspectRatio',[1 1 1],...
    'PlotBoxAspectRatioMode', 'manual');
lighting gouraud
rotate3d on;
camlight;

