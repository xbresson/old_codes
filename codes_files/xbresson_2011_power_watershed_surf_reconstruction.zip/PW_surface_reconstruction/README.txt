/*Copyright ESIEE (2011) 

Author :
Camille Couprie (c.couprie@esiee.fr)

Contributors : 
Hugues Talbot (h.talbot@esiee.fr)
Leo Grady (leo.grady@siemens.com)
Laurent Najman (l.najman@esiee.fr)

This software contains some image processing algorithms whose purpose is to be
used primarily for research.

This software is governed by the CeCILL license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.
*/
------------------------------------------------------------------------



This package contains :
- code implementing the power watershed solver described in [1]
 (Directory "sources_PWcut") with an example of simple graph 
  construction "powerwatexample.c"

- code for surface reconstruction decribed in [2] (Directory
"sources_surface_reconstruction") The main function for the shape
fitting/surface reconstruction is located in the file "powerwatsurf.c"

- lists of 3D point clouds in directory "3Dpoints", and C code to
  embed the points in a grid: "points2image.c"

To compile, type "make" To test the power watershed surface
reconstruction executable "powerwatsurf.exe", you need the followings:

- 1- a pgm image name containing a 3D image of black dots in a white volume 
- 2- a pgm image name containing seeds according the following format:

 The image indicates the space of solution research : 
 If I == 200 : foreground seed 
    I == 75   : background seed
    I == 128 : solution space
    I == 0 : ignored background space
    I == 255 : ignored foreground space

1- The 3D image containing the point cloud can be created by calling 

./points2image.exe <list_points.txt> <bbox.dat> <width of volume> <image_output_name.pgm>

Examples: 
 ./points2image.exe 3Dpoints/Bunny/list_points.txt 3Dpoints/Bunny/bbox.dat 225 bunny.pgm
./points2image.exe 3Dpoints/Dragon/list_points.txt 3Dpoints/Dragon/bbox.dat 300 dragon.pgm


2- To create a markers(=seeds) image, you can use the provided script "build_graph_seeds".
It first require the installation of the Pink image processing library available at: 
http://pinkhq.com/

Then, you can type 
./build_graph_seeds <image_name(without.pgm)> <integer_parameter>

Examples: 
./build_graph_seeds bunny 55
./build_graph_seeds dragon 35

Warning: this way to build seeds is not entirely satisfactory at the current stage, in a future work we'd like to automatically set the markers as in [3].

3- Once you have your image and the markers you can call powerwatsurf.exe.

Examples:  
./powerwatsurf.exe  bunny.pgm bunny_seeds.pgm
./powerwatsurf.exe  dragon.pgm  dragon_seeds.pgm

The result is computed in file "proba.pgm", that you can visualize using the 
3dview software from Pink.

Example: 3dview proba.pgm &

4- You can display the isosurface in matlab for example using the provided script "showSurface" from Victor Lempitsky. However the rendering can be much better using the Aviso software.

In Matlab, type:
showSurface('proba.pgm');

[1] Camille Couprie, Leo Grady, Laurent Najman, and Hugues Talbot. Power watersheds: a unifying graph based optimization framework. In IEEE Transactions
on Pattern Analysis and Machine Intelligence (IEEE PAMI), (vol. 33 no. 7),
pp. 1384-1399, July 2011.
[2] Camille Couprie, Xavier Bresson, Laurent Najman, Hugues Talbot, and Leo
Grady. Surface reconstruction using power watersheds. In Proc. of Interna-
tional Symposium on Mathematical Morphology (ISMM), 2011.
[3] V. Lempitsky and Y. Boykov. Global Optimization for Shape Fitting. In Proceedings of the 20th IEEE Conference on Computer Vision and Pattern Recognition (CVPR'2007), Minneapolis, USA, 2007.
