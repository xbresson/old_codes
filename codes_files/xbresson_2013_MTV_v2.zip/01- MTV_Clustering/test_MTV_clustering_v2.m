

function test_MTV_clustering_v2


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMMENT OR UNCOMMENT DATASET
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% WEBKB4 (4,196 data points)
load('data/WEBKB4.mat','A','C','nc');
[MTVsol,purity,energy] = MTV_clustering(A,C,nc,'WEBKB4');


% OPTDIGITS (5,620 data points)
load('data/OPTDIGITS.mat','A','C','nc');
[MTVsol,purity,energy] = MTV_clustering(A,C,nc,'OPTDIGITS');


% PENDIGITS (10,992 data points)
load('data/PENDIGITS.mat','A','C','nc');
[MTVsol,purity,energy] = MTV_clustering(A,C,nc,'PENDIGITS');


% 20NEWS (19,938 data points)
load('data/20NEWS.mat','A','C','nc');
[MTVsol,purity,energy,time] = MTV_clustering(A,C,nc,'20NEWS');


% MNIST (70,000 data points)
load('data/MNIST.mat','A','C','nc');
[MTVsol,purity,energy] = MTV_clustering(A,C,nc,'MNIST');



end







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [MTVsol,purity,energy,time] = MTV_clustering(A,Cgt,nc,name_dataset)


fprintf('\nDataset= %s, Nb data points= %i, Nb classes= %i\n\n',name_dataset,size(A,1),nc);


% Check random generator
%random_nb = randi(10^9,1,1); % to check the random number generator
%fprintf(['Random generator number= ',num2str(random_nb),'\n']);


tstart1 = tic; 


%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prepare graph weight W 
%%%%%%%%%%%%%%%%%%%%%%%%%%%
W = max(A,A');  
W = W + speye( size(W,1) ); 
W = double(W>0);
R = nc;


%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%
tol = 0.01; % perc of changed solution
speed = 25; % speed of seeding
max_steps = 50; % max number of iterations
max_time = 10 * 60; % in sec
verbose = 1; % =1 display on
   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute the number of seeds to be added per class at each iteration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n = size(W,2);
percentage_of_seeds_added_per_iteration= speed*10^(-4);
nb_of_seeds_added_per_iteration = percentage_of_seeds_added_per_iteration * n;
delta_seeds = nb_of_seeds_added_per_iteration / R;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct the random walk matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
D = sum(W,2);
invD = spdiags(1./D,0,n,n);
RW = (W*invD); 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct the gradient matrix K        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%display('Constructing the Gradient matrix and estimating its norm')
triangularW=triu(W,1);
[I, J, v]=find(triangularW);
m=length(v); %number of edges in the graph
KI=[1:m 1:m];
KJ(1:m) = I;
KJ(m+1:2*m) = J;
Kv(1:m)=v;
Kv(m+1:2*m)=-v;
K=sparse(KI,KJ,Kv,m,n);
warning('OFF');
L=normest(K);


%%%%%%%%%%%%%%%%%%
% Initialization
%%%%%%%%%%%%%%%%%%
C = randi(R,n,1);
best_C = C;
C_stored = C;
nb_of_seeds = 1;
iter = 0; 
frac_of_changed_points = 1;
comp_time = 0;
best_energy = 1e10;


%%%%%%%%%%%%%%%%%%
% MAIN LOOP
%%%%%%%%%%%%%%%%%%
while ( frac_of_changed_points>tol  &&  iter<max_steps  &&  comp_time<max_time )  
     
    
    iter=iter+1;
    
    
    % Plant
    [F,R,nb_of_seeds] = PLANT(best_C, R, nb_of_seeds);
    
    
    % Grow
    F = GROW_MTV(F,RW,K,L,Cgt);

    
    % Harvest
    [~,C] = max(F,[],2);
    
    
    % Keep the best energy
    Cheeger_en = compute_conductance(W,C)/ R* 100;
    if Cheeger_en < best_energy
        best_energy = Cheeger_en;
        best_C = C;
    end
    
    
    % Increase number of seeds
    nb_of_seeds = nb_of_seeds + delta_seeds;
    
    
    % Stopping condition
    if mod(iter,10)==0
        frac_of_changed_points = sum( C ~= C_stored    )  /  n;
        C_stored = C;
    end
    
    
    % Time
    comp_time = toc(tstart1);
    
    
    % Display
    if verbose
        if (mod(iter,1)==0 )
            % display
            prt = compute_purity(C,Cgt,R);
            Cheeger_en = compute_conductance(W,C)/ R* 100;
            display(['ITER= ' , num2str(iter), ' || TIME= ' , num2str(round(comp_time)) ,...
                ' || PERC= ' , num2str(frac_of_changed_points*100), ' || PURITY= ' , num2str(prt),...
                ' || SEEDS= ', num2str(nb_of_seeds),' || EnChe= ', num2str(Cheeger_en),...
                ' || EnBest= ', num2str(best_energy) ])
        end
    end
    
    
end



% Outputs
MTVsol = best_C;
purity = compute_purity(C,Cgt,R);
time = comp_time;
energy = best_energy;


fprintf('\nPurity= %.4f for dataset= %s\n',purity,name_dataset);

display(' ');
display('Press any key to continue to the next dataset');
display(' ');
%pause;


end






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PLANT FUNCTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [F,R,nb_of_seeds] = PLANT(C,R,nb_of_seeds)

idx_in_class=cell(R,1);
ClassSize=zeros(R,1);

for k=1:R
    idx_in_class{k} =  find(C==k);
    ClassSize(k)=length(idx_in_class{k});
end

if min(ClassSize) == 0
    class_to_be_deleted=find(ClassSize==0);
    idx_in_class(class_to_be_deleted)=[];
    ClassSize(class_to_be_deleted)=[];
    R=length(ClassSize);
end

n=length(C);
F=zeros(n,R);

nb_of_seeds=min(  min(ClassSize)  , nb_of_seeds);

for k=1:R;
    junk=randperm(ClassSize(k));
    junk=junk( 1 : floor(nb_of_seeds) );
    selected_idx = idx_in_class{k}( junk );
    F(selected_idx,k)=1;
end


end







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GROW FUNCTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Fnew = GROW_MTV(F_init,RW,K,L,Cgt)


% Diffuse these indicator function
for i=1:3 % 5
    F_init = RW * F_init; 
end


% MTV clustering [NIPS'13]
rel_tol = 0.001;
maxTime = 60; % sec
maxIter = 100; % 100
verbose = 0; %=1 display ON
[Fnew,~,~,~,~] =  MTVclust(K,L,F_init,rel_tol,maxTime,maxIter,Cgt,verbose);


end



function [F,C,Energy,Energy_tresh,iter] = MTVclust(K,L,F_init,tol,maxTime,max_iter,Cgt,verbose) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MTVclust [NIPS'13]
% Multiclass Total Variation Clustering (MTV)
% X. Bresson, T. Laurent, D. Uminsky and J.H. von Brecht
% Annual Conference on Neural Information Processing Systems (NIPS), 2013 
%
%   Find a local min of
%         TV(f_1) / B(f_1) +...+ TV(f_R) / B(f_R) 
%         where B(f)=|| f - med_lambda(f) ||_1
%   subject to the simplex constraint f_1 + ... + f_R = 1, f_1, ..., f_R >=0
%        
%   INPUT :
%       K           - the  gradient matrix of a graph (an NxN matrix)
%       L           - norm of the gradient matrix: L=normest(K)
%       F_init      - the inital guess for the R relaxed indicator functions (an NxR matrix) 
%       rel_tol     - relative tolerance for the energetic stopping criteria
%
%   OUTPUT :       
%       F      - the R relaxed indicator functions (an NxR matrix)
%       C      - the partition associated to F  (an Nx1 matrix)
%       Energy - the discrete energy of the computed partition
%       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Tstart = tic; 
[n,R] = size(F_init);              % number of data points and number of classes 
m = size(K,1);                     % number of edges in the graph 
lambda = 1/(R-1);                  % parameter for the asymetric balance term
F = Project_to_Simplex(F_init);    % project F_init on the simplex  
P = zeros(m,R);                    % initial choice for the dual variable
tau = 1/L;                         % initial choice for the time step in the inner loop


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                BEGINNING OF OUTER LOOP              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%              
%compute balance term, total variation and energy of each classes of the initial iterate                              
[H,B,E] = compute_HBE(K, lambda, F); 
[~,C_stored] = max(F_init,[],2);
frac_of_changed_points=1;
Total_Energy = 1000;
iter = 0;
flag = 0;
while( flag == 0)
    
    
    % Energy
    Delta = max(B);
    Total_Energy_old = Total_Energy;
    Total_Energy = sum(E);   % Sum of the energy of each class
    
    
    % Compute the subdifferential of the balance term
    H_plus = (H>0); n_plus = sum(H_plus,1);
    H_minus = (H<0); n_minus = sum(H_minus,1);
    H_zero = (H==0); n_zero = sum(H_zero,1);
    q = (lambda.*n_minus - n_plus)./n_zero;
    V = H_plus - bsxfun(@times,H_minus,lambda) + bsxfun(@times,H_zero,q);   % V=( v_1 , ... , v_R ) where v_i belongs to the subdifferential of B at f_i
    
    
    % forward step
    G = F + bsxfun(@times, Delta*V, E./B);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %        INNER LOOP              %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    B_outer=B; F_outer=F; E_outer=E;
    Gamma = Delta./B;
    L_tilda= max(Gamma)*L;  sigma=1/(tau*L_tilda^2);
    F_bar = F;
    innerFlag = 0;
    while ( innerFlag == 0 )
        
        iter = iter + 1;
        
        
        % Chambolle-Pock Primal Dual algorithm
        P = P + sigma * bsxfun(@times, K*F_bar, Gamma);
        P = P./max(1,abs(P));
        F_old = F;
        F = F - tau * bsxfun(@times, K'*P, Gamma);
        F = (F + tau*G)/(1+tau);
        F = Project_to_Simplex(F);
        theta=1/sqrt(1+2*tau); tau=theta*tau;  sigma=sigma/theta;
        F_bar= (1+theta) * F - theta * F_old;
        
        
        % Compute H, B, T, and E  associated to the current iterate of the PD algorithm
        [H,B,E] = compute_HBE(K, lambda, F);
        
        
        % Stopping criteria for the inner loop
        change_in_energy = sum( Delta * (B./B_outer) .* (E_outer - E)  );
        dist_btw_iterates = norm(  F - F_outer, 'fro' )^2;
        quantity = change_in_energy  - 0.999 * dist_btw_iterates;  % 0.99
        if( quantity>0 || iter>max_iter )
            innerFlag = 1;
        end
        
        
        % percentage of unchanged points for stopping condition
        if(mod(iter,10)==0)
            [~,C] = max(F,[],2);
            frac_of_changed_points = sum( C ~= C_stored ) / n;
            C_stored = C;
        end
        
        
        % time
        comp_time = toc(Tstart);
        
        
        % display
        if verbose
            if mod(iter,10)==0 % 10
                [~,C] = max(F,[],2);
                prt = compute_purity(C,Cgt,R);
                display(['INNER ITER= ' , num2str(iter), ' || TIME= ' , num2str(round(comp_time)) ,...
                    ' ||  PERC changed pts= ' , num2str(round(frac_of_changed_points*100)), ...
                    '%  ||  PURITY= ' , num2str(prt),'%',...
                    ' || En change= ' , num2str(abs(Total_Energy-Total_Energy_old)/Total_Energy)])
            end
        end
        
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %      END OF INNER LOOP  // STOPPING CREITERIA FOR OUTER LOOP         %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if( comp_time>= maxTime || iter>=max_iter || frac_of_changed_points<=tol )
        %if( abs(Total_Energy-Total_Energy_old)/Total_Energy <= rel_tol || iter>=max_iter  )
        flag = 1;
    end
    
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
%   END OF OUTER LOOP  //  COMPUTE OUTPUT VARIABLES         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[~,Classes] = max(F,[],2);
F_tresholded = sparse(1:n,Classes,1,n,R);
[~,~,E] = compute_HBE(K, lambda, F_tresholded); 
Energy_tresh = sum(E);
Energy = Total_Energy;
C = Classes;


end
 




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MTV energy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function  [H,B,E] = compute_HBE(K, lambda, F)

%Compute asymetric median of each relaxed indicator functions in F
n = size(F,1);
k = ceil(  n/(1+lambda) );
Z = sort(F,1);
M = Z(k,:);

% compute H, B ,T and E
H=bsxfun(@minus,F,M);
tilted_abs_H = H.*(H>0) - lambda*H.*(H<0);
B=sum( tilted_abs_H , 1); % row vector containing the balance term of each class
T = sum ( abs(K*F) , 1 ); % row vector containing the balance term of each class
E = T./B;                 % row vector containing the Energy for each class


end

    
    
    
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Projection on simplex
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = Project_to_Simplex(F)
% F is a matrix with N rows of length R
% Each of the N rows is projected onto the canonical simplex in R^R.  

[N,R] = size(F);
x = F;
n_I = R*ones(N,1);
I = zeros(N,R);
flag = zeros(N,R);

while(min(min(flag)) == 0)    
    y = ( sum(x,2)-1 )./n_I;
    x=bsxfun(@minus, x,y).*(1-I);
    
    flag = (x>=0);
    I = I + (x<0);
    n_I = R - sum(I,2);
    x = x.*(x>=0);   
end

    
end   



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purity
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ percentage] = compute_purity(C_computed, C_grndtruth , R)

N=length(C_grndtruth);
nb_of_dominant_points_in_class=zeros(R,1);

for k=1:R
   v= C_grndtruth( C_computed==k  ); 
   [~,nb_of_dominant_points_in_class(k)]=mode(v);
end

percentage=(sum(nb_of_dominant_points_in_class)/N)*100;

end

    




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purity
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function output = compute_conductance(W,C)

R=max(C);
N=size(W,1);
D_total=sum(W,2);
D_out=zeros(N,1);
cond_vector=zeros(R,1);

for r=1:R
    
    % idx and idx in complement
    idx=find(C==r);
    idx_comp= 1:N ;
    idx_comp( idx )=[];
    
    % compute nb of edges going out
    WW = W(idx,idx_comp);
    nb_of_edges_out=sum(WW, 2);
    
    % fill D_out
    D_out(idx)=nb_of_edges_out;
    
    % compute conductance of the class
    cut= sum( D_out(idx)    );
    vol= sum( D_total(idx)  );
    cond_vector(r)=cut/vol;
    
end

output = sum(cond_vector); 

end


