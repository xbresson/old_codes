
version 2


The following code reproduces the results introduced in
Multiclass Total Variation Clustering (MTV)
X. Bresson, T. Laurent, D. Uminsky and J.H. von Brecht, Annual Conference on Neural Information Processing Systems (NIPS), 2013 


What you need to do:

(1) Unsupervised clustering:
- Open Matlab
- Go to the folder 01- MTV_Clustering/
- Run test_MTV_clustering_v2

(2) Transductive clustering:
- Open Matlab
- Go to the folder 02- MTV_Transductive/
- Run test_MTV_transductive



Note 1: All datasets (but 4_MOONS) were taken here:
http://users.ics.aalto.fi/rozyang/nmfr/index.shtml
with the associated paper:
Zhirong Yang, Tele Hao, Onur Dikmen, Xi Chen, and Erkki Oja. "Clustering by nonnegative matrix factorization using graph random walk". In Advances in Neural Information Processing Systems (NIPS), pages 1088–1096, 2012.

Note 2: The Normalized Cut code (folder "Ncut_9") was taken here:
http://www.timotheecour.com/software/ncut/ncut.html
with the associated paper:
Jianbo Shi and Jitendra Malik, "Normalized Cuts and Image Segmentation", IEEE Transactions on Pattern Analysis and Machine Intelligence (PAMI), 2000.

Note 3: ncut.m uses different versions of "eigs":
1) Matlab version < R2013a
[vbar,s,convergence] = eigs_new(@mex_w_times_x_symmetric,size(P,1),nbEigenValues,'LA',options,tril(P)); 
2) Matlab version >= R2013a
[vbar,s,convergence] = eigs(@mex_w_times_x_symmetric,size(P,1),nbEigenValues,'LA',options,tril(P));

