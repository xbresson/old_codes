%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: 	Xavier Bresson (xbresson@math.ucla.edu)
% Last version: Aug 3, 2008
% For more information:  X. Bresson and T.F. Chan, "Fast Minimization of the
% Vectorial Total Variation Norm and Applications to Color Image Processing", CAM Report 07-25
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function dual_vectorial_ROF


close all;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loading Input Image
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Im,map] = imread('rose.jpg'); 

[Ny,Nx,Nc] = size(Im);
Im = double(Im);
Im = 255* Im/ max(max(Im(:))); % max(Im)=255

figure(1); imagesc(uint8(Im)); title('Input Image'); axis image;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adding Noise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ImRef = Im;
Im = ImRef + 0.2 *255 *randn(size(ImRef));

figure(2); imagesc(uint8(Im)); title('Noisy Input Image'); axis image;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dt = 1/8;
lambda = 1e1*6;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Iterative Denoising Scheme
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initial value
pxU = zeros(size(Im));
pyU = zeros(size(Im));
U = zeros(size(Im));
Denom = zeros(size(Im));

nb_iters = 10000;
for cpt=1:nb_iters
    
    cpt
    
    Divp = ( BackwardX(pxU) + BackwardY(pyU) );
    Term = Divp -Im/ lambda;
    Term1 = ForwardX(Term);
    Term2 = ForwardY(Term);  
    Norm = sqrt(sum(Term1.^2 + Term2.^2,3));    
    Denom(:,:,1)=1+dt*Norm; Denom(:,:,2)=Denom(:,:,1); Denom(:,:,3)=Denom(:,:,1);
    pxU = (pxU+dt*Term1)./Denom;
    pyU = (pyU+dt*Term2)./Denom;
    U = Im - lambda* Divp;

    if rem(cpt,10)==0
        figure(3); clf; imagesc(uint8(U)); title('Denoised Image'); axis image;
        pause(0.2)
        %pause
    end

end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sub Functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [dx] = BackwardX(v);

[Ny,Nx,Nc] = size(v);
dx = v;
dx(2:Ny-1,2:Nx-1,:)=( v(2:Ny-1,2:Nx-1,:) - v(2:Ny-1,1:Nx-2,:) );
dx(:,Nx,:) = -v(:,Nx-1,:);


function [dy] = BackwardY(v);

[Ny,Nx,Nc] = size(v);
dy = v;
dy(2:Ny-1,2:Nx-1,:)=( v(2:Ny-1,2:Nx-1,:) - v(1:Ny-2,2:Nx-1,:) );
dy(Ny,:,:) = -v(Ny-1,:,:);



function [dx] = ForwardX(v);

[Ny,Nx,Nc] = size(v);
dx = zeros(size(v));
dx(1:Ny-1,1:Nx-1,:)=( v(1:Ny-1,2:Nx,:) - v(1:Ny-1,1:Nx-1,:) );



function [dy] = ForwardY(v);

[Ny,Nx,Nc] = size(v);
dy = zeros(size(v));
dy(1:Ny-1,1:Nx-1,:)=( v(2:Ny,1:Nx-1,:) - v(1:Ny-1,1:Nx-1,:) );




