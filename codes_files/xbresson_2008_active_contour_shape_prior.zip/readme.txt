
Xavier Bresson - Oct. 06 2008


Active Contour using Shape Prior:
[X. Bresson, P. Vandergheynst and J.-P. Thiran, A Variational Model for Object Segmentation Using Boundary Information and Shape Prior Driven by the Mumford-Shah Functional, IJCV 68(2), 2006, p145-162.]




How to use this code ?


1- Compute the training set. (Our example uses 30 ellipses)

Open Matlab, go to the directory:
"activeContourShapePrior\1-createTrainingSetOfEllipses\"
and compile the mex function "sdfFM_mex.c" by running:
mex sdf_mex.c
Then run createTrainingSetOfEllipses


2- Compute the PCA.
Open Matlab, go to the directory:
"activeContourShapePrior\2-computePCA\"
and compile the mex function "pca_mex.c":
mex pca_mex.c nrutil.c
Then run computePCA


3- Run the active contour with shape prior code.
Open Matlab, go to the directory:
"activeContourShapePrior\3-runActiveContourShapePrior\"
and compile the mex function "acsp_mex.c" by running:
mex acsp_mex.c acsp.c acspReDistLSF.c acspBoundaryTerm.c acspShapeTerms.c acspBsplines.c acspExtensionU.c
and 
mex sdf_mex.c
Then run runActiveContourShapePrior
PS: There are two examples in runActiveContourShapePrior: ellipse_cut and ellipse_occlusion. Comment and uncomment EXAMPLE #1 or #2.



