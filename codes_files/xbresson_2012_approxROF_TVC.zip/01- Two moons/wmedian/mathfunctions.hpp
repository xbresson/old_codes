#pragma once


double betai(double a, double b, double x);
double poisspdf(double x, double lambda);
double normpdf(double x, double mu, double sigma);


