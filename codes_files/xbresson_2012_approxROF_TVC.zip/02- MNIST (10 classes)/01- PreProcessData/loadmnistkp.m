function [B At labels testlabels Va m oB oAt e]=loadmnistkp(npc,recenter);
%function [B At labels testlabels Va m oB oAt e]=loadmnistkp(npc,recenter);


NN=60000;
%NN=10000;
m=zeros(28);
numbers=LoadMNistImages('numbers');
labels=LoadMNistLabels('labels');
A=zeros(NN,784);
for k=1:NN
    clear m    
    m(:,:)=numbers(k,:,:);
    m=double(m);
    %for s=1:2
    %    m=conv2(m,ones(3)/9,'same');
    %end
    v=reshape(real(m),prod(size(m)),1);
    A(k,:)=v;
end
clear numbers;
 m=mean(A);
if recenter==1
   
    mm=repmat(m,NN,1);
    A=A-mm;
end


if npc<784
    [B e Va mt]=pcp(A,npc,0);
else 
    B=A;
    e=0;
    Va=eye(784);
end
clear A
testnumbers=LoadMNistImages('testnumbers');
testlabels=LoadMNistLabels('testlabels');
At=zeros(10000,784);


for k=1:10000
    clear tm    
    tm(:,:)=testnumbers(k,:,:);
    v=reshape(real(tm),prod(size(tm)),1);
    At(k,:)=v;
end

if recenter==1
    mm=repmat(m,10000,1);
    At=At-mm;
end
if npc<784
    At=At*Va(:,1:npc);
end
clear d
clear d2


oAt=At;
oB=B;
for k=1:NN
    B(k,:)=B(k,:)/norm(B(k,:));
end
for k=1:10000
    At(k,:)=At(k,:)/norm(At(k,:));
end