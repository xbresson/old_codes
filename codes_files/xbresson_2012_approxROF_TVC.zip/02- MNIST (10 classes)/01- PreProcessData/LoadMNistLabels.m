function [vLabels] = LoadMNistLabels( cFileName );

% Open the file.
lFileHandle = fopen( cFileName, 'r','ieee-be' );
% Check for correct file opening.
if lFileHandle == - 1
    fprintf('Sorry, I coudln''t find the file %s.',cFileName);
    return;
end;
% Load the file.
lMagicNumber = fread( lFileHandle, 1, 'int32' );
lNumberOfItems = fread( lFileHandle, 1, 'int32' );
vLabels = fread( lFileHandle,inf,'uchar' )';

return;

