


function pre_process_usps

clear




file_data = 'usps_polytech.mat';
load(file_data,'usps_test','usps_train');

% usps_train 7291 x 257
% usps_test 2007 x 257



labels = usps_test(:,1)';
T = usps_test(:,2:257);
size(labels)
size(T)


traininglabels = usps_train(:,1)';
trainingT = usps_train(:,2:257);
size(traininglabels)
size(trainingT)




npc=5; % 53
npc=25; % 26
npc=50; % 26
%npc=10; % 36
%npc=100; % 26
[B e Va mt]=pcp(trainingT,npc,0);
clear A
for k=1:size(trainingT,1)
    B(k,:)=B(k,:)/norm(B(k,:));
end
trainingT=B;
clear B


At=T*Va(:,1:npc);
for k=1:size(T,1)
    At(k,:)=At(k,:)/norm(At(k,:));
end
T=At;
clear At




file = 'file_usps.mat';
tic
save(file,'T','trainingT','labels','traininglabels');
toc




solution = labels;




figure(1); clf; s=3; A=T'; N=size(A); z=solution;
scatter(A(1,1:N(2)),A(2,1:N(2)),s*ones(1,N(2)),z,'o', 'filled'); title('ground truth');
axis off;




end









