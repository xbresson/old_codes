function [dx]=forwardx(u,Ny,Nx);

dx = zeros(Ny,Nx);
dx(1:Ny-1,1:Nx-1)=( u(1:Ny-1,2:Nx) - u(1:Ny-1,1:Nx-1) );
%dx(:,Nx) = 0;
