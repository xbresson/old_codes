function y = f_inverse_strictly_increasing_new(x,F) 

n = 1;
while 0.000000001+F(1,n) < x
       n = n+1;
end

y = n;

return