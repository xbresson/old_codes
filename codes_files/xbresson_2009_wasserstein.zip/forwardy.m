function [dy]=forwardy(u,Ny,Nx);

dy = zeros(Ny,Nx);
dy(1:Ny-1,1:Nx-1)=( u(2:Ny,1:Nx-1) - u(1:Ny-1,1:Nx-1) );
%dx(:,Nx) = 0;