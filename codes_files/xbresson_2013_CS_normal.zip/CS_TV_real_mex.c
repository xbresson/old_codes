/**************************************/
/**************************************/
/*C version of Segment2 for matlab-mex*/
/**************************************/
/**************************************/
#include "mex.h"
#include "matrix.h"
#include <math.h>
#include <complex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PI 3.141592653589793

/****************************************/
/*****************forward and backward x and y derivatives ************/
/***************** with specific boundary conditions*******************/
void Dxt( double complex *Dfx, double complex *f, int N, int n)
{
	int i;
	for(i=0; i < N-n ; i++) 
		Dfx[i] = f[i] - f[i+n];
    for(i=N-n; i < N ; i++) 
		Dfx[i] = f[i] - f[i-N+n];     
}
/****************************************/
void Dx( double complex *Dfx, double complex *f, int N, int n)
{
	int i;
	for(i=0; i < n ; i++) 
		Dfx[i] = f[i] - f[i+N-n];    
	for(i=n; i < N ; i++) 
		Dfx[i] = f[i] - f[i-n];   
}
/****************************************/
void Dyt( double complex *Dfy, double complex *f, int N, int nx, int ny)
{
	int i, j, count;
    count=0;
	for(i=0; i < ny ; i++)
    {
        for(j=0; j < nx-1 ; j++)
        {
            Dfy[count] = f[count] - f[count+1];
            count = count+1;
        }
        Dfy[count] = f[count] - f[count-nx+1];
        count = count+1;        
    }
}
/****************************************/
void Dy( double complex *Dfy, double complex *f, int N, int nx, int ny)
{
	int i, j, count;
    count=0;
	for(i=0; i < ny ; i++)
    {
        Dfy[count] = f[count] - f[count+nx-1];
        count = count + 1;
        for(j=1; j < nx ; j++)
        {
            Dfy[count] = f[count] - f[count-1];
            count = count + 1;
        }
    }
}
/***************** pixel-wise  computation of the norm****/
/**********************************************************************************/
void norm( double *z, double complex *x, double complex *y, int N)
{
	int i;
	for(i=0; i < N ; i++)
        z[i] = sqrt( x[i]*conj(x[i]) + y[i]*conj(y[i]) );
}
/*********** pixel-wise operations shrink and min_p**********/
/************************************************************/
void shrink( double complex *xs, double complex *ys, double complex *x, double complex *y, double lambda, int N)
{
	int i;
    double s;
	for(i=0; i < N ; i++)
    {
        s = sqrt( conj(x[i])*x[i] + conj(y[i])*y[i] );  
        if(s<=lambda)
        {
            xs[i] = 0;
            ys[i] = 0;
        }
        else
        {
            s = (s - lambda)/s;
            xs[i] = s*x[i];
            ys[i] = s*y[i];
        }
    }
}

/*********** FFT minimization from Euler-Lagrange************/
/************************************************************/
void create_auxFFT(double complex *auxFFT, int nx, int ny)
{
	int i,j,count=0;
    double cy;
    double anglex = 2*PI/nx;
    double angley = 2*PI/ny;
    
	for(i=1; i <= ny ; i++) 
    {
        cy = cos(angley*i);
        for(j=1; j <= nx ; j++)
        {
            auxFFT[count] = cy + cos(anglex*j) - 2;
            count = count + 1;
        }
    }
}
void ifft2( double complex *z, double complex *f, int nx, int ny, int N)
{ /*z = ifft2( fft2( f )*/
    int kk;
    mxArray *rhs[1], *lhs[1];
    double *ifftr, *iffti, *fr, *fi;
    fr = (double *) mxMalloc( N*sizeof(double) );
    fi = (double *) mxMalloc( N*sizeof(double) );

    for(kk=0; kk < N ; kk++)
    {
        fr[kk] = creal(f[kk]);
        fi[kk] = cimag(f[kk]);
    }
    rhs[0] = mxCreateDoubleMatrix(nx, ny, mxCOMPLEX);
    memmove(mxGetPr(rhs[0]),fr, sizeof(double)*N);
    memmove(mxGetPi(rhs[0]),fi, sizeof(double)*N);
    mxSetM(rhs[0], nx);
    mxSetN(rhs[0], ny);
    lhs[0] = mxCreateDoubleMatrix(nx, ny, mxCOMPLEX);
    mexCallMATLAB(1, lhs, 1, rhs, "ifft2");  
     
    ifftr = mxGetPr(lhs[0]);
    iffti = mxGetPi(lhs[0]);
    for(kk=0; kk < N ; kk++)
        z[kk] = ifftr[kk] + _Complex_I*iffti[kk];

    mxDestroyArray(rhs[0]);
    mxDestroyArray(lhs[0]); 
    mxFree(fr);
    mxFree(fi);
}
void FFTmin( double complex *z, double complex *b, double complex *K, int nx, int ny, int N)
{ /*z = ifft2( fft2( rhs )./K );*/
    int kk;
    mxArray *rhs[1], *lhs[1], *rhsb[1];
    double *fr, *fi;
    double *fftr, *ffti, *ifftr, *iffti;
    fr = (double *) mxMalloc( N*sizeof(double) );
    fi = (double *) mxMalloc( N*sizeof(double) );

    for(kk=0; kk < N ; kk++)
    {
        fr[kk] = creal(b[kk]);
        fi[kk] = cimag(b[kk]);
    }
    rhs[0] = mxCreateDoubleMatrix(nx, ny, mxCOMPLEX);
    memmove(mxGetPr(rhs[0]),fr,sizeof(double)*N);
    memmove(mxGetPi(rhs[0]),fi,sizeof(double)*N);
    mxSetM(rhs[0], nx);
    mxSetN(rhs[0], ny);
    lhs[0] = mxCreateDoubleMatrix(nx, ny, mxCOMPLEX);
    mexCallMATLAB(1, lhs, 1, rhs, "fft2");      
    fftr = mxGetPr(lhs[0]);
    ffti = mxGetPi(lhs[0]);
    
    for(kk=0; kk < N ; kk++)
    {
        fftr[kk] = fftr[kk]/K[kk];
        ffti[kk] = ffti[kk]/K[kk];
    }
    
    rhsb[0] = mxCreateDoubleMatrix(nx, ny, mxCOMPLEX);
    memmove(mxGetPr(rhsb[0]),fftr,sizeof(double)*N);
    memmove(mxGetPi(rhsb[0]),ffti,sizeof(double)*N);
    mxSetM(rhsb[0], nx);
    mxSetN(rhsb[0], ny);
    mexCallMATLAB(1, lhs, 1, rhsb, "ifft2");
    ifftr = mxGetPr(lhs[0]);
    iffti = mxGetPi(lhs[0]);
    for(kk=0; kk < N ; kk++)
        z[kk] = ifftr[kk];/* + _Complex_I*iffti[kk];*/

    mxDestroyArray(rhs[0]);
    mxDestroyArray(lhs[0]); 
    mxDestroyArray(rhsb[0]);
    mxFree(fr);
    mxFree(fi);
}
/***************** l1, l2 norms ****/
/**********************************************************************************/
double l1norm( double complex *x, int N)
{
	int i;
    double z = 0;
	for(i=0; i < N ; i++)
        z = z + sqrt( x[i]*conj(x[i]));
    return z;
}
double l1norm_vect( double complex *x, double complex *y, int N)
{
	int i;
    double z = 0;
	for(i=0; i < N ; i++)
        z = z + sqrt( x[i]*conj(x[i]) + y[i]*conj(y[i]) );
    return z;
}
double l2norm( double complex *x, int N)
{
	int i;
    double z = 0;
	for(i=0; i < N ; i++)
        z = z + x[i]*conj(x[i]);
    z = sqrt(z);
    return z;
}
double sqr_l2norm( double complex *x, int N)
{
	int i;
    double z = 0;
	for(i=0; i < N ; i++)
        z = z + x[i]*conj(x[i]);
    return z;
}
double CS_term( double complex *u, double *R, double complex *f, int nx, int ny, int N)
{
    int kk;
    double z;
    double complex aux;
    mxArray *rhs[1], *lhs[1];
    double *fftr, *ffti, *ur, *ui;
    ur = (double *) mxMalloc( N*sizeof(double) );
    ui = (double *) mxMalloc( N*sizeof(double) );

    for(kk=0; kk < N ; kk++)
    {
        ur[kk] = creal(u[kk])/sqrt(N);
        ui[kk] = cimag(u[kk])/sqrt(N);
    }
    rhs[0] = mxCreateDoubleMatrix(nx, ny, mxCOMPLEX);
    memmove(mxGetPr(rhs[0]),ur, sizeof(double)*N);
    memmove(mxGetPi(rhs[0]),ui, sizeof(double)*N);
    mxSetM(rhs[0], nx);
    mxSetN(rhs[0], ny);
    lhs[0] = mxCreateDoubleMatrix(nx, ny, mxCOMPLEX);
    mexCallMATLAB(1, lhs, 1, rhs, "fft2");  
     
    fftr = mxGetPr(lhs[0]);
    ffti = mxGetPi(lhs[0]);
    z = 0;
    for(kk=0; kk < N ; kk++)
    {
        aux = R[kk]*(fftr[kk] + _Complex_I*ffti[kk]) - f[kk];
        z = z + aux*conj(aux);
    }

    mxDestroyArray(rhs[0]);
    mxDestroyArray(lhs[0]); 
    mxFree(ur);
    mxFree(ui);    

    return z;
}
/***********************main function***************************/
/***************** analogue to matlab file *********************/
void CS_TV(double complex *u, double *Energy, double *res, double *R, double complex *f, double alpha, double rd, int nAL, int nx, int ny, int N )
{ 
    int kk, iAL;
    double resx, resy, l2deltau, l2u;
    double complex *ux = (double complex *) mxMalloc( N*sizeof(double complex) );
    double complex *uy = (double complex *) mxMalloc( N*sizeof(double complex) );     
    double complex *upast = (double complex *) mxMalloc( N*sizeof(double complex) );
    double complex *rhs = (double complex *) mxMalloc( N*sizeof(double complex) );   
    double complex *rhsx = (double complex *) mxMalloc( N*sizeof(double complex) ); 
    double complex *rhsy = (double complex *) mxMalloc( N*sizeof(double complex) );
    double complex *bx = (double complex *) mxMalloc( N*sizeof(double complex) ); 
    double complex *by = (double complex *) mxMalloc( N*sizeof(double complex) );
    double complex *rhs0 = (double complex *) mxMalloc( N*sizeof(double complex) ); 
    double complex *K = (double complex *) mxMalloc( N*sizeof(double complex) ); 

    
    /* variables for efficient FFT computations from real data -> exploit symmetry on DFT domain*/  
    double complex *auxFFT = (double complex *) mxMalloc(N*sizeof(double complex));
    create_auxFFT(auxFFT,nx,ny);
    
    /* set the value of parameters and auxiliaries derived from them*/
    double epsilon = alpha/10;
    double fftscale = sqrt(N);
    double rdinv = 1.0/rd;

    /* initialize variables*/
    for(kk=0; kk < N ; kk++)
        u[kk] = 0;
    memmove(upast,u,N*sizeof(double complex));
    
    /*initialize Lagrange multipliers and splitting variables*/    
    double complex *ldx, *ldy;
    /*calloc initializes to zero*/
    ldx = (double complex *) mxCalloc( N, sizeof(double complex) );
    ldy = (double complex *) mxCalloc( N, sizeof(double complex) );
        
    double complex *dx, *dy;
    /*malloc sets no initial value of memory*/
    dx = (double complex *) mxMalloc( N*sizeof(double complex) );
    Dx( dx, u, N, nx );    
    dy = (double complex *) mxMalloc( N*sizeof(double complex) );
    Dy( dy, u, N, nx, ny ); 
    
    /*set the value of variables fixed on the loop*/
    for(kk=0; kk < N ; kk++)
        bx[kk] = R[kk]*f[kk];
    ifft2(by, bx, nx, ny, N);
    for(kk=0; kk < N ; kk++)
    {
        K[kk] = epsilon + alpha*R[kk] - 2*rd*auxFFT[kk];
        rhs0[kk] =  alpha*fftscale*by[kk];
    }
    
    
    for (iAL = 0; iAL < nAL; iAL++)
    {
       /* minimization w.r.t u */     
        for(kk=0; kk < N ; kk++)
        {
            bx[kk] = rd*dx[kk] + ldx[kk];
            by[kk] = rd*dy[kk] + ldy[kk];
        }
        Dxt(rhsx, bx, N, nx);
        Dyt(rhsy, by, N, nx, ny);
        for(kk=0; kk < N ; kk++)
            rhs[kk] = rhs0[kk] + rhsx[kk] + rhsy[kk] + epsilon*u[kk];
        FFTmin(u, rhs, K, nx, ny, N);
        
        
       /*minimization w.r.t d*/
        Dx(ux, u, N, nx);
        Dy(uy, u, N, nx, ny);
        for(kk=0; kk < N ; kk++)
        {
            bx[kk] = ux[kk] - rdinv*ldx[kk];
            by[kk] = uy[kk] - rdinv*ldy[kk];
        }        
        shrink(dx, dy, bx, by, rdinv, N);
   
        /*update Lagrange multipliers, compute residual and l2-norms*/
        l2deltau = 0; l2u = 0; res[iAL] = 0; Energy[iAL] = 0;
        for(kk=0; kk < N ; kk++)
        {
            resx = dx[kk] - ux[kk];
            resy = dy[kk] - uy[kk];
            ldx[kk] = ldx[kk] + rd*resx;
            ldy[kk] = ldy[kk] + rd*resy;
            
            res[iAL] = res[iAL] + resx*resx + resy*resy;
            Energy[iAL] = Energy[iAL] + sqrt( ux[kk]*conj(ux[kk]) +  uy[kk]*conj(uy[kk]) );
            l2u = l2u + u[kk]*u[kk];
            l2deltau = l2deltau + (u[kk] - upast[kk])*(u[kk] - upast[kk]);
            upast[kk] = u[kk];
        }  
        
        res[iAL] = sqrt(res[iAL])/N; l2u = sqrt(l2u)/N; l2deltau = sqrt(l2deltau)/N;
        Energy[iAL] =  ( Energy[iAL] + CS_term(u,R,f,nx,ny,N) )/N;
        if( iAL>0 )
            if( (res[iAL]>1e-3) && ( (res[iAL-1]-res[iAL])/res[iAL] < 0.25 ) )
            {
                rd = rd*2;
                rdinv = 1.0/rd;
            }        
        if( ( res[iAL]<1e-3 ) && ( l2deltau<1e-5 ) && ( l2deltau/l2u < 1e-5) )
        {
            mexPrintf("stoped at iteration %d\n",iAL);
            break;
        }

    }

    mxFree(ux);
    mxFree(uy);  
    mxFree(bx);
    mxFree(by);
    mxFree(rhs);
    mxFree(rhs0);
    mxFree(rhsx);
    mxFree(rhsy);
    mxFree(K);  
    mxFree(ldx);
    mxFree(ldy);
    mxFree(auxFFT);
  
}
/****************************************/
/* gateway function */
/****************************************/
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{

    int nx, ny, N, kk, nAL, nnzR;
    nAL = 10000;
    double alpha, rd;
    double complex *f;
    double complex *u;
    double *R, *fr, *fi, *ur, *Energy, *res;

    nx = mxGetM(prhs[0]);
    ny = mxGetN(prhs[0]);
    N = nx*ny;
    
    /*Input variables from matlab*/
    R = mxGetPr(prhs[0]); 
    fr = mxGetPr(prhs[1]);
    fi = mxGetPi(prhs[1]);
    alpha = mxGetScalar(prhs[2]); 
    rd = mxGetScalar(prhs[3]);
    /*create complex variables for f and u*/
    
    f = (double complex *) mxMalloc(N*sizeof(double complex)); 
    u = (double complex *) mxCalloc( N, sizeof(double complex) ); 
    plhs[1] = mxCreateDoubleMatrix(1, nAL, mxREAL);
    plhs[2] = mxCreateDoubleMatrix(1, nAL, mxREAL);
    Energy = mxGetPr(plhs[1]);
    res = mxGetPr(plhs[2]);  
    nnzR = 0;
    for(kk=0; kk < N ; kk++)
    {
        f[kk] = fr[kk] + _Complex_I*fi[kk];
        nnzR = nnzR + R[kk];
    }
    
     /*Create and link to output matlab variables*/
    plhs[0] = mxCreateDoubleMatrix(nx, ny, mxREAL);
    ur= mxGetPr(plhs[0]);
    /*Call the segmentation function in C*/
    CS_TV(u, Energy, res, R, f, alpha*sqrt(N)/nnzR, rd, nAL, nx, ny, N );
  
    for(kk=0; kk < N ; kk++)
        ur[kk] = creal(u[kk]);
    
    mxFree(f);
    mxFree(u);
    
    return;
}
