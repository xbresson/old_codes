function [DivN, w_edge, normfx, normfy] = estimate_Normals(u,mu,verb)
if nargin<3
    verb = 0;
end;
EPSILON = 1e-6;
[Ny,Nx] = size(u);
N = Ny*Nx;


% compute spatial derivatives and its norm pixel-wise
Dfxu = Dx(u); Dfyu = Dy(u);
nDu = sqrt(  EPSILON + conj(Dfxu).*Dfxu + conj(Dfyu).*Dfyu ); 

% Tuckey edge detector from 
% M. J. Black, G. Sapiro, D. H. Marimont, and D. Heeger, ?Robust anisotropic diffusion,? IEEE Transactions on Image Processing, vol. 7, no. 3, pp. 421?432, Jan. 1998.
med_nDu = median(nDu(:));
nDu_centered = sqrt( conj(Dfxu - med_nDu).*(Dfxu - med_nDu) + conj(Dfyu - med_nDu).*(Dfyu - med_nDu) );
sigma_e = 1.4826*median( nDu_centered(:) );
w_edge= g_t(nDu,sigma_e); 
mx = max(w_edge(:)); mn = min(w_edge(:));
if(mx>(mn+1e-3))
    w_edge = (w_edge-mn)/(mx-mn);
else
    w_edge = ones(Ny,Nx);
end;


% compute normals by normalizing spatial gradients
normf0x = Dfxu./nDu;
normf0y = Dfyu./nDu;


% mask normals with edge detector
mask_edge= 1 - w_edge; 
w_edge = w_edge + 1.0;

if verb
    figure(101); clf;
    subplot(121); imagesc(u); hold on; quiver(normf0x,normf0y); title('normals before denoising'); colormap(gray);
    pause(0.01);
end;


% % denoise normals with ROF
[normfx, normfy] = normal_wROF_mex(normf0x, normf0y, w_edge, mu);


%compute divergence
DivN = Dxt(normfx) + Dyt(normfy);

if verb
    figure(101);
    subplot(122); imagesc(u); hold on; quiver(normfx,normfy); title('estimated normals'); colormap(gray);
    pause(0.01);
end;



% finite difference approximation to spatial derivatives
function d = Dx(u)
[rows,cols] = size(u); 
d = zeros(rows,cols);
d(:,2:cols) = u(:,2:cols)-u(:,1:cols-1);
d(:,1) = u(:,1)-u(:,cols);
return

function d = Dxt(u)
[rows,cols] = size(u); 
d = zeros(rows,cols);
d(:,1:cols-1) = u(:,1:cols-1)-u(:,2:cols);
d(:,cols) = u(:,cols)-u(:,1);
return

function d = Dy(u)
[rows,cols] = size(u); 
d = zeros(rows,cols);
d(2:rows,:) = u(2:rows,:)-u(1:rows-1,:);
ud(1,:) = u(1,:)-u(rows,:);
return

function d = Dyt(u)
[rows,cols] = size(u); 
d = zeros(rows,cols);
d(1:rows-1,:) = u(1:rows-1,:)-u(2:rows,:);
d(rows,:) = u(rows,:)-u(1,:);
return


% Tuckey edge detector
function g = g_t(x,sigma)
cond = ( abs(x) <= sigma );
g = 1/2*( ( 1 - (x/sigma).^2 ).^2 ).*cond ;
return