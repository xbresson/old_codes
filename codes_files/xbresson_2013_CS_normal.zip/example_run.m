%
% This code provides the algorithms described in the paper: V. Estellers, J.-P. Thiran, X. Bresson, 
% 'Enhanced Compressed Sensing Recovery with Level Set Normals', IEEE Transactions on Image Processing.
% I am happy to share my code and ideas. If you find them useful, please acknowledge them and help the open-source community to grow.
% V. Estellers
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code requierements:
% - For the non local reconstruction methods, it is necessary to use the nearest neighbours search.
%   I use the open library TSTtool (http://www.physik3.gwdg.de/tstool/index.html) to that purpose.
% 
% - For the non local methods, it is convenient to save some auxiliary variables (the weights
%   associated with the non local operators). This is done in folde 'graph_data'.
%   For this reason the first time you will have to run: 
%     > mkdir('graph_data');
%     
% - For speed-up some functions are coded in c, so the first time you will have to run
%     > mex CS_TV_real_mex.c
%     > mex CS_TVN_real_mex.c
%     > mex normal_WROF_mex.c
%   Non mex code is available upon request.
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%first run
mkdir('graph_data');
mex CS_TV_real_mex.c;
mex CS_TVN_real_mex.c;
mex normal_WROF_mex.c;

N = 128;


sampling  = 2; % 1 for uniform; 2 for radial
sparsity = 12; 
nSpecLines = 8;

image = phantom(N);
%normalize image to range [0 1]
image = ( image - min(image(:)) )/( max(image(:)) - min(image(:)) );


if(sampling == 1)
    R = rand(N,N);
    R = double(R<sparsity/100);
else
    [R, sparsity] = MRImask(N,nSpecLines);
end;


%compressed sensing samples (normalized fft2)
f = R.*fft2(image)/N;

% result obtained by backprojection
ubp = real(ifft2(f))*N; snr_bp = snr(real(ubp),image); 

% draw results
clf
figure(1); 
subplot(211); imagesc(image); colormap('gray'); title('original image'); axis off
subplot(212); imagesc(ubp); colormap('gray'); title(['back-projection ' num2str(snr_bp) ' dB']); axis off
pause(0.1);



%%%%%%%%%% local methods

% TV reconstruction
[u_TV, Energy, res] = CS_TV_real_mex(R, f, 0.5e5, 10); snr_TV = snr(u_TV,image);

% enhanced CS with Level Set Normals -- Local version
[u_TVN, snr_TVN, DivN] = CS_TVN_it(R, f, image, u_TV, 0.5e5, 1.6, 10, 5.3);

% draw results
figure(2); clf
subplot(221); imagesc(u_TV); colormap('gray'); title(['TV reconstruction ' num2str(snr_TV) ' dB']); axis off
subplot(222); imagesc(u_TVN); colormap('gray'); title(['Enhanced CS with Level Set Normals -- Local version ' num2str(snr_TVN) ' dB']); axis off
pause(0.1);


%%%%%%%%%% Non local methods


% Initialize Non Local methods with TV solution -> compute NL weights from TV solution and save them in file 'phantom_u_TV'
Dgraph(u_TV,'phantom_u_TV');

% Non Local TV reconstruction
[u_NL_TV, snr_NL_TV] = NL_CS_TV(R, f, image, u_TV, 5e7, 10, 10, 'phantom_u_TV');

% enhanced CS with Level Set Normals -- Non Local version
[u_NL_TVN, snr_NL_TVN] = NL_CS_TVN(R, f, image, u_TV, 5e7, 0.9, 10, 10, 3.9, 'phantom_u_TV');


% draw results
subplot(223); imagesc(real(u_NL_TV)); colormap('gray'); title(['Non Local TV reconstruction ' num2str(snr_NL_TV) ' dB']); axis off
subplot(224); imagesc(real(u_NL_TVN)); colormap('gray'); title(['Enhanced CS with Level Set Normals -- Non Local version ' num2str(snr_NL_TVN) ' dB']); axis off

