/**************************************/
/**************************************/
/*C version of Segment2 for matlab-mex*/
/**************************************/
/**************************************/
#include "mex.h"
#include "matrix.h"
#include <math.h>
#include <complex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PI 3.141592653589793

void Dxt( double *Dfx, double *f, int N, int n)
{
	int i;
	for(i=0; i < N-n ; i++) 
		Dfx[i] = f[i] - f[i+n];
    for(i=N-n; i < N ; i++) 
		Dfx[i] = f[i] - f[i-N+n];     
}
/****************************************/
void Dx( double *Dfx, double *f, int N, int n)
{
	int i;
	for(i=0; i < n ; i++) 
		Dfx[i] = f[i] - f[i+n-1];    
	for(i=n; i < N ; i++) 
		Dfx[i] = f[i] - f[i-n];   
}
/****************************************/
void Dyt( double *Dfy, double *f, int N, int nx, int ny)
{
	int i, j, count;
    count=0;
	for(i=0; i < ny ; i++)
    {
        for(j=0; j < nx-1 ; j++)
        {
            Dfy[count] = f[count] - f[count+1];
            count = count+1;
        }
        Dfy[count] = f[count] - f[count-nx+1];
        count = count+1;        
    }
}
/****************************************/
void Dy( double *Dfy, double *f, int N, int nx, int ny)
{
	int i, j, count;
    count=0;
	for(i=0; i < ny ; i++)
    {
        Dfy[count] = f[count] - f[count+nx-1];
        for(j=1; j < nx ; j++)
        {
            count = i*nx + j;
            Dfy[count] = f[count] - f[count-1];
        }
    }
}

/*********** pixel-wise operations shrink and min_p**********/
/************************************************************/
void shrink( double *x1s, double *y1s, double *x2s, double *y2s, double *x1, double *y1, double *x2, double *y2, double *wlambda, int N)
{
	int i;
    double aux, lambda;
	for(i=0; i < N ; i++)
    {
        lambda  = wlambda[i];
        aux = sqrt( x1[i]*x1[i] + y1[i]*y1[i] + x2[i]*x2[i] + y2[i]*y2[i] + 1e-9 );
        if(aux<=lambda)
        {
            x1s[i] = 0;
            y1s[i] = 0;
            x2s[i] = 0;
            y2s[i] = 0;           
        }
        else
        {
            x1s[i] = (aux-lambda)/aux * x1[i];
            y1s[i] = (aux-lambda)/aux * y1[i];
            x2s[i] = (aux-lambda)/aux * x2[i];
            y2s[i] = (aux-lambda)/aux * y2[i];            
        }
    }
}
/*********** FFT minimization from Euler-Lagrange************/
/************************************************************/
void create_auxFFT(double *auxFFT, int nx, int ny)
{
	int i,j,count=0;
    double cy;
    double anglex = 2*PI/nx;
    double angley = 2*PI/ny;
    
	for(i=1; i <= ny ; i++) 
    {
        cy = cos(angley*i);
        for(j=1; j <= nx ; j++)
        {
            auxFFT[count] = cy + cos(anglex*j) - 2;
            count = count + 1;
        }
    }
}
void FFTmin( double *z, double *b, double *K, int nx, int ny, int N)
{ /*z = real(ifft2( fft2( b )./K ));*/
    int kk;
    double aux;
    mxArray *rhs[1], *lhs[1], *rhsb[1];
    double *fftr, *ffti, *fftrr, *fftii;

    rhs[0] = mxCreateDoubleMatrix(nx, ny, mxREAL);
    memmove(mxGetPr(rhs[0]),b,sizeof(double)*N);
    mxSetM(rhs[0], nx);
    mxSetN(rhs[0], ny);
    lhs[0] = mxCreateDoubleMatrix(nx, ny, mxCOMPLEX);
    mexCallMATLAB(1, lhs, 1, rhs, "fft2");  
     
    fftr = mxGetPr(lhs[0]);
    fftrr = (double *) mxMalloc(N*sizeof(double));
    ffti = mxGetPi(lhs[0]);
    fftii = (double *) mxMalloc(N*sizeof(double));
    for(kk=0; kk < N ; kk++)
    {
        fftrr[kk] = fftr[kk]/K[kk];
        fftii[kk] = ffti[kk]/K[kk];
    }
    
    rhsb[0] = mxCreateDoubleMatrix(nx, ny, mxCOMPLEX);
    memmove(mxGetPr(rhsb[0]),fftrr,sizeof(double)*N);
    memmove(mxGetPi(rhsb[0]),fftii,sizeof(double)*N);
    mxSetM(rhsb[0], nx);
    mxSetN(rhsb[0], ny);
    mexCallMATLAB(1, lhs, 1, rhsb, "ifft2");
    memmove(z,mxGetPr(lhs[0]),sizeof(double)*N);

    mxDestroyArray(rhs[0]);
    mxDestroyArray(lhs[0]); 
    mxDestroyArray(rhsb[0]);
}
/***********************main function***************************/
/***************** analogue to matlab file *********************/
void normal_wROF(double *u1, double *u2, double *u01, double *u02, double * w, double mu, int nx, int ny, int N )
{ 
    int iAL, kk;
    double z1, z2, nz;
    double res, resv, res1x, res1y, res2x, res2y, resv1, resv2, l2deltau, l2u, res_past, resv_past;   
    double *u1x = (double *) mxMalloc( N*sizeof(double) );
    double *u1y = (double *) mxMalloc( N*sizeof(double) );  
    double *u2x = (double *) mxMalloc( N*sizeof(double) );
    double *u2y = (double *) mxMalloc( N*sizeof(double) );  
    double *u1past = (double *) mxMalloc( N*sizeof(double) );
    double *u2past = (double *) mxMalloc( N*sizeof(double) );
    double *rhs1 = (double *) mxMalloc( N*sizeof(double) ); 
    double *rhs2 = (double *) mxMalloc( N*sizeof(double) );   
    double *rhs1x = (double *) mxMalloc( N*sizeof(double) ); 
    double *rhs1y = (double *) mxMalloc( N*sizeof(double) );
    double *rhs2x = (double *) mxMalloc( N*sizeof(double) ); 
    double *rhs2y = (double *) mxMalloc( N*sizeof(double) );    
    double *b1x = (double *) mxMalloc( N*sizeof(double) ); 
    double *b1y = (double *) mxMalloc( N*sizeof(double) );
    double *b2x = (double *) mxMalloc( N*sizeof(double) ); 
    double *b2y = (double *) mxMalloc( N*sizeof(double) ); 
    double *wrdinv = (double *) mxMalloc( N*sizeof(double) );
    
   
    /* variables for efficient FFT computations from real data -> exploit symmetry on DFT domain*/  
    double *auxFFT = (double *) mxMalloc(N*sizeof(double));
    double *K = (double *) mxMalloc(N*sizeof(double));
    create_auxFFT(auxFFT,nx,ny);
    
    /* set the value of parameters and auxiliaries derived from them*/
    int nAL = 500;
    double rd = mu;
    double rv = mu;
    double rdinv = 1.0/rd;
    
    /*initialize Lagrange multipliers and splitting variables*/    
    double *ld1x, *ld1y, *ld2x, *ld2y, *lv1, *lv2;
    /*calloc initializes to zero*/
    ld1x = (double *) mxCalloc( N, sizeof(double) );
    ld1y = (double *) mxCalloc( N, sizeof(double) );
    ld2x = (double *) mxCalloc( N, sizeof(double) );
    ld2y = (double *) mxCalloc( N, sizeof(double) );
    lv1 = (double *) mxCalloc( N, sizeof(double) );
    lv2 = (double *) mxCalloc( N, sizeof(double) );
    
    /*mexPrintf("lagrange multipliers created and initialized\n");*/
    
    double *d1x, *d1y, *d2x, *d2y, *v1, *v2 ;
    /*malloc sets no initial value of memory*/
    d1x = (double *) mxMalloc( N*sizeof(double) );
    Dx( d1x, u1, N, nx );    
    d1y = (double *) mxMalloc( N*sizeof(double) );
    Dy( d1y, u1, N, nx, ny ); 
    d2x = (double *) mxMalloc( N*sizeof(double) );
    Dx( d2x, u2, N, nx );    
    d2y = (double *) mxMalloc( N*sizeof(double) );
    Dy( d2y, u2, N, nx, ny );    
        /*calloc initializes to zero
    d1x = (double *) mxCalloc( N, sizeof(double) );
    d1y = (double *) mxCalloc( N, sizeof(double) );
    d2x = (double *) mxCalloc( N, sizeof(double) );
    d2y = (double *) mxCalloc( N, sizeof(double) );*/
    v1 = (double *) mxCalloc( N, sizeof(double) );
    v2 = (double *) mxCalloc( N, sizeof(double) );
    memmove(v1,u01,sizeof(double)*N);
    memmove(v2,u02,sizeof(double)*N);
    memmove(u1,u01,sizeof(double)*N);
    memmove(u2,u02,sizeof(double)*N);
    memmove(u1past,u1,sizeof(double)*N);
    memmove(u2past,u2,sizeof(double)*N);
    
    for(kk=0; kk < N ; kk++)
    {      
        K[kk] = mu + rv - 2*rd*auxFFT[kk];
        wrdinv[kk] = w[kk]*rdinv;
    }

    for (iAL = 0; iAL < nAL; iAL++)
    {
        /*minimization w.r.t u*/       
        for(kk=0; kk < N ; kk++)
        {
            b1x[kk] = rd*d1x[kk] + ld1x[kk];
            b1y[kk] = rd*d1y[kk] + ld1y[kk];
            b2x[kk] = rd*d2x[kk] + ld2x[kk];
            b2y[kk] = rd*d2y[kk] + ld2y[kk];            
        }
        Dxt(rhs1x, b1x, N, nx);
        Dyt(rhs1y, b1y, N, nx, ny);
        Dxt(rhs2x, b2x, N, nx);
        Dyt(rhs2y, b2y, N, nx, ny);        
        for(kk=0; kk < N ; kk++)
        {
            rhs1[kk] = mu*u01[kk] + rv*v1[kk] + rhs1x[kk] + rhs1y[kk];
            rhs2[kk] = mu*u02[kk] + rv*v2[kk] + rhs2x[kk] + rhs2y[kk];
        }
        FFTmin(u1, rhs1, K, nx, ny, N);
        FFTmin(u2, rhs2, K, nx, ny, N);
        
        /*minimization w.r.t v*/
        for(kk=0; kk < N ; kk++)
        {
            z1 = u1[kk] + lv1[kk]/rv;
            z2 = u2[kk] + lv2[kk]/rv;
            nz = sqrt( z1*z1 + z2*z2 );
            if(nz<1)
            {
                v1[kk] = z1;
                v2[kk] = z2;  
            }
            else
            {
                v1[kk] = z1/nz;
                v2[kk] = z2/nz;                
            }
        }
        
        /*minimization w.r.t d*/
        Dx(u1x, u1, N, nx);
        Dy(u1y, u1, N, nx, ny);
        Dx(u2x, u2, N, nx);
        Dy(u2y, u2, N, nx, ny);
        for(kk=0; kk < N ; kk++)
        {
            b1x[kk] = u1x[kk] - rdinv*ld1x[kk];
            b1y[kk] = u1y[kk] - rdinv*ld1y[kk];
            b2x[kk] = u2x[kk] - rdinv*ld2x[kk];
            b2y[kk] = u2y[kk] - rdinv*ld2y[kk];            
        }        
        shrink(d1x, d1y, d2x, d2y, b1x, b1y, b2x, b2y, wrdinv, N);
   
        /*update Lagrange multipliers, compute residual and l2-norms*/
        res = 0; resv = 0; l2deltau = 0; l2u = 0;
        for(kk=0; kk < N ; kk++)
        {
            res1x = d1x[kk] - u1x[kk];
            res1y = d1y[kk] - u1y[kk];
            res2x = d2x[kk] - u2x[kk];
            res2y = d2y[kk] - u2y[kk];
            resv1 = u1[kk] - v1[kk];
            resv2 = u2[kk] - v2[kk];
            ld1x[kk] = ld1x[kk] + rd*res1x;
            ld1y[kk] = ld1y[kk] + rd*res1y;
            ld2x[kk] = ld2x[kk] + rd*res2x;
            ld2y[kk] = ld2y[kk] + rd*res2y;
            lv1[kk] = lv1[kk] + rv*resv1;
            lv2[kk] = lv2[kk] + rv*resv2;
            
            res = res + res1x*res1x + res1y*res1y + res2x*res2x + res2y*res2y;
            resv = resv + resv1*resv1 + resv2*resv2;
            l2u = l2u + u1[kk]*u1[kk] + u2[kk]*u2[kk];
            l2deltau = l2deltau + (u1[kk] - u1past[kk])*(u1[kk] - u1past[kk]) + (u2[kk] - u2past[kk])*(u2[kk] - u2past[kk]);
            u1past[kk] = u1[kk];
            u2past[kk] = u2[kk];        
        }   
        res = sqrt(res)/N; resv = sqrt(resv)/N; l2deltau = sqrt(l2deltau)/N; l2u = sqrt(l2u)/N;
 /*       if( iAL>0 )
        {
            if( (res>1e-3) && ( (res_past-res)/res < 0.25 ) )
            {
                mexPrintf("rd increased to %f\n",rd);
                rd = rd*2;
                rdinv = 1.0/rd;
            } 
             if( (resv>1e-3) && ( abs((resv_past-resv)/resv) < 0.25 ) )
            {
                mexPrintf("rv increased to %f\n",rv);
                rv = rv*2;
            }            
        }
        res_past = res;
        resv_past = resv;*/
        if( ( res <= 1e-3 ) && ( resv <= 1e-3 ) && ( l2deltau <= 1e-6 ) && ( l2deltau/l2u <= 1e-5) )
        {
            mexPrintf("normal wROF stoped at iteration %d\n",iAL);
            break;
        }

    } 
        
    if(iAL>nAL-2)
    {
        memmove(u1,u01,sizeof(double)*N);
        memmove(u2,u02,sizeof(double)*N);   
    }
    mxFree(wrdinv);
    mxFree(u1past);
    mxFree(u2past);
    mxFree(d1x);
    mxFree(d1y); 
    mxFree(d2x);
    mxFree(d2y);  
    mxFree(v1);
    mxFree(v2); 
    mxFree(u1x);
    mxFree(u1y);  
    mxFree(b1x);
    mxFree(b1y);
    mxFree(rhs1);
    mxFree(rhs1x);
    mxFree(rhs1y);  
    mxFree(ld1x);
    mxFree(ld1y);
    mxFree(u2x);
    mxFree(u2y);  
    mxFree(b2x);
    mxFree(b2y);
    mxFree(rhs2);
    mxFree(rhs2x);
    mxFree(rhs2y);  
    mxFree(ld2x);
    mxFree(ld2y);    
    mxFree(K);
    mxFree(auxFFT);
  
}
/****************************************/
/* gateway function */
/****************************************/
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{

    int nx, ny, N;
    double mu;
    double *u1, *u2, *u01, *u02, *w;

    nx = mxGetM(prhs[0]);
    ny = mxGetN(prhs[0]);
    N = nx*ny;
    
    /*Input variables from matlab*/
    u01 = mxGetPr(prhs[0]); 
    u02 = mxGetPr(prhs[1]);
    w = mxGetPr(prhs[2]);
    mu = mxGetScalar(prhs[3]); 

     /*Create and link to output matlab variables*/
    plhs[0] = mxCreateDoubleMatrix(nx, ny, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(nx, ny, mxREAL);
    u1= mxGetPr(plhs[0]);
    u2= mxGetPr(plhs[1]);
    /*Call the segmentation function in C*/
    normal_wROF( u1, u2, u01, u02, w, mu, nx, ny, N );  
    
    return;
}
