function v = ROF(v0, mu, verb)

% solves min vTV(N) + 0.5 \mu || N - N0 ||^2

if nargin<3
    verb = 0;
end;

%%%%% parameters
nAL = 10000;
nInner = 1;
rd = mu;

%%%%%% normalize parameters to size of image and CS samples
[Ny, Nx] = size(v0);
N = Nx*Ny;

%%%%%%%%%%% auxiliary variable for FFT-based minimization
[X,Y] = meshgrid(1:Nx,1:Ny);
auxFFT = cos(2*pi/Ny*Y) + cos(2*pi/Nx*X) - 2;


%%%%%%%%%%%%% initialize split variables
v = v0;%zeros(Ny,Nx,L);
vpast = v;

dx = Dx(v);
dy = Dy(v);
ldx = zeros(Ny,Nx);
ldy = zeros(Ny,Nx);

K = mu - 2*rd*auxFFT;

%%%%%%%%%%%%% iterate AL algorithm
for iAL=1:nAL
    for inner = 1:nInner;
       
        %update V
        rhs = mu*v0 + Dxt( ldx + rd*dx ) + Dyt( ldy + rd*dy );
        v  = real( ifft2( fft2(rhs)./K ));

        %update d
        vx = Dx(v); vy = Dy(v);
        [dx,dy] = shrink2( vx - ldx/rd, vy - ldy/rd, 1/rd);
    end;
    
    %update Lagrange multipliers
    ldx = ldx + rd*( dx - vx );
    ldy = ldy + rd*( dy - vy );
    
    
    % compute energy and AL residuals
    Energy(iAL) = sum(sum( sqrt( vx.*conj(vx) + vy.*conj(vy) ) ))/N  + 0.5/N*mu*norm( v(:) - v0(:) )^2;
    res(iAL) = 1/N*norm( dx(:) - vx(:) ) + 1/N*norm( dy(:) - vy(:) ); 

    % stopping condition
    stop_cond = [ ( res(iAL) > 1e-3 ) norm(v(:) - vpast(:))/norm(v(:)) norm(v(:) - vpast(:))/N ];
    vpast = v;
    if( max(stop_cond)<1e-6 )
        disp(['vectorial ROF stopped at iteration ' int2str(iAL)])
        break;
    end;      
    
end;


if( verb )
    cpt_fig = 101;
    figure(cpt_fig); clf;
    subplot(131); imagesc(v0); title('Original image');
    subplot(132); imagesc(real(v)); title('Reconstructed image');
    subplot(133); imagesc(conj(v-v0).*(v-v0)); colorbar; title('|| V - V0 ||^2');
    pause(0.01);
    
%     cpt_fig = 102;
%     figure(cpt_fig); clf;
%     subplot(121); semilogy(Energy); title('Energy to minimize'); 
%     subplot(122); semilogy(res); title('residuals');    
%     pause(0.01);
end;


%%%%%%%%%%%% estimate differential functions with finite differences

function d = Dx(u)
[rows,cols,L] = size(u); 
d = zeros(rows,cols);
d(:,2:cols) = u(:,2:cols)-u(:,1:cols-1);
d(:,1) = u(:,1)-u(:,cols);
return

function d = Dxt(u)
[rows,cols] = size(u); 
d = zeros(rows,cols);
d(:,1:cols-1) = u(:,1:cols-1)-u(:,2:cols);
d(:,cols) = u(:,cols)-u(:,1);
return

function d = Dy(u)
[rows,cols] = size(u); 
d = zeros(rows,cols);
d(2:rows,:) = u(2:rows,:)-u(1:rows-1,:);
ud(1,:) = u(1,:)-u(rows,:);
return

function d = Dyt(u)
[rows,cols] = size(u); 
d = zeros(rows,cols);
d(1:rows-1,:) = u(1:rows-1,:)-u(2:rows,:);
d(rows,:) = u(rows,:)-u(1,:);
return



%%%%%%%%%%%% auxiliary shrinkage functions

function xs = shrink(x,lambda)

s = sqrt(x.*conj(x));
ss = s-lambda;
ss = ss.*(ss>0);

s = s+(s<lambda);
ss = ss./s;

xs = ss.*x;

return;


function [xs,ys] = shrink2(x,y,lambda)
s = sqrt(x.*conj(x)+y.*conj(y));
ss = s-lambda;
ss = ss.*(ss>0);

s = s+(s<lambda);
ss = ss./s;
xs = ss.*x;
ys = ss.*y;

return;
