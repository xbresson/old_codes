function [DivN, w_edge] = NL_estimate_Normals(u,mu,graphfile,verb)


if nargin<4
    verb = 0;
end;
EPSILON = 1e-6;
[Ny,Nx] = size(u);
N = Nx*Ny;

load(['graph_data/' graphfile ],'D','Dt','J','T');
D = sparse(D);Dt = sparse(Dt);
szd = size(D,1);

Du = D*u(:);
nDu = sqrt(  EPSILON + J*(Du.^2) ); 

% Tuckey edge detector from 
% M. J. Black, G. Sapiro, D. H. Marimont, and D. Heeger, ?Robust anisotropic diffusion,? IEEE Transactions on Image Processing, vol. 7, no. 3, pp. 421?432, Jan. 1998.
med_nDu = median(nDu(:));
nDu_centered = sqrt( J*(( Du - med_nDu ).^2) );
sigma_e = 1.4826*median( nDu_centered(:) );
w_edge= g_t(nDu,sigma_e); 
mx = max(w_edge(:)); mn = min(w_edge(:));
if(mx-mn>EPSILON)
    w_edge = (w_edge-mn)/(mx-mn);
else
    w_edge = ones(Ny*Nx,1);
end;
normGu = Du./(T*nDu);


% mask normals with edge detector
mask_edge= 1 - T*w_edge; 
normGu = normGu.*mask_edge;

% denoise divergence of normals 
% compute noisy divergence
DivN0 = Dt*normGu;

%NL-0 ROF
DivNc = ROF(reshape(DivN0,Ny,Nx), mu); 


DivN = DivNc(:);

if verb
    cpt_fig = 101;
    figure(cpt_fig); clf;
    subplot(131);imagesc(u);title(['current reconstructed image']); colormap(gray);
    subplot(132);imagesc(reshape(w_edge,Ny,Nx));title(['NL edge detector']); colormap(gray);
    subplot(133);imagesc(reshape(DivN,Ny,Nx));title(['NL divergence of normals']); colormap(gray);
    pause(0.1);
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% auxiliary functions

% Perona-Malick edge detector 2
function g = g_pm(x,sigma)
g = 2./(2 + (x/sigma).^2);
return

% Huber edge detector
function g = g_huber(x,sigma)
cond = ( abs(x) <= sigma );
g = 1/sigma.*cond + sign(x)./x.*(1-cond);
return

% Tuckey edge detector
function g = g_t(x,sigma)
cond = ( abs(x) <= sigma );
g = 1/2*( ( 1 - (x/sigma).^2 ).^2 ).*cond ;
return