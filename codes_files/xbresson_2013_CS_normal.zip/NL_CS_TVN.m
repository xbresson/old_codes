function [u, snr_out] = NL_CS_TVN(R, f, uclean, ustart, alpha, gamma, rd, ru, mu, graphfile0)

verb = 0;

%%%%% parameters
nAL = 8000;
nNorm = 100;
nInner = 1;

%%%%%%%%%%%%%%%% Non-Local operators
graphfile = graphfile0;
saved_graphfile = 1;
if saved_graphfile
    load(['graph_data/' graphfile ],'D','Dt','J','T');
else
    %Dgraph_vectors( V0,'temp'); 
    graphfile = 'temp_NL_CS_TVN';
    Dgraph( real(ustart),'temp_NL_CS_TVN');
    load(['graph_data/temp_NL_CS_TVN' ],'D','Dt','J','T');
end;
saved_graphfile = 0;
%%%%%% normalize parameters to size of image and CS samples
[Ny,Nx] = size(R);
N = Nx*Ny;
alpha = alpha*sqrt(N)/nnz(R);
fftscale = sqrt(N);
epsilon = alpha/1e1;

%%%%%%%%%%% useful for min w.r.t u and v
K = ru + alpha*conj(R).*R;
rhsfft0 = alpha*ifft2(R.*f)*fftscale;
maxit_pcg = 10;  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
urshp = ustart;
snr_out = 0;   
for iNorm = 1:nNorm 
   
    [DivN, w_edge] = NL_estimate_Normals( real(urshp), mu, graphfile);
    clear SNR Energy res var_noise
    
    u = ustart(:);
    upast = u; 
    %%%%%%%%%%%%%%%%initialize split variables
    D = sparse(D);Dt = sparse(Dt);
    szd = size(D,1);
    A = ru*speye(N) + rd*Dt*D;
    LAt = cholinc(A,struct('droptol',1e-1,'michol',1)); LA = LAt';
    % you might need to use this other line instead of the previous instruction, depending on your matlab version
    % LA = ichol(A,struct('michol','on')); LAt = LA';
    d = D*u;
    v = zeros(Ny,Nx);
    ld = zeros(szd,1);
    lu = zeros(Ny,Nx);

    for iAL=1:nAL
        
        for iInner=1:nInner
            %update u
            rhs =  ru*v(:) + gamma*DivN(:) - lu(:) + Dt*( ld + rd*d );
            [u flag relres] = pcg( A , rhs, 1e-6, maxit_pcg, LA, LAt, u );
            urshp = reshape(u,Ny,Nx);

            %update v
            rhsfft = rhsfft0 + lu + ru*urshp;
            v = ifft2( fft2(rhsfft)./K );

            %update d
            Du = D*u;
            d = shrinkL_NL( Du - ld/rd, J, T, 1/rd);
        end;

        %update Lagrange multipliers
        ld = ld + rd*( d - Du );
        lu = lu + ru*( urshp - v );


        % compute energy and AL residuals
        Rfftu = R.*fft2(urshp)/fftscale;
        Energy(iAL) = sum( sqrt( J*(Du.*conj(Du)) ) )/N  + 0.5/N*alpha*norm( Rfftu - f , 'fro')^2 + gamma*sum( real(DivN.*u) )/N;
        res(iAL) = 1/N*norm( Du-D*u(:)); 
        SNR(iAL) = snr(real(urshp),uclean);         

%         if( rem(iAL,50)==0 )
%             cpt_fig = 101;
%             figure(cpt_fig); clf;
%             subplot(221); imshow(abs(urshp)); title(['TV SNR = ',num2str(SNR(iAL))]);
%             subplot(222); semilogy(Energy); title('Energy to minimize');
%             subplot(223); semilogy(res+1e-9); title('residuals'); legend('grad u = d');
%             subplot(224); plot(SNR); title('SNR');  
%             pause(0.01)
%         end;

        % stopping condition
        stop_cond = [ ( res(iAL) > 1e-5 ) norm(u-upast,'fro')/norm(u,'fro') norm(u-upast,'fro')/N ];
        upast = u;
        if( max(stop_cond)<1e-6 )
            disp(['external loop ' int2str(iNorm) ' SNR ' num2str(SNR(iAL)) ' at iteration ' int2str(iAL) ])
            break;
        end;


    end;
    
    if snr_out > SNR(iAL)
        disp('SNR went down');
        break;
    end;
    nerror = sqrt(conj(urshp-uclean).*(urshp-uclean));
    
    %reestimate DivN
    if saved_graphfile<1
        clear D Dt J T A
        graphfile = 'temp_NL_CS_TVN';
        Dgraph( real(urshp),'temp_NL_CS_TVN');
        %disp('recomputing graph weights');
        load(['graph_data/temp_NL_CS_TVN' ],'D','Dt','J','T');
    end;    
    % monitor variables
    measurements_MSE(iNorm) = norm( Rfftu - f , 'fro')/N;
    reconstruction_MSE(iNorm) = sum(nerror(:))/N;
    
    snr_out = SNR(iAL);
    u_out = u;
    
    
end;
u = reshape(u_out,Ny,Nx);
snr_out
if verb
    cpt_fig = 1001;
    figure(cpt_fig); clf;
    subplot(221); imshow(abs(u)); title(['TV SNR = ',num2str(SNR(iAL))]);
    subplot(222); semilogy(Energy); title('Energy to minimize');
    subplot(223); semilogy(res+1e-9); title('residuals'); legend('grad u = d');
    subplot(224); plot(SNR); title('SNR');    
    pause(0.01);

    cpt_fig = 1002;
    figure(cpt_fig); clf;
    subplot(131);imagesc(real(uclean));title(['original image']); colormap(gray);
    subplot(132);imagesc(real(u));title(['reconstrection SNR=' num2str(SNR(iAL))]); colormap(gray);
    subplot(133);imagesc(nerror, [min(nerror(:)) max(nerror(:))]); title(['|| uclean - u ||']); colormap(gray);
    pause(0.01);
    
    cpt_fig = 1003;
    figure(cpt_fig); clf;
    subplot(121);plot(measurements_MSE); ylabel('|| f - K*u_{k} ||'); xlabel('iterations-restimation of normals'); title('|| f - K*u_{k} ||');
    subplot(122);plot(measurements_MSE); ylabel('|| u* - u_{k} ||'); xlabel('iterations-restimation of normals'); title('|| u* - u_{k} ||');
    pause(0.01);
end;

return

%%%%%%%%%%%% auxiliary shrinkage functions

function xs = shrinkL_NL(x, J, T, lambda)
L = size(x,2);
s = sqrt(sum( J*( x.*conj(x)) ,2));
ss = s-lambda;
ss = ss.*(ss>0);

s = s+(s<lambda);
ss = ss./s;
ss = T*ss;

xs = repmat(ss,1,L).*x;

return;
