function [u, snr_out, nx, ny] = CS_TVN_it(R, f, uclean, unormals, alpha, gamma, rd, mu, verb)
%function [u, snr_out, DivN] = CS_TVN_it(R, f, uclean, unormals, alpha, gamma, rd, mu, verb)

if nargin<9
    verb = 0;
end;
%%%%% parameters
nNorm = 100;
N = length(uclean(:));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% estimate normals
u = unormals;
snr_out = 0;   
u_out = zeros(size(R));
for iNorm = 1:nNorm 
    
    [DivN, w_edge, normfx, normfy] = estimate_Normals(u,mu);
%      [DivN, w_edge, normfx, normfy] = estimate_Normals_NL(u,mu);

    clear u Energy res
    [u, Energy, res] = CS_TVN_real_mex(R, f, DivN, alpha, gamma, rd);
    snr_it = snr(u,uclean)
    if( (snr_it<0) || isnan(snr_it))
        disp('SNR negative or nan');
        disp(['alpha=' num2str(alpha) ' gamma=' num2str(gamma) ' rd=' num2str(rd) ' mu=' num2str(mu) ]);
        cpt_fig = 1001;
        figure(cpt_fig); clf;
        subplot(121); semilogy(Energy); title('Energy');
        subplot(122); semilogy(res); title('AL residual');
        pause(0.01);
        break;
    end;
    if(snr_out > snr_it)
        disp('SNR went down');
        break;
    end;
    u_out = u;
    nerror = sqrt(conj(u-uclean).*(u-uclean));
       
    % monitor variables
    measurements_MSE(iNorm) = norm( R.*fft2(u)/sqrt(N) - f , 'fro')/N;
    reconstruction_MSE(iNorm) = sum(nerror(:))/N;
    
    snr_out = snr_it;    
    if( (norm(DivN,'fro')/(N)<1e-3) || (sum(isnan(DivN(:)))>0) )
        break;
    end;    
    nx = normfx; ny = normfy;
end;
snr_out
u = u_out;
nerror = sqrt(conj(u-uclean).*(u-uclean));
if verb

    cpt_fig = 1002;
    figure(cpt_fig); clf;
    subplot(131);imagesc(uclean);title(['original image']); colormap(gray);
    subplot(132);imagesc(u);title(['reconstrection SNR=' num2str(snr_it)]); colormap(gray);
    subplot(133);imagesc(nerror, [min(nerror(:)) max(nerror(:))]); title(['|| uclean - u ||']); colormap(gray);
    pause(0.01);
    
    cpt_fig = 1003;
    figure(cpt_fig); clf;
    imagesc(u); hold on; quiver(normfx,normfy); title('estimated normals'); colormap(gray);
    pause(0.01);
    
%     cpt_fig = 1004;
%     figure(cpt_fig); clf;
%     subplot(131);plot(change_DivN); ylabel('|| DivN_k - DivN_{k=1} ||'); xlabel('iterations-restimation of normals'); title('|| DivN_k - DivN_{k=1} ||');
%     subplot(132);plot(measurements_MSE); ylabel('|| f - K*u_{k} ||'); xlabel('iterations-restimation of normals'); title('|| f - K*u_{k} ||');
%     subplot(133);plot(reconstruction_MSE); ylabel('|| u* - u_{k} ||'); xlabel('iterations-restimation of normals'); title('|| u* - u_{k} ||');
%     pause(0.01);
end;

return