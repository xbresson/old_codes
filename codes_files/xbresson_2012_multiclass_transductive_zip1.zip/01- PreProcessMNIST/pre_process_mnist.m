

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MNIST
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function pre_process_mnist

clear


tic
[T trainingT labels traininglabels Va m oB oAt e]=loadmnistkp(50,0);
toc


% T: 60,000 data, trainingT:10,000 training data
% labels: the class for the 60,000 data, traininglabels: the class for the 10,000 training data


file = 'file_mnist.mat';
tic
save(file,'T','trainingT','labels','traininglabels');
toc






solution = labels;




figure(1); clf; s=3; A=T'; N=size(A); z=solution;
scatter(A(1,1:N(2)),A(2,1:N(2)),s*ones(1,N(2)),z,'o', 'filled'); title('ground truth');
axis off;




end









