
Xavier Bresson - April 10 2009


A Fast Global Minimization Algorithm for Active Contour Models

Read: A Short Guide on a Fast Global Minimization Algorithm for Active Contour Models



How to use this code ?


Open Matlab and compile the mex function "active_contour_minimization_mex.c" by running:
mex active_contour_minimization_mex.c
Then run test_active_contour_segmentation




