%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: 	Xavier Bresson (xbresson@math.ucla.edu)
% Description: Fast minimization algorithm for General Active Contour Model
% For more details, see the report:
% X. Bresson, "A Short Guide on a Fast Global Minimization Algorithm for Active Contour Models"
% See also these reports: 
% 1- T. Goldstein, X. Bresson, and S. Osher, Geometric Applications of the 
% Split Bregman Method: Segmentation and Surface Reconstruction,
% CAM Report 09-06, 2009. 
% 2- T.F.Chan, L.A.Vese, Active contours without edges, IEEE
% Transactions on Image Processing. 10:2, pp. 266-277, 2001.
% (Segmentation model for smooth/non-texture images)
% 3- N. Houhou, J-P. Thiran and X. Bresson, 
% Fast Texture Segmentation based on Semi-Local Region Descriptor and Active Contour, 2009
% (Segmentation model for texture images)
% Last version: April 3, 2009
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Choice of the segmentation model:
% ModelSeg = MODEL_SMOOTH_IMAGE;
% or
% ModelSeg = MODEL_TEXTURE_IMAGE;
% Then, choose the two parameters mu and lambda
% Here is an empirical rule: first, choose mu
% Typically, mu=1e3 but you can choose between [1e1,1e4]
% Second, choose lambda
% Typically, for lambda=0.1 then large regularization/smoothing
% for lambda=1 then medium regularization/smoothing
% for lambda=10 then small regularization/smoothing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function test_active_contour_segmentation

close all;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Constants
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MODEL_SMOOTH_IMAGE = 0; % Chan-Vese Model
MODEL_TEXTURE_IMAGE = 1; % Houhou-Thiran-Bresson Model


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Default values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
maxI = 256; % max image intensity





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Comment and un-comment experiments
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Smooth/Non-Texture Images
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% noisy square
Im0 = zeros(128,128); Im0(32:32+64,32:32+64)=1;
Im0 = Im0 + 0.2*randn(size(Im0));
Im0 = ( Im0-min(Im0(:)) )/ ( max(Im0(:))-min(Im0(:)) );
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e3; 
lambda = mu* 5;

cpt_fig = 1; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function



% cameraman
[Im0,map] = imread('images/cameraman.gif');
[Ny,Nx,Nc] = size(Im0); 
if Nc>1; Im0=rgb2gray(Im0); end; % Convert color image to gray-scale image
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e2; 
lambda = mu* 8; % 3

cpt_fig = 10; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% lung
[Im0,map] = imread('images/lung.jpg'); 
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e3; 
lambda = mu* 0.1;

cpt_fig = 20; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% lung2
[Im0,map] = imread('images/lung2.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e2; % 1e1
lambda = mu* 0.6;%1;

cpt_fig = 30; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% house
[Im0,map] = imread('images/house.png');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e3;
lambda = mu* 1;

cpt_fig = 40; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% bacteria
[Im0,map] = imread('images/bacteria.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e4; 
lambda = mu* 0.5; 

cpt_fig = 50; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% bacteria2
[Im0,map] = imread('images/bacteria2.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e3; 
lambda = mu* 0.1; 

cpt_fig = 60; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function



% brain
[Im0,map] = imread('images/brain.tif');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e3; 
lambda = mu* 7; % 5

cpt_fig = 70; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% ultrasound
[Im0,map] = imread('images/ultrasound.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e3; 
lambda = mu* 0.3; 

cpt_fig = 80; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% squirrel
[Im0,map] = imread('images/squirrel.jpg'); 
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_SMOOTH_IMAGE;
mu = 1e3; 
lambda = mu* 0.118;

cpt_fig = 90; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; ]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Texture Images
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% nbBin = number of bins for instensity distributions
% stdParzenWindow = standard deviation for Gaussian in Parzen's estimation
% of intensity distribution (typically 2)
% patchsize = size of intensity patches in the computation of the texture 
% feature (depends on the textures, between [5,20])



% zebra-texture
[Im0,map] = imread('images/zebra-texture.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_TEXTURE_IMAGE;
nbBin = maxI;
stdParzenWindow = 2;
mu = 1e3;
lambda = mu* 0.04;
patchsize = 7;

cpt_fig = 100; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; nbBin; stdParzenWindow; patchsize;]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function



% cheetah1
[Im0,map] = imread('images/cheetah1.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_TEXTURE_IMAGE;
nbBin = maxI;
stdParzenWindow = 1;
mu = 1e1; % 1e1
lambda = mu* 1; % mu* 1
patchsize = 9;

cpt_fig = 110; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; nbBin; stdParzenWindow; patchsize;]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function





% zebras
[Im0,map] = imread('images/zebras.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_TEXTURE_IMAGE;
nbBin = maxI;
stdParzenWindow = 2;
mu = 1e1; % 1e1
lambda = mu* 1.35; % mu* 1.35
patchsize = 9;

cpt_fig = 120; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; nbBin; stdParzenWindow; patchsize;]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function





% tiger
[Im0,map] = imread('images/tiger.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_TEXTURE_IMAGE;
nbBin = maxI;
stdParzenWindow = 2;
mu = 1e1; % 1e1
lambda = mu* 0.3; % mu* 0.6
patchsize = 9;

cpt_fig = 130; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; nbBin; stdParzenWindow; patchsize;]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function





% panther
[Im0,map] = imread('images/panther.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_TEXTURE_IMAGE;
nbBin = maxI;
stdParzenWindow = 2;
mu = 1e2*0.207; % 1e2*0.207
lambda = mu* 0.1; % mu* 0.1
patchsize = 7;

cpt_fig = 140; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; nbBin; stdParzenWindow; patchsize;]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% bear
[Im0,map] = imread('images/bear.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_TEXTURE_IMAGE;
nbBin = maxI;
stdParzenWindow = 2;
mu = 1e2/2; % 1e1
lambda = mu* 0.01; % mu* 0.2
mu = 1e1; % 1e1
lambda = mu* 0.2; % mu* 0.2
patchsize = 17; % 21

cpt_fig = 150; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; nbBin; stdParzenWindow; patchsize;]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% fish
[Im0,map] = imread('images/fish.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_TEXTURE_IMAGE;
nbBin = maxI;
stdParzenWindow = 2;
mu = 1e1; % 1e1
lambda = mu* 0.7; % mu* 0.7
patchsize = 11;

cpt_fig = 160; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; nbBin; stdParzenWindow; patchsize;]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function




% cheetah2
[Im0,map] = imread('images/cheetah2.jpg');
[Ny,Nx] = size(Im0);
ModelSeg = MODEL_TEXTURE_IMAGE;
nbBin = maxI;
stdParzenWindow = 2;
mu = 1e1*0.7; % 1e1*0.7
lambda = mu* 0.6; % mu* 0.6
patchsize = 11;

cpt_fig = 170; % figure number
VecParameters = [Ny; Nx; ModelSeg; lambda; mu; nbBin; stdParzenWindow; patchsize;]; % parameters for active contour function
active_contour_minimization(Im0,VecParameters,cpt_fig); % active contour function






