
/***************************************************************************/
/* Name:       active_contour_minimization_mex.c                               
Date:          April 3, 2009                                                 
Author:        Xavier Bresson (xbresson@math.ucla.edu)                  
Description:   Fast minimization algorithm for General Active Contour Model
For more details, see the report:
X. Bresson, "A Short Guide on a Fast Global Minimization Algorithm for Active Contour Models"
See also these reports: 
1- T. Goldstein, X. Bresson, and S. Osher, Geometric Applications of the 
Split Bregman Method: Segmentation and Surface Reconstruction,
CAM Report 09-06, 2009. 
2- T.F.Chan, L.A.Vese, Active contours without edges, IEEE
Transactions on Image Processing. 10:2, pp. 266-277, 2001.
(Segmentation model for smooth/non-texture images)
3- N. Houhou, J-P. Thiran and X. Bresson, 
Fast Texture Segmentation based on Semi-Local Region Descriptor and Active Contour, 2009
(Segmentation model for texture images) */
/***************************************************************************/


/*  compilation command (under matlab): mex active_contour_minimization_mex.c  */

/*  Organization of the code:
 First part: Functions that computes the region-term for Chan-Vese Model,
 Houhou-Thiran-Bresson Model, or YOUR Active Contour model 
 Second part: Functions that minimizes the energy */



#include <stdio.h>
#include <stdlib.h>
#include <mex.h>
#include <math.h>
#include <time.h>


#define YES 0
#define NO 1

#define MODEL_SMOOTH_IMAGE 0
#define MODEL_TEXTURE_IMAGE 1

#define PI 3.1415926

#define X(ix,iy) (ix)*iNy+ (iy)
#define Xe(ix,iy) (ix)*iNye+ (iy)

#define MAX(a,b) ( a > b ? a : b )
#define SIGN(x) ( x >= 0.0 ? 1.0 : -1.0 )
#define ABS(x) ( (x) > 0.0 ? x : -(x) )
#define SQR(x) (x)*(x)

#ifndef HAVE_RINT 
#define rint(A) floor((A)+(((A) < 0)? -0.5 : 0.5)) 
#endif

float SQRT(float number) {
    long i;
    float x, y;
    const float f = 1.5F;
    
    x = number * 0.5F;
    y  = number;
    i  = * ( long * ) &y;
    i  = 0x5f3759df - ( i >> 1 );
    y  = * ( float * ) &i;
    y  = y * ( f - ( x * y * y ) );
    y  = y * ( f - ( x * y * y ) );
    return number * y;
}






/**********************************************/
/************** SUB FUNCTIONS *****************/
/* (See MAIN FUCTION at the end of this file) */
/**********************************************/


/****************************************/
/* SEGMENTATION MODEL FOR SMOOTH/NON-TEXTURE IMAGES (CHAN-VESE MODEL) */
/* See: T.F.Chan, L.A.Vese, Active contours without edges, IEEE
Transactions on Image Processing. 10:2, pp. 266-277, 2001. */
/****************************************/
void vComputeChanVese (
  float  *pfIm0, 
  float  *pfu,
  int    iNx,
  int    iNy,
  float  *pfHr,
  int    iNbItersUpdateHr,
  float  *pfMeanIn,
  float  *pfMeanOut,
  int    iNI
  )
 
{
    float  fMeanIn, fMeanOut, fNormalizationIn, fNormalizationOut;
    int    ix, iy;
    
    
    /* Update Chan-Vese region function Hr every "iNbItersUpdateHr" iterations */
    if ( (iNI==0) || (iNI%iNbItersUpdateHr==0) )
    {
        
        /* Compute inside and outside means */
        fMeanIn = 0.0; fMeanOut = 0.0;
        fNormalizationIn = 0.0; fNormalizationOut = 0.0;
        
        for (ix=0; ix< iNx; ix++)
            for (iy=0; iy< iNy; iy++)
        {
            fMeanIn += pfIm0[X(ix,iy)]*pfu[X(ix,iy)];
            fNormalizationIn += pfu[X(ix,iy)];
            fMeanOut += pfIm0[X(ix,iy)]*(1.0-pfu[X(ix,iy)]);
            fNormalizationOut += 1.0-pfu[X(ix,iy)];
            }

        if (fNormalizationIn>0.0) fMeanIn = fMeanIn/ fNormalizationIn;
        if (fNormalizationOut>0.0) fMeanOut = fMeanOut/ fNormalizationOut;
        
        
        /* Compute region term h_r = (c1-I)^2 - (c2-I)^2*/
        for (ix=0; ix< iNx; ix++)
            for (iy=0; iy< iNy; iy++)
                pfHr[X(ix,iy)] = -( SQR(fMeanIn-pfIm0[X(ix,iy)]) - SQR(fMeanOut-pfIm0[X(ix,iy)]) );
        
        *pfMeanIn = fMeanIn;
        *pfMeanOut = fMeanOut;
        
    }
    
    

}
/****************************************/

/****************************************/
/* END SEGMENTATION MODEL FOR SMOOTH/NON-TEXTURE IMAGES (CHAN-VESE MODEL) */
/****************************************/








/****************************************/
/* SEGMENTATION MODEL FOR TEXTURE IMAGES (HOUHOU-THIRAN-BRESSON MODEL) */
/* See: N. Houhou, J-P. Thiran and X. Bresson, 
Fast Texture Segmentation based on Semi-Local Region Descriptor and Active Contour, 2009 */
/****************************************/

/****************************************/
/* This function computes the texture feature */
void vComputeTextureFeature
(
float  *pfIm0,
int    iNx,
int    iNy,
float  *pfTextFeat,
int    ip,
int    iNbBin
)

{
    int    ix, iy, iX, iNxe, iNye, ip2, ixe, iye, ik;
    int    iyp2, ixp2, iy2, ix2, iXe, iNyxe;
    float  *pfI, *pfIx, *pfIy, *pfIxe, *pfIye, fG11, fG22, fG12;
    float  fMaxI, fMinI, fNbBin;
    
    
    
    /* Allocate memory */
    pfI = (float *) calloc( (unsigned)(iNx*iNy), sizeof(float) );
    if (!pfI)
        mexPrintf("Memory allocation failure\n");
    
    
    /* Normalize Im0 */
    fMaxI = 0.0;
    fMinI = 1e10;
    for (ix=0; ix< iNx; ix++)
        for (iy=0; iy< iNy; iy++)
    {
        if (pfIm0[X(ix,iy)]>fMaxI) fMaxI= pfIm0[X(ix,iy)];
        if (pfIm0[X(ix,iy)]<fMinI) fMinI= pfIm0[X(ix,iy)];
        }
    for (ix=0; ix< iNx; ix++)
        for (iy=0; iy< iNy; iy++)
            pfI[X(ix,iy)] = (pfIm0[X(ix,iy)]-fMinI)/ (fMaxI-fMinI);
    
    
    /* Allocate memory */
    pfIx = (float *) calloc( (unsigned)(iNx*iNy), sizeof(float) );
    if (!pfIx)
        mexPrintf("Memory allocation failure\n");
    
    pfIy = (float *) calloc( (unsigned)(iNx*iNy), sizeof(float) );
    if (!pfIy)
        mexPrintf("Memory allocation failure\n");
    
    
    
    /* Compute partial_x I=Ix, partial_y I=Iy */
    for (ix=0; ix< iNx-1; ix++)
        for (iy=0; iy< iNy-1; iy++)
    {
        iX = X(ix,iy);
        pfIx[iX] = pfI[X(ix+1,iy)] - pfI[iX];
        pfIy[iX] = pfI[X(ix,iy+1)] - pfI[iX];
        }
    ix = iNx-1;
    for (iy=0; iy< iNy-1; iy++)
    {
        iX = X(ix,iy);
        pfIx[iX] = pfI[iX] - pfI[X(ix-1,iy)];
        pfIy[iX] = pfI[X(ix,iy+1)] - pfI[iX];
    }
    iy = iNy-1;
    for (ix=0; ix< iNx-1; ix++)
    {
        iX = X(ix,iy);
        pfIx[iX] = pfI[X(ix+1,iy)] - pfI[iX];
        pfIy[iX] = pfI[iX] - pfI[X(ix,iy-1)];
    }
    ix = iNx-1;
    iy = iNy-1;
    iX = X(ix,iy);
    pfIx[iX] = pfI[iX] - pfI[X(ix-1,iy)];
    pfIy[iX] = pfI[iX] - pfI[X(ix,iy-1)];
    
    
    
    /* Compute extended Ix, Iy with mirror conditions */
    ip2 = (ip-1)/2;
    iNxe = iNx + 2* ip2;
    iNye = iNy + 2* ip2;
    iNyxe = iNxe*iNye;
    
    
    /* Allocate memory */
    pfIxe = (float *) calloc( (unsigned)(iNxe*iNye), sizeof(float) );
    if (!pfIxe)
        mexPrintf("Memory allocation failure\n");
    
    pfIye = (float *) calloc( (unsigned)(iNxe*iNye), sizeof(float) );
    if (!pfIye)
        mexPrintf("Memory allocation failure\n");
    
    
    for (ixe=0,ik=0;ixe<iNxe;ixe++)
    {
        if (ixe<ip2) ix=ip2-ixe;
        else if (ixe>iNx+ip2-1) ix=2*iNx+ip2-ixe-2;
        else ix=ixe-ip2;
        
        for (iye=0;iye<iNye;iye++,ik++)
        {
            if (iye<ip2)  iy=ip2-iye;
            else if (iye>iNy+ip2-1) iy=2*iNy+ip2-iye-2;
            else iy=iye-ip2;
            
            pfIxe[ik]=pfIx[X(ix,iy)];
            pfIye[ik]=pfIy[X(ix,iy)];
        }
    }
    
    
    /* Compute Texture Feature */
    for (iye=ip2;iye<iNye-ip2;iye++)
        for (ixe=ip2;ixe<iNxe-ip2;ixe++)
    {
        fG11 = 0.0;
        fG22 = 0.0;
        fG12 = 0.0;
        for (iyp2=-ip2;iyp2<ip2;iyp2++)
            for (ixp2=-ip2;ixp2<ip2;ixp2++)
        {
            iy2 = iye+iyp2;
            ix2 = ixe+ixp2;
            iXe = Xe(ix2,iy2);
            fG11 += SQR(pfIxe[iXe]);
            fG22 += SQR(pfIye[iXe]);
            fG12 += pfIxe[iXe]*pfIye[iXe];
            }
        
        iy=iye-ip2;
        ix=ixe-ip2;
        pfTextFeat[X(ix,iy)] = 1.0/( (1.0+fG11)*(1.0+fG22) - SQR(fG12) );
        }
    
    
    /* Normalize Texture Feature */
    fMaxI = 0.0;
    fMinI = 1e10;
    for (ix=0; ix< iNx; ix++)
        for (iy=0; iy< iNy; iy++)
    {
        if (pfTextFeat[X(ix,iy)]>fMaxI) fMaxI= pfTextFeat[X(ix,iy)];
        if (pfTextFeat[X(ix,iy)]<fMinI) fMinI= pfTextFeat[X(ix,iy)];
        }
    
    /* Range Texture Feature is in [1 NbBin] */
    fNbBin = (float)iNbBin;
    for (ix=0; ix< iNx; ix++)
        for (iy=0; iy< iNy; iy++)
            pfTextFeat[X(ix,iy)] = 1.0 + (pfTextFeat[X(ix,iy)]-fMinI)/ (fMaxI-fMinI)* fNbBin;
    
    
    
    /* Free memory */
    free( (float *) pfI );
    free( (float *) pfIx );
    free( (float *) pfIy );
    free( (float *) pfIxe );
    free( (float *) pfIye );
    
}
/****************************************/

/****************************************/
/* This function computes a Gaussian function */
void vComputeGaussian
(
float    *pfGaussian,
float    fStdParzenWindow,
int      iNGaussian
)

{
    int    ic, i;
    float  f1, f2;
    
    ic = (int) ((iNGaussian-1)/2);
    
    f1 = 2.0* SQR(fStdParzenWindow);
    f2 = fStdParzenWindow* SQRT(2.0* PI);
    
    for (i=0; i< iNGaussian; i++)
        pfGaussian[i] = (float)exp( -SQR(i-ic)/ f1 ) / f2;
    
}
/****************************************/

/****************************************/
/* This function estimates the intensity distribution from an histogram */
void vComputeParzenWindFunction_p
(
float  *pfp,
float  *pfHisto,
float  fAera,
int    iNbBin,
float  *pfGaussian,
int    iNGaussian
)

{
  int    iNg, iNg2, ic, i, i2, i_shift;
  float  fSumGauss;

  iNg = iNGaussian;
  iNg2 = (int) ((iNGaussian-1)/2);
  ic = (int) ((iNGaussian-1)/2);
  
  
  /* Pre-processing to avoid division by zero */
  for (i=0; i< iNbBin; i++)
      if( pfHisto[i] < 1 )
          pfHisto[i] = 1;
  
  
  /* Center of p */
  for (i=iNg2; i< iNbBin- iNg2; i++)
  {
      for (i2=0; i2< iNg; i2++)
          pfp[i] += pfHisto[i+(i2-ic)]* pfGaussian[i2];
      pfp[i] /= fAera;
  }
  
  
  /* Borders of p */
  for (i=0; i< iNg2; i++)
  {
      fSumGauss = 0.0;
      for (i2=0; i2< iNg; i2++)
      {
          i_shift = i+(i2-ic);
          if ( i_shift>= 0  &&  i_shift< iNbBin )
              pfp[i] += pfHisto[i_shift]* pfGaussian[i2];
          fSumGauss += pfGaussian[i2];
      }
      pfp[i] /= fAera;
      pfp[i] /= fSumGauss;
  }
  
  for (i=iNbBin- iNg2; i< iNbBin; i++)
  {
      fSumGauss = 0.0;
      for (i2=0; i2< iNg; i2++)
      {
          i_shift = i+(i2-ic);
          if ( i_shift>= 0  &&  i_shift< iNbBin )
              pfp[i] += pfHisto[i_shift]* pfGaussian[i2];
          fSumGauss += pfGaussian[i2];
      }
      pfp[i] /= fAera;
      pfp[i] /= fSumGauss;
  }

  
}
/****************************************/

/****************************************/
void vComputeParzenWindFunction_E
(
float  *pfpIn,
float  *pfLogpIn,
float  *pfpOut,
float  *pfLogpOut,
float  *pfE1,
float  *pfE2,
int    iNbBin,
float  *pfGaussian,
int    iNGaussian
)

{
    int    iNg, iNg2, ic, i, i2, i_shift;
    float  fSumGauss;
    
    
    iNg = iNGaussian;
    iNg2 = (int) ((iNGaussian-1)/2);
    ic = (int) ((iNGaussian-1)/2);
    
    
    /* Init */
    for (i=0; i< iNbBin; i++) { pfE1[i] = 0.0; pfE2[i] = 0.0;  }
    
    
    /* Center of E1 and E2 */
    for (i=iNg2; i< iNbBin- iNg2; i++){
        for (i2=0; i2< iNg; i2++)
        {
            pfE1[i] += ( pfLogpIn[i+(i2-ic)] - pfLogpOut[i+(i2-ic)] + 1.0 - pfpOut[i+(i2-ic)]/pfpIn[i+(i2-ic)])* pfGaussian[i2];
            pfE2[i] += ( pfLogpIn[i+(i2-ic)] - pfLogpOut[i+(i2-ic)] - 1.0 + pfpIn[i+(i2-ic)]/pfpOut[i+(i2-ic)])* pfGaussian[i2];
        }
    }
    
    
    /* Boders of E1 and E2 */
    for (i=0; i< iNg2; i++)
    {
        fSumGauss = 0.0;
        for (i2=0; i2< iNg; i2++)
        {
            i_shift = i+(i2-ic);
            if ( i_shift>= 0  &&  i_shift< iNbBin )
            {
                pfE1[i] += ( pfLogpIn[i_shift] - pfLogpOut[i_shift] + 1.0 - pfpOut[i_shift]/pfpIn[i_shift])* pfGaussian[i2];
                pfE2[i] += ( pfLogpIn[i_shift] - pfLogpOut[i_shift] - 1.0 + pfpIn[i_shift]/pfpOut[i_shift])* pfGaussian[i2];
                fSumGauss += pfGaussian[i2];
            }
        }
        pfE1[i] /= fSumGauss;
        pfE2[i] /= fSumGauss;
    }
    
    for (i= iNbBin- iNg2; i< iNbBin; i++)
    {
        fSumGauss = 0.0;
        for (i2=0; i2< iNg; i2++)
        {
            i_shift = i+(i2-ic);
            if ( i_shift>= 0  &&  i_shift< iNbBin )
            {
                pfE1[i] += ( pfLogpIn[i_shift] - pfLogpOut[i_shift] + 1.0 - pfpOut[i_shift]/pfpIn[i_shift])* pfGaussian[i2];
                pfE2[i] += ( pfLogpIn[i_shift] - pfLogpOut[i_shift] - 1.0 + pfpIn[i_shift]/pfpOut[i_shift])* pfGaussian[i2];
                fSumGauss += pfGaussian[i2];
            }
        }
        pfE1[i] /= fSumGauss;
        pfE2[i] /= fSumGauss;
    }
    
    
}
/****************************************/

/****************************************/
void vComputeParzenWindFunction_F
(
float  *pfpIn,
float  *pfLogpIn,
float  *pfpOut,
float  *pfLogpOut,
float  *pfF1,
float  *pfF2,
int    iNbBin,
float  *pfGaussian,
int    iNGaussian
)
{
    
    int    iNg, iNg2, ic, i;
    float  fF1, fF2;
    
    iNg = iNGaussian;
    iNg2 = (int) ((iNGaussian-1)/2);
    ic = (int) ((iNGaussian-1)/2);
    
    fF1 = 0.0;
    fF2 = 0.0;
    
    for (i=0; i< iNbBin; i++)
    {
        fF1 += (pfpIn[i]*pfLogpIn[i] - pfpIn[i]*pfLogpOut[i] + pfpIn[i] - pfpOut[i]);
        fF2 += (pfpOut[i]*pfLogpIn[i] - pfpOut[i]*pfLogpOut[i] - pfpOut[i] + pfpIn[i]);
    }
    
    *pfF1 = fF1;
    *pfF2 = fF2;
    
}
/****************************************/


/****************************************/
void vComputeKL (
float  *pfIm0,
float  *pfu,
int    iNx,
int    iNy,
float  *pfHr,
int    iNbItersUpdateHr,
float  *pfpIn,
float  *pfpOut,
float  *pfHistoIn,
float  *pfHistoOut,
float  *pfLogpIn,
float  *pfLogpOut,
int    iNI,
int    iNbBin,
float  *pfGaussian,
int    iNGaussian,
float  *pfE1,
float  *pfE2
)

{
    float  fNormalizationIn, fNormalizationOut;
    float  fEps, fLogEps, fF1, fF2, fEvolIn, fEvolOut;
    int    ix, iy, i, iI;
    
    
    /* Update the region function Hr every "iNbItersUpdateHr" iterations */
    if ( (iNI==0) || (iNI%iNbItersUpdateHr==0) )
    {
        
        /* Init */
        for (i=0; i< iNbBin; i++) { pfHistoIn[i] = 0.0; pfHistoOut[i] = 0.0; }
        fNormalizationIn = 0.0;
        fNormalizationOut = 0.0;
        
        
        /* Compute histograms inside and outside the boundary of {u>0.5} */
        for ( ix=0; ix< iNx; ix++)
            for (iy=0; iy< iNy; iy++)
        {
            iI = (int)(rint(pfIm0[X(ix,iy)]));
            if (iI<=0) iI=0;
            if (pfu[X(ix,iy)] >= 0.5 )
                pfHistoIn[iI] += 1.0;
            else
                pfHistoOut[iI] += 1.0;

            fNormalizationIn += pfu[X(ix,iy)];
            fNormalizationOut += 1.0-pfu[X(ix,iy)];
            }
        
        
        /* Estimate the intensity distributions inside and outside from histograms, using the Parzen estimation method */
        vComputeParzenWindFunction_p(pfpIn,pfHistoIn,fNormalizationIn,iNbBin,pfGaussian,iNGaussian);
        vComputeParzenWindFunction_p(pfpOut,pfHistoOut,fNormalizationOut,iNbBin,pfGaussian,iNGaussian);
        
        
        /* Compute the log of distributions */
        fEps = 1e-32;
        fLogEps = log10(fEps);
        for (i=0; i< iNbBin; i++)
        {
            if ( pfpIn[i] > fEps ) pfLogpIn[i] = log10(pfpIn[i]);
            else  pfLogpIn[i] = fLogEps;
            if ( pfpOut[i] > fEps ) pfLogpOut[i] = log10(pfpOut[i]);
            else  pfLogpOut[i] = fLogEps;
        }
        
        
        vComputeParzenWindFunction_E(pfpIn,pfLogpIn,pfpOut,pfLogpOut,pfE1,pfE2,iNbBin,pfGaussian,iNGaussian);
        vComputeParzenWindFunction_F(pfpIn,pfLogpIn,pfpOut,pfLogpOut,&fF1,&fF2,iNbBin,pfGaussian,iNGaussian);
        
        
        for (ix=0; ix< iNx; ix++)
            for (iy=0; iy< iNy; iy++)
        {
            iI =(int)rint(pfIm0[X(ix,iy)]);
            if (iI<=0) iI=0;
            if (fNormalizationIn>1e-4) fEvolIn = (pfE1[iI] - fF1)/ fNormalizationIn; else fEvolIn = 0.0;
            if (fNormalizationOut>1e-4) fEvolOut =(pfE2[iI] - fF2)/fNormalizationOut; else fEvolOut = 0.0;
            pfHr[X(ix,iy)] = -(fEvolIn + fEvolOut);
            }
        
        
    }
    
    
}
/****************************************/

/****************************************/
/* SEGMENTATION MODEL FOR TEXTURE IMAGES (HOUHOU-THIRAN-BRESSON MODEL) */
/****************************************/




/****************************************/
/* YOUR MODEL HERE !!!!!! */
/****************************************/

/* void vComputeYOURMODEL (
  float  *pfIm0, 
  float  *pfu,
  int    iNx,
  int    iNy,
  float  *pfHr
  )
{
} */
/****************************************/





/**********************************************/
/************** END SUB FUNCTIONS *************/
/**********************************************/













/**********************************************/
/************** MAIN FUNCTION *****************/
/**********************************************/

/****************************************/
extern void mexFunction(int iNbOut, mxArray *pmxOut[],
int iNbIn, const mxArray *pmxIn[])
{
    
  /* iNbOut: number of outputs
     pmxOut: array of pointers to output arguments */
    
  /* iNbIn: number of inputs
     pmxIn: array of pointers to input arguments */
    
    
    float   *pfIm0, *pfdx, *pfdy, *pfu, *pfuOld, *pfGb, *pfGb2;
    float   *pfbx, *pfby, *pfVecParameters;
    float   fLambda, fMu, fct1, fct2, fctST, fG, fDxu, fDyu, fs, fTemp, fSumDiff;
    float   fct1b, fct2b, fct1c, fct2c, fInvMu, fInvMu2, f1, f2, fMeanIn, fMeanOut;
    float   *pfHr, fMaxImRef, *pfpIn, *pfpOut, *pfHistoIn, *pfHistoOut, *pfLogpIn, *pfLogpOut;
    float   *pfE1, *pfE2, *pfGaussian, *pfrIn, *pfrOut, *pfuOld2, *pfTextFeat, *pfFT;
    float   fStdParzenWindow, fRangeHr, fMinHr, fMaxHr, fNyx;
    float   fDiffNew, fDiffOld, fDiffNew2, fSumU, fError;
    float   fSumUold, fDiffFirst2, fStopThres;
    int     iNy, iNx, iNdim, iDim[3], ix, iy;
    int     iNI, iX, iGS, iRD, iNbBin, iNGaussian, i;
    int     iNbItersUpdateHr, iMeanGS, iCptGS, ip;
    time_t  start_time, end_time;
    
    
    start_time = clock();
    
    
    /* Inputs */
    pfIm0 = mxGetData(pmxIn[0]); /* Given image */
    pfGb = mxGetData(pmxIn[1]); /* Edge Detector function */
    pfVecParameters = mxGetData(pmxIn[2]); /* Vector of parameters */
    
    
    
    /* Size */
    iNy = (int) pfVecParameters[0];
    iNx = (int) pfVecParameters[1];
    
    
    
    /* Choice of region segmentation model */
    iRD = (int) pfVecParameters[2]; /* region model */
    if (iRD==MODEL_SMOOTH_IMAGE)
        mexPrintf("\nRegion model: Chan-Vese model\n");
    else if (iRD==MODEL_TEXTURE_IMAGE)
    {
        mexPrintf("\nRegion model: Houhou-Thiran-Bresson model\n"); 
        iNbBin = (int) pfVecParameters[5]; /* Number of bins for histograms */
        fStdParzenWindow = pfVecParameters[6]; /* standard deviation in Parzen estimation */
        ip = pfVecParameters[7]; /* patch size */
    }
   
    
    
    
    /* Outputs */
    iNdim = 2;
    iDim[0] = iNy;
    iDim[1] = iNx;
    
    pmxOut[0] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu = mxGetData(pmxOut[0]);
    
    if (iRD==MODEL_SMOOTH_IMAGE)
    /* if Chan-Vese then outputs are the intensity means inside and outside the boundary of {u>0.5} */
    {
        iNdim = 2;
        iDim[0] = 1;
        iDim[1] = 1;
        pmxOut[1] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
        pfrIn = mxGetData(pmxOut[1]);
        pmxOut[2] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
        pfrOut = mxGetData(pmxOut[2]);
    }
    else if (iRD==MODEL_TEXTURE_IMAGE)
    /* if Houhou-Thiran-Bresson then outputs are the intensity distributions inside and outside the boundary of {u>0.5} */
    {
        iNdim = 2;
        iDim[0] = iNbBin+1;
        iDim[1] = 1;
        pmxOut[1] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
        pfrIn = mxGetData(pmxOut[1]);
        pmxOut[2] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
        pfrOut = mxGetData(pmxOut[2]);  
        
        iNdim = 2;
        iDim[0] = iNy;
        iDim[1] = iNx;
        pmxOut[3] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
        pfFT = mxGetData(pmxOut[3]);
    }
    /* else if (iRD==YOUR MODEL) PUT YOUR MODEL HERE !!!!!! */
    /* vComputeYOURMODEL(pfIm0,pfu,iNx,iNy,pfHr); */
    

    
    
    
    
    /* Memory allocation */
    pfdx = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
    if (!pfdx)
        mexPrintf("Memory allocation failure\n");
    
    pfdy = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
    if (!pfdy)
        mexPrintf("Memory allocation failure\n");
    
    pfbx = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
    if (!pfbx)
        mexPrintf("Memory allocation failure\n");
    
    pfby = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
    if (!pfby)
        mexPrintf("Memory allocation failure\n");
    
    pfuOld = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
    if (!pfuOld)
        mexPrintf("Memory allocation failure\n");
    
    pfGb2 = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
    if (!pfGb2)
        mexPrintf("Memory allocation failure\n");
    
    pfHr = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
    if (!pfHr)
        mexPrintf("Memory allocation failure\n");
    
    pfuOld = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
    if (!pfuOld)
        mexPrintf("Memory allocation failure\n");
    
    pfuOld2 = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
    if (!pfuOld2)
        mexPrintf("Memory allocation failure\n");
    
    
    
    
    
    /* Memory allocation for the Houhou-Thiran-Bresson Model */
    if (iRD==MODEL_TEXTURE_IMAGE)
    {
        iNGaussian = (int)rint(6.0* fStdParzenWindow);
        iNGaussian = (iNGaussian%2 == 1) ? iNGaussian : iNGaussian+1;
        pfGaussian = (float *) calloc( (unsigned)(iNGaussian), sizeof(float) );
        if (!pfGaussian)
            mexPrintf("Memory allocation failure\n");
        
        pfpIn = (float *) calloc( (unsigned)(iNbBin*2), sizeof(float) );
        if (!pfpIn)
            mexPrintf("Memory allocation failure\n");
        
        pfpOut = (float *) calloc( (unsigned)(iNbBin*2), sizeof(float) );
        if (!pfpOut)
            mexPrintf("Memory allocation failure\n");
        
        pfHistoIn = (float *) calloc( (unsigned)(iNbBin*2), sizeof(float) );
        if (!pfHistoIn)
            mexPrintf("Memory allocation failure\n");
        
        pfHistoOut = (float *) calloc( (unsigned)(iNbBin*2), sizeof(float) );
        if (!pfHistoOut)
            mexPrintf("Memory allocation failure\n");
        
        pfLogpIn = (float *) calloc( (unsigned)(iNbBin*2), sizeof(float) );
        if (!pfLogpIn)
            mexPrintf("Memory allocation failure\n");
        
        pfLogpOut = (float *) calloc( (unsigned)(iNbBin*2), sizeof(float) );
        if (!pfLogpOut)
            mexPrintf("Memory allocation failure\n");
        
        pfE1 = (float *) calloc( (unsigned)(iNbBin*2), sizeof(float) );
        if (!pfE1)
            mexPrintf("Memory allocation failure\n");
        
        pfE2 = (float *) calloc( (unsigned)(iNbBin*2), sizeof(float) );
        if (!pfE2)
            mexPrintf("Memory allocation failure\n");
        
        pfTextFeat = (float *) calloc( (unsigned)(iNy*iNx), sizeof(float) );
        if (!pfTextFeat)
            mexPrintf("Memory allocation failure\n");
    }

    
    
    
    
    
    
    
    
    
    /* Compute square of Edge Detector function (speed up computations) */
    for (ix=0; ix< iNx; ix++)
        for (iy=0; iy< iNy; iy++)
            pfGb2[X(ix,iy)] = SQR(pfGb[X(ix,iy)]); 
    
    
    
    
   
    
    
    if (iRD==MODEL_TEXTURE_IMAGE)
    {
        /* Compute Gaussian kernel for the KL model */
        vComputeGaussian(pfGaussian,fStdParzenWindow,iNGaussian);
        
        /* Compute Texture Feature */
        vComputeTextureFeature(pfIm0,iNx,iNy,pfTextFeat,ip,iNbBin);
        pfIm0 = pfTextFeat;
        for (ix=0; ix< iNx; ix++)
            for (iy=0; iy< iNy; iy++)
                pfFT[X(ix,iy)] = pfTextFeat[X(ix,iy)];
    }
    
    
    
    
    
    
    /* Compute init function u (any non-zero function is fine) */
    fMaxImRef = 0.0;
    for (ix=0; ix< iNx; ix++)
        for (iy=0; iy< iNy; iy++)
            if (ABS(pfIm0[X(ix,iy)])>fMaxImRef) fMaxImRef= ABS(pfIm0[X(ix,iy)]);
    for (ix=0; ix< iNx; ix++)
        for (iy=0; iy< iNy; iy++)
            pfu[X(ix,iy)] = pfIm0[X(ix,iy)]/fMaxImRef;
    
    
    
    
    
    /* Parameters for the segmentation code */
    fLambda = pfVecParameters[3];
    fMu = pfVecParameters[4];
    
    
    
    
    
    /* Normalize lambda value for the computation of Gauss-Seidel iterations */
    /* Estimate of g_r */
    if (iRD==MODEL_SMOOTH_IMAGE) /* CHAN-VESE MODEL */
        vComputeChanVese(pfIm0,pfu,iNx,iNy,pfHr,iNbItersUpdateHr,&fMeanIn,&fMeanOut,0);
    else if (iRD==MODEL_TEXTURE_IMAGE) /* HOUHOU-THIRAN-BRESSON MODEL */
        vComputeKL(pfIm0,pfu,iNx,iNy,pfHr,iNbItersUpdateHr,pfpIn,pfpOut,pfHistoIn,pfHistoOut,
        pfLogpIn,pfLogpOut,0,iNbBin,pfGaussian,iNGaussian,pfE1,pfE2);
    /* else if (iRD==YOUR MODEL) PUT YOUR MODEL HERE !!!!!! */
    /* vComputeYOURMODEL(pfIm0,pfu,iNx,iNy,pfHr); */

    /* Estimate of the range of g_r */
    fMinHr = 1e10;
    fMaxHr = -1e10;
    for (ix=1; ix< iNx-1; ix++)
        for (iy=1; iy< iNy-1; iy++)
    {
        if ( pfHr[X(ix,iy)]>fMaxHr ) fMaxHr = pfHr[X(ix,iy)];
        if ( pfHr[X(ix,iy)]<fMinHr ) fMinHr = pfHr[X(ix,iy)];
        }
    fRangeHr = fMaxHr-fMinHr;
        
    /* Normalize lambda with respect to the range of hr */
    fLambda /= fRangeHr;     
    
    
    
    
    /* Display parameters */
    mexPrintf("Image size: Ny= %i and Nx= %i\n",iNy,iNx);
    mexPrintf("Lambda= %.5f, Mu= %.5f\n",fLambda,fMu);
    if (iRD==MODEL_TEXTURE_IMAGE)
    {
        mexPrintf("NbBin= %i, StdParzenWindow= %.5f\n",iNbBin,fStdParzenWindow);
        mexPrintf("Patch size= %i\n",ip);
    }

    
    
    
    
    
    
    
    /* Constants */
    iNbItersUpdateHr = 1;  /* number of iterations to update the region function g_r */
    
    fInvMu = 1./ fMu;
    fInvMu2 = SQR(fInvMu);
    
    fct1 = 1./4.;
    fct2 = fLambda/(4.0*fMu);
    fct1b = 1./3.;
    fct2b = fLambda/(3.0*fMu);
    fct1c = 1./2.;
    fct2c = fLambda/(2.0*fMu);

    fNyx = (float)(iNy*iNx);
    
    
    if (iRD==MODEL_SMOOTH_IMAGE) /* CHAN-VESE MODEL */
        fStopThres = 1e-6;
    else if (iRD==MODEL_TEXTURE_IMAGE) /* HOUHOU-THIRAN-BRESSON MODEL */
        fStopThres = 1e-10;
        
    
    
    
    
    
    
    
    
    /* Iterative minimization scheme
    See: T. Goldstein, X. Bresson, and S. Osher, Geometric Applications of the 
    Split Bregman Method: Segmentation and Surface Reconstruction, CAM Report 09-06, 2009
    Iterative scheme:
    (u^k+1,d^k+1) = arg min int g_b |d| + lambda h_r u + mu/2 |d - grad u - b^k|^2
    b^k+1 = b^k + grad u^k+1 - d^k+1 */
    
    fDiffOld = 1e10; fDiffNew = 1e11;
    iMeanGS = 0; iCptGS = 0;
    iNI=0; /* number of iterations (outer iterations) */
    while ( ABS(fDiffNew-fDiffOld)>fStopThres && iNI<30 ) 
    {
        
        /* Store u^old for outer iterations */
        for (ix=0; ix< iNx; ix++)
            for (iy=0; iy< iNy; iy++)
                pfuOld[X(ix,iy)] = pfu[X(ix,iy)];
        
        
        /* Update region function hr */
        if (iRD==MODEL_SMOOTH_IMAGE) /* CHAN-VESE MODEL */
            vComputeChanVese(pfIm0,pfu,iNx,iNy,pfHr,iNbItersUpdateHr,&fMeanIn,&fMeanOut,iNI);
        else if (iRD==MODEL_TEXTURE_IMAGE) /* HOUHOU-THIRAN-BRESSON MODEL */
            vComputeKL(pfIm0,pfu,iNx,iNy,pfHr,iNbItersUpdateHr,pfpIn,pfpOut,pfHistoIn,pfHistoOut,
            pfLogpIn,pfLogpOut,iNI,iNbBin,pfGaussian,iNGaussian,pfE1,pfE2);
        /* else if (iRD==YOUR MODEL) PUT YOUR MODEL HERE !!!!!! */
        /* vComputeYOURMODEL(pfIm0,pfu,iNx,iNy,pfHr); */
        
        
        
        /* Compute u^{k+1} with Gauss-Seidel */
        /* Solve u^k+1 = arg min int lambda h_r u + mu/2 |d - grad u - b^k|^2 */
        /* Euler-Lagrange is  mu Laplacian u = lambda hr + mu div (b^k-d^k), u in [0,1] */
        iGS=0; /* number of iterations for Gauss-Seidel (inner iterations) */
        fError = 1e10;
        while ( fError>1e-2 && iGS<50 )  
        {
            
            /* Store u^old for inner iterations (Gauss-Seidel) */
            for (ix=0; ix< iNx; ix++)
                for (iy=0; iy< iNy; iy++)
                    pfuOld2[X(ix,iy)] = pfu[X(ix,iy)];
            
            /* Center */
            for (ix=1; ix< iNx-1; ix++)
                for (iy=1; iy< iNy-1; iy++)
            {
                iX = X(ix,iy);
                fG = pfu[X(ix+1,iy)] + pfu[X(ix-1,iy)] + pfu[X(ix,iy+1)] + pfu[X(ix,iy-1)];
                fG += pfdx[X(ix-1,iy)] - pfdx[iX] - pfbx[X(ix-1,iy)] + pfbx[iX];
                fG += pfdy[X(ix,iy-1)] - pfdy[iX] - pfby[X(ix,iy-1)] + pfby[iX];
                fG *= fct1;
                fG -= fct2* pfHr[iX];
                if(fG>1.0) fG=1.0; else if(fG<0.0) fG=0.0;
                pfu[iX] = fG;
                }
            
            /* Borders */
            ix=0;
            for (iy=1; iy< iNy-1; iy++)
            {
                iX = X(ix,iy);
                fG = pfu[X(ix+1,iy)] + pfu[X(ix,iy+1)] + pfu[X(ix,iy-1)];
                fG += - pfdx[iX] + pfbx[iX];
                fG += pfdy[X(ix,iy-1)] - pfdy[iX] - pfby[X(ix,iy-1)] + pfby[iX];
                fG *= fct1b;
                fG -= fct2b* pfHr[iX];
                if(fG>1.0) fG=1.0; else if(fG<0.0) fG=0.0;
                pfu[iX] = fG;
            }
            
            ix=iNx-1;
            for (iy=1; iy< iNy-1; iy++)
            {
                iX = X(ix,iy);
                fG = pfu[X(ix-1,iy)] + pfu[X(ix,iy+1)] + pfu[X(ix,iy-1)];
                fG += pfdx[X(ix-1,iy)] - pfdx[iX] - pfbx[X(ix-1,iy)] + pfbx[iX];
                fG += pfdy[X(ix,iy-1)] - pfdy[iX] - pfby[X(ix,iy-1)] + pfby[iX];
                fG *= fct1b;
                fG -= fct2b* pfHr[iX];
                if(fG>1.0) fG=1.0; else if(fG<0.0) fG=0.0;
                pfu[iX] = fG;
            }
            
            iy=0;
            for (ix=1; ix< iNx-1; ix++)
            {
                iX = X(ix,iy);
                fG = pfu[X(ix+1,iy)] + pfu[X(ix-1,iy)] + pfu[X(ix,iy+1)];
                fG += pfdx[X(ix-1,iy)] - pfdx[iX] - pfbx[X(ix-1,iy)] + pfbx[iX];
                fG += - pfdy[iX] + pfby[iX];
                fG *= fct1b;
                fG -= fct2b* pfHr[iX];
                if(fG>1.0) fG=1.0; else if(fG<0.0) fG=0.0;
                pfu[iX] = fG;
            }
            
            iy=iNy-1;
            for (ix=1; ix< iNx-1; ix++)
            {
                iX = X(ix,iy);
                fG = pfu[X(ix+1,iy)] + pfu[X(ix-1,iy)] + pfu[X(ix,iy-1)];
                fG += pfdx[X(ix-1,iy)] - pfdx[iX] - pfbx[X(ix-1,iy)] + pfbx[iX];
                fG += pfdy[X(ix,iy-1)] - pfdy[iX] - pfby[X(ix,iy-1)] + pfby[iX];
                fG *= fct1b;
                fG -= fct2b* pfHr[iX];
                if(fG>1.0) fG=1.0; else if(fG<0.0) fG=0.0;
                pfu[iX] = fG;
            }
            
            ix=0; iy=0;
            iX = X(ix,iy);
            fG = pfu[X(ix+1,iy)] + pfu[X(ix,iy+1)];
            fG += - pfdx[iX] + pfbx[iX];
            fG += - pfdy[iX] + pfby[iX];
            fG *= fct1c;
            fG -= fct2c* pfHr[iX];
            if(fG>1.0) fG=1.0; else if(fG<0.0) fG=0.0;
            pfu[iX] = fG;
            
            ix=iNx-1; iy=0;
            iX = X(ix,iy);
            fG = pfu[X(ix-1,iy)] + pfu[X(ix,iy+1)];
            fG += pfdx[X(ix-1,iy)] - pfdx[iX] - pfbx[X(ix-1,iy)] + pfbx[iX];
            fG += - pfdy[iX] + pfby[iX];
            fG *= fct1c;
            fG -= fct2c* pfHr[iX];
            if(fG>1.0) fG=1.0; else if(fG<0.0) fG=0.0;
            pfu[iX] = fG;
            
            ix=0; iy=iNy-1;
            iX = X(ix, iy);
            fG = pfu[X(ix+1, iy)] + pfu[X(ix, iy-1)];
            fG += - pfdx[iX] + pfbx[iX];
            fG += pfdy[X(ix, iy-1)] - pfdy[iX] - pfby[X(ix, iy-1)] + pfby[iX];
            fG *= fct1c;
            fG -= fct2c* pfHr[iX];
            if(fG>1.0) fG=1.0; else if(fG<0.0) fG=0.0;
            pfu[iX] = fG;
            
            ix=iNx-1; iy=iNy-1;
            iX = X(ix,iy);
            fG = pfu[X(ix-1,iy)] + pfu[X(ix,iy-1)];
            fG += pfdx[X(ix-1,iy)] - pfdx[iX] - pfbx[X(ix-1,iy)] + pfbx[iX];
            fG += pfdy[X(ix,iy-1)] - pfdy[iX] - pfby[X(ix,iy-1)] + pfby[iX];
            fG *= fct1c;
            fG -= fct2c* pfHr[iX];
            if(fG>1.0) fG=1.0; else if(fG<0.0) fG=0.0;
            pfu[iX] = fG;
            /* end Borders */
            
            
            /* Compute diff ( u - uold ) */
            fSumDiff = 0.0;
            fSumU = 0.0;
            fSumUold = 0.0;
            for (ix=0; ix< iNx; ix++)
                for (iy=0; iy< iNy; iy++)
                    fSumDiff += SQR(pfu[X(ix,iy)]-pfuOld2[X(ix,iy)]);
            fDiffNew2 = fSumDiff/ fNyx;
            if ( iGS==0 ) 
            {
                fDiffFirst2 = fDiffNew2;
                fDiffNew2 = 1e10;
                fError = 1e10;
            }
            else
                fError = 1.0 - ABS(fDiffNew2-fDiffFirst2)/fDiffFirst2;
            iGS++;
            
        }
        
        
        iMeanGS += iGS;
        iCptGS++;
        

        /* Compute d^{k+1} (Soft-Thresholding) and b^{k+1} (Bregman function) */
        /* d^k+1 = arg min int g_b |d| + mu/2 |d - grad u - b^k|^2 */
        /* d^k+1 = (grad u^k+1 + b^k)/ |grad u^k+1 + b^k| max(|grad u^k+1 + b^k|-1/mu,0) */
        /* b^k+1 = b^k + grad u^k+1 - d^k+1 */
        /* Center */
        for (ix=0; ix< iNx-1; ix++)
            for (iy=0; iy< iNy-1; iy++)
        {
            iX = X(ix,iy);
            /* d */
            fDxu = pfu[X(ix+1,iy)] - pfu[iX];
            fDyu = pfu[X(ix,iy+1)] - pfu[iX];
            f1 = fDxu+pfbx[iX];
            f2 = fDyu+pfby[iX];
            fs = SQR(f1)+SQR(f2);
            fctST = fInvMu2* pfGb2[iX];
            if ( fs<fctST ) { pfdx[iX]=0.0; pfdy[iX]=0.0; }
            else {
                fs = SQRT(fs);
                fctST = SQRT(fctST);
                fTemp = fs-fctST; fTemp /= fs;
                pfdx[iX] = fTemp* f1;
                pfdy[iX] = fTemp* f2; }
            /* b */
            pfbx[iX] += fDxu - pfdx[iX];
            pfby[iX] += fDyu - pfdy[iX];
            }
        
        /* Borders */
        ix=iNx-1;
        for (iy=1; iy< iNy-1; iy++)
        {
            iX = X(ix,iy);
            fDxu = 0.0;
            fDyu = pfu[X(ix,iy+1)] - pfu[iX];
            f1 = fDxu+pfbx[iX]; f2 = fDyu+pfby[iX];
            fs = SQR(f1)+SQR(f2); fctST = fInvMu2* pfGb2[iX];
            if ( fs<fctST ) { pfdx[iX]=0.0; pfdy[iX]=0.0; }
            else {
                fs = SQRT(fs); fctST = SQRT(fctST);
                fTemp = fs-fctST; fTemp /= fs;
                pfdx[iX] = fTemp* f1;
                pfdy[iX] = fTemp* f2; }
            pfbx[iX] += fDxu - pfdx[iX];
            pfby[iX] += fDyu - pfdy[iX];
        }
        
        iy=iNy-1;
        for (ix=1; ix< iNx-1; ix++)
        {
            iX = X(ix,iy);
            fDxu = pfu[X(ix+1,iy)] - pfu[iX];
            fDyu = 0.0;
            f1 = fDxu+pfbx[iX]; f2 = fDyu+pfby[iX];
            fs = SQR(f1)+SQR(f2); fctST = fInvMu2* pfGb2[iX];
            if ( fs<fctST ) { pfdx[iX]=0.0; pfdy[iX]=0.0; }
            else {
                fs = SQRT(fs); fctST = SQRT(fctST);
                fTemp = fs-fctST; fTemp /= fs;
                pfdx[iX] = fTemp* f1;
                pfdy[iX] = fTemp* f2; }
            pfbx[iX] += fDxu - pfdx[iX];
            pfby[iX] += fDyu - pfdy[iX];
        }
        
        ix=iNx-1; iy=0;
        iX = X(ix,iy);
        fDxu = 0.0;
        fDyu = pfu[X(ix,iy+1)] - pfu[iX];
        f1 = fDxu+pfbx[iX]; f2 = fDyu+pfby[iX];
        fs = SQR(f1)+SQR(f2); fctST = fInvMu2* pfGb2[iX];
        if ( fs<fctST ) { pfdx[iX]=0.0; pfdy[iX]=0.0; }
        else {
            fs = SQRT(fs); fctST = SQRT(fctST);
            fTemp = fs-fctST; fTemp /= fs;
            pfdx[iX] = fTemp* f1;
            pfdy[iX] = fTemp* f2; }
        pfbx[iX] += fDxu - pfdx[iX];
        pfby[iX] += fDyu - pfdy[iX];
        
        ix=0; iy=iNy-1;
        iX = X(ix,iy);
        fDxu = pfu[X(ix+1,iy)] - pfu[iX];
        fDyu = 0.0;
        f1 = fDxu+pfbx[iX]; f2 = fDyu+pfby[iX];
        fs = SQR(f1)+SQR(f2); fctST = fInvMu2* pfGb2[iX];
        if ( fs<fctST ) { pfdx[iX]=0.0; pfdy[iX]=0.0; }
        else {
            fs = SQRT(fs); fctST = SQRT(fctST);
            fTemp = fs-fctST; fTemp /= fs;
            pfdx[iX] = fTemp* f1;
            pfdy[iX] = fTemp* f2; }
        pfbx[iX] += fDxu - pfdx[iX];
        pfby[iX] += fDyu - pfdy[iX];
        
        ix=iNx-1; iy=iNy-1;
        iX = X(ix,iy);
        fDxu = 0.0;
        fDyu = 0.0;
        f1 = fDxu+pfbx[iX]; f2 = fDyu+pfby[iX];
        fs = SQR(f1)+SQR(f2); fctST = fInvMu2* pfGb2[iX];
        if ( fs<fctST ) { pfdx[iX]=0.0; pfdy[iX]=0.0; }
        else {
            fs = SQRT(fs); fctST = SQRT(fctST);
            fTemp = fs-fctST; fTemp /= fs;
            pfdx[iX] = fTemp* f1;
            pfdy[iX] = fTemp* f2; }
        pfbx[iX] += fDxu - pfdx[iX];
        pfby[iX] += fDyu - pfdy[iX];
        /* Borders */
        
        
        
        fSumDiff = 0.0;
        fSumU = 0.0;
        fSumUold = 0.0;
        for (ix=0; ix< iNx; ix++)
            for (iy=0; iy< iNy; iy++)
        {
            fSumDiff += SQR(pfu[X(ix,iy)]-pfuOld[X(ix,iy)]);
            fSumU += SQR(pfu[X(ix,iy)]);
            fSumUold += SQR(pfuOld[X(ix,iy)]);
            }
        fDiffOld = fDiffNew;
        fDiffNew = fSumDiff/ (fSumU*fSumUold);
        iNI++;

    }
    
    mexPrintf("number of iterations (outer iterations)= %i\n",iNI);
    mexPrintf("mean number of iterations for Gauss-Seidel (inner iterations)= %.1f\n",((float)iMeanGS)/((float)iCptGS));
    
    
    /* Outputs (see above) */
    if (iRD==MODEL_SMOOTH_IMAGE)
    {
        pfrIn[0] = fMeanIn;
        pfrOut[0] = fMeanOut;
    }
    else if (iRD==MODEL_TEXTURE_IMAGE)
    {
        for (i=0; i< iNbBin; i++)
        {
            pfrIn[i] = pfpIn[i];
            pfrOut[i] = pfpOut[i];
        }
    }

    
    /* Free memory */
    free( (float *) pfdx );
    free( (float *) pfdy );
    free( (float *) pfbx );
    free( (float *) pfby );
    free( (float *) pfGb2 );
    free( (float *) pfHr );
    free( (float *) pfuOld );
    free( (float *) pfuOld2 );
    

    /* Memory allocation for the HOUHOU-THIRAN-BRESSON Model */
    if (iRD==MODEL_TEXTURE_IMAGE)
    {
        free( (float *) pfpIn );
        free( (float *) pfpOut );
        free( (float *) pfHistoIn );
        free( (float *) pfHistoOut );
        free( (float *) pfLogpIn );
        free( (float *) pfLogpOut );
        free( (float *) pfE1 );
        free( (float *) pfE2 );
        free( (float *) pfGaussian );
        free( (float *) pfTextFeat );
    }
    

    end_time = clock();
    mexPrintf("\nComputing Time for Active Contour Segmentation= %.4f sec\n \n",difftime(end_time,start_time)/1000);
    
    
}
/****************************************/






/**********************************************/
/************** END MAIN FUNCTION *************/
/**********************************************/
