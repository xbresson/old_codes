%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name:        colorROF_deconvolution 
% Description: see Section 3.6 in
% "X. Bresson, T.F. Chan, Fast minimization of the vectorial total 
% variation norm and applications to color image processing"
% Author: 	Xavier Bresson (xbresson@math.ucla.edu)
% Last version: 08-11-06
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function colorROF_deconvolution

close all;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load the input image
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[F0,map] = imread('satellite_color.tif'); f = 2; f2 = 1.1;

[Ny,Nx,Nc] = size(F0);
F0 = double(F0);
F0 = F0/ max(max(F0(:)));






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute color kernel and blurred image
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if rem(Ny,2)==1  % ALWAYS EVEN 
    F0 = imresize(F0,[Ny+1 Nx],'nearest');
    [Ny,Nx,Nc] = size(F0)
end
if rem(Nx,2)==1  % ALWAYS EVEN 
    F0 = imresize(F0,[Ny Nx+1],'nearest');
    [Ny,Nx,Nc] = size(F0)
end

% parameter
std = 2; % standard deviation for blurring
Ng = ceil(6*std)+1; 
if rem(Ng,2)==0; Ng=Ng+1; end; % ALWAYS ODD 
Gaussian = fspecial('gaussian',[Ng Ng],std);
Ng2=(Ng-1)/2;
Nyc=Ny/2+1;
Nxc=Nx/2+1;
G=zeros(Ny,Nx); G(Nyc-Ng2:Nyc+Ng2,Nxc-Ng2:Nxc+Ng2) = Gaussian; Gaussian = G;
G = G/ sum(sum(G));


% blurred color image
F = zeros(Ny,Nx,Nc);
F(:,:,1) = abs(ifftshift(ifft2(fft2(F0(:,:,1)).*fft2(G))));
F(:,:,2) = abs(ifftshift(ifft2(fft2(F0(:,:,2)).*fft2(G))));
F(:,:,3) = abs(ifftshift(ifft2(fft2(F0(:,:,3)).*fft2(G))));
FClean = F;

% color kernel
A = zeros(Ny,Nx,Nc);
A(:,:,1) = G;
A(:,:,2) = G;
A(:,:,3) = G;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add noise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parameter
k = 0.02; % noise

% noisy image
F = F + k*randn(size(F0));

display = 1;
if display == 1
  cpt_fig = 1;
  figure(cpt_fig); clf; 
  subplot(2,2,1); imshow(F0); title('Input image'); hold on;  
  subplot(2,2,2); imshow(FClean); title('Blurred image'); hold on;  
  subplot(2,2,3); imshow(F); title('Blurred and noisy image');  hold on;  
  truesize(cpt_fig,[round(f2*Ny) round(f2*Nx)]);
  %pause;
end













%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% General Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% satellite: std=2 k=0.02 25Iters
dt = 1/4; % theoretical temporal step in ROF minimization = 1/8 but 1/4 is fine
eta = 1e2/4; % scale paramater in ROF energy
lambdaDivEta = 1e-1; % deconvolution paramater



FFTAc1 = fft2(A(:,:,1)); 
FFTAc2 = fft2(A(:,:,2)); 
FFTAc3 = fft2(A(:,:,3));

A31 = abs(FFTAc1).^2 + lambdaDivEta;
A32 = abs(FFTAc2).^2 + lambdaDivEta; 
A33 = abs(FFTAc3).^2 + lambdaDivEta;

A11 = conj(FFTAc1).*fft2(F(:,:,1));
A12 = conj(FFTAc2).*fft2(F(:,:,2));
A13 = conj(FFTAc3).*fft2(F(:,:,3));

v11 = A11./A31; v11 = ifftshift(ifft2(v11));
v12 = A12./A32; v12 = ifftshift(ifft2(v12));
v13 = A13./A33; v13 = ifftshift(ifft2(v13));






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Init
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pxu = zeros(size(F));
pyu = zeros(size(F));
v = zeros(size(F));
u = zeros(size(F));

MinF0 = min(FClean(:));
MaxF0 = max(FClean(:));
MinBlurred = min(F(:));
MaxBlurred = max(F(:));






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
diff = 1;
cpt = 0;
uold = F;

tic
while diff>1e-5
    
    cpt = cpt + 1
    
    % new u
    divp = ( backwardx(pxu,Nx,Ny) + backwardy(pyu,Nx,Ny) );
    Term = divp - eta*v;
    term1 = forwardx(Term,Nx,Ny);
    term2 = forwardy(Term,Nx,Ny);  
    norm = sqrt(sum(term1.^2 + term2.^2,3));    
    denom(:,:,1)=1+dt*norm; denom(:,:,2)=denom(:,:,1); denom(:,:,3)=denom(:,:,1);
    pxu = (pxu+dt*term1)./denom;
    pyu = (pyu+dt*term2)./denom;
    u = v - divp/eta;
    u(:,1,:)=u(:,2,:); u(:,Nx,:)=u(:,Nx-1,:); u(1,:,:)=u(2,:,:); u(Ny,:,:)=u(Ny-1,:,:); 
     
    % new v    
    A2 = lambdaDivEta* fft2(u(:,:,1)); 
    v(:,:,1) = v11 + ifft2(A2./A31); 
    A2 = lambdaDivEta* fft2(u(:,:,2)); 
    v(:,:,2) = v12 + ifft2(A2./A32); 
    A2 = lambdaDivEta* fft2(u(:,:,3)); 
    v(:,:,3) = v13 + ifft2(A2./A33); 
    v(v<0) = 0;
    
    
    display_image = 2;
    if display_image == 1
        MinU = min(min(u(:)));
        MaxU = max(max(u(:)));
        MinV = min(min(v(:)));
        MaxV = max(max(v(:)));

        if rem(cpt,1)==0
            cpt_fig = 1000;
            figure(cpt_fig); clf;
            subplot(2,2,1); imshow(F0); title(['MinF0= ',num2str(MinF0,3), '  MaxF0= ',num2str(MaxF0,3)]); hold on; %colorbar;
            subplot(2,2,2); imshow(F); title(['MinBlurred= ',num2str(MinBlurred,3), '  MaxBlurred= ',num2str(MaxBlurred,3)]); hold on; %colorbar;
            subplot(2,2,3); imshow(u); title(['MinU= ',num2str(MinU,3), '  MaxU= ',num2str(MaxU,3)]); hold on; %colorbar;
            subplot(2,2,4); imshow(v); title(['MinV= ',num2str(MinV,3), '  MaxV= ',num2str(MaxV,3)]); hold on; %colorbar;
            truesize(cpt_fig,[round(f2*Ny) round(f2*Nx)]);
            pause(0.01)
        end
    end
    
    diff = sqrt( sum(sum(sum((u-uold).^2))) )/(Ny*Nx)
    uold = u;
    %pause
    
end
toc



MinU = min(min(u(:)));
MaxU = max(max(u(:)));
MinV = min(min(v(:)));
MaxV = max(max(v(:)));

cpt_fig = 1000;
figure(cpt_fig); clf;
subplot(2,2,1); imshow(F0); title(['MinF0= ',num2str(MinF0,3), '  MaxF0= ',num2str(MaxF0,3)]); hold on; %colorbar;
subplot(2,2,2); imshow(F); title(['MinBlurred= ',num2str(MinBlurred,3), '  MaxBlurred= ',num2str(MaxBlurred,3)]); hold on; %colorbar;
subplot(2,2,3); imshow(u); title(['MinU= ',num2str(MinU,3), '  MaxU= ',num2str(MaxU,3)]); hold on; %colorbar;
truesize(cpt_fig,[round(f2*Ny) round(f2*Nx)]);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sub functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dx]=backwardx(u,Nx,Ny)

dx = u;
dx(:,2:Nx-1,:)=( u(:,2:Nx-1,:) - u(:,1:Nx-2,:) );
dx(:,Nx,:) = -u(:,Nx-1,:);


function [dy]=backwardy(u,Nx,Ny)

dy = u;
dy(2:Ny-1,:,:)=( u(2:Ny-1,:,:) - u(1:Ny-2,:,:) );
dy(Ny,:,:) = -u(Ny-1,:,:);



function [dx]=forwardx(u,Nx,Ny)

dx = zeros(size(u));
dx(:,1:Nx-1,:)=( u(:,2:Nx,:) - u(:,1:Nx-1,:) );



function [dy]=forwardy(u,Nx,Ny)

dy = zeros(size(u));
dy(1:Ny-1,:,:)=( u(2:Ny,:,:) - u(1:Ny-1,:,:) );

