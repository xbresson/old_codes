addpath(genpath('wavelet\'));
addpath(genpath('GPSR_5.0\'));

addpath(genpath('images\'));
addpath(genpath('mex\'));
addpath(genpath('utilities\'));
addpath(genpath('solvers\'));



