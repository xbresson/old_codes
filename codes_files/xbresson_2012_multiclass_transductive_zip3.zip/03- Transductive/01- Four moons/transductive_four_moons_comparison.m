
 % addpath('01- Transductive Cheeger (MOON)');
 % addpath('02- Transductive Potts (MOON)');
 % addpath('03- Transductive spectral (MOON)');
 

function transductive_four_moons_comparison

clear


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MOONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


save_data = 2;
if save_data == 1
    
    % 4 moons
    tN=4000;
    dim=100;
    x=linspace(0,pi,tN/4)'; % linearly spaced vector
    T=[1.5*cos(x) sin(x)];
    T=cat(1,T,[1.5*cos(x)+2 0.35-sin(x)]);
    T=cat(1,T,[1.5*cos(x)-2 0.35-sin(x)]);
    T=cat(1,T,[1.5*cos(x)+4 sin(x)]);
    sig=0.015;
    T(:,3:dim)=0;
    T=T+sqrt(sig)*randn(tN,dim); % noise
    
    solution(1:tN/4)=0;
    solution(tN/4+1:tN/2)=1;
    solution(tN/2+1:3*tN/4)=2;
    solution(3*tN/4+1:tN)=3;
    
    file = 'four_moons.mat';
    save(file,'T','solution','tN');
    
else
    
    file = 'four_moons.mat';
    load(file,'T','solution','tN');
    
end



display = 2;
if display == 1
    figure(1); clf; s2=3; A=T'; N=size(A); % MOONS
    title('graph'); v=solution;
    scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');
    pause
end







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check results: post-processing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

check_results = 2;
if check_results == 1
    
    file = 'results_transductive_4moons.mat';
    load(file,'resultsTransCheeger','resultsTransCheegerPerc',...
        'resultsTransPotts','resultsTransPottsPerc',...
        'resultsTransSpectral','resultsTransSpectralPerc');
    
    
    meanresultsTransCheegerPerc = mean(resultsTransCheegerPerc')
    meanresultsTransPottsPerc = mean(resultsTransPottsPerc')
    meanresultsTransSpectralPerc = mean(resultsTransSpectralPerc')
    
    return
    
end









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test transductive learning algorithms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


TabNbLabels = [1 3 6 10 25 50 100 200];
sizeTabNbLabels = size(TabNbLabels,2);
nbTestsPerLabel = 10;



resultsTransCheeger = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransCheegerPerc = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransPotts = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransPottsPerc = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransSpectral = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransSpectralPerc = zeros(sizeTabNbLabels,nbTestsPerLabel);



for kNbLabels=1:sizeTabNbLabels
    
    
    for kTest=1:nbTestsPerLabel
        
        
        kNbLabels
        kTest
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % extract a small set of labels for classification
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        nbTrainingPts = TabNbLabels(kNbLabels)
        %pause
        
        junk = randperm(1000);
        indexTrainingNumbers{1} = junk(1:nbTrainingPts);
        junk = 1000+randperm(1000);
        indexTrainingNumbers{2} = junk(1:nbTrainingPts);
        junk = 2000+randperm(1000);
        indexTrainingNumbers{3} = junk(1:nbTrainingPts);
        junk = 3000+randperm(1000);
        indexTrainingNumbers{4} = junk(1:nbTrainingPts);
        

        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % construct the graph of data
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%8%%%%%%%%%%%%%%%%%%
        
        opts.kNN=10;
        opts.alpha=1;
        opts.kNNdelta=10;
        
        tic
        fprintf('building weights... \n');
        [w NNIdxs]=fgf(T,opts);
        toc
        
        tN = size(w,2);
        
        
        
        
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Cheeger
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        disp(' ');
        disp('---------------------------');
        disp('Cheeger');
        disp('---------------------------');
        
       
        
        % Four moons
        rd=1e1;
        rv=1e2;
        K=4; rm=6*K/tN;
        ns=150;
        nsi=10;
        maxiter=50;
        V2 = tN/K;
        p = 0.4;
        Maxdiffl = 1e-3;
        Maxdiffinner = 1e-7;
        Maxdiffu = 1e-6;
        MaxdiffC = 0;
        
        
        VecParameters = [rd rv rm ns nsi maxiter V2 p Maxdiffl Maxdiffinner Maxdiffu MaxdiffC];
        
        
        tic
        [classification_error,classification_error_percentage] = ...
            transductive_cheeger_4p_comparison(VecParameters,w,indexTrainingNumbers,solution)
        toc
        
        
        resultsTransCheeger(kNbLabels,kTest) = classification_error;
        resultsTransCheegerPerc(kNbLabels,kTest) = classification_error_percentage;
        
        
        file = 'results_transductive_4moons.mat';
        save(file,'resultsTransCheeger','resultsTransCheegerPerc',...
            'resultsTransPotts','resultsTransPottsPerc','resultsTransSpectral','resultsTransSpectralPerc');
        
    
        
        
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Potts
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        disp(' ');
        disp('---------------------------');
        disp('Potts');
        disp('---------------------------');
        
        
        
        % Four moons
        rd=1e1;
        rv=1e2;
        nsi=50;
        maxiter=500;
        p = 0.4;
        Maxdiffu = 1e-6;
        MaxdiffC = 0;
        
        
        VecParameters = [rd rv nsi maxiter p Maxdiffu MaxdiffC];
        
        
        tic
        [classification_error,classification_error_percentage] = ...
            transductive_Potts_4p_comparison(VecParameters,w,indexTrainingNumbers,solution)
        toc
        
        
        resultsTransPotts(kNbLabels,kTest) = classification_error;
        resultsTransPottsPerc(kNbLabels,kTest) = classification_error_percentage;
        
        
        file = 'results_transductive_4moons.mat';
        save(file,'resultsTransCheeger','resultsTransCheegerPerc',...
            'resultsTransPotts','resultsTransPottsPerc','resultsTransSpectral','resultsTransSpectralPerc');
        
        
        
        
        
        
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Spectral
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        disp(' ');
        disp('---------------------------');
        disp('Spectral');
        disp('---------------------------');
        
        
        
        
        tic
        [classification_error,classification_error_percentage] = ...
            transductive_spectral_4p_comparison(w,indexTrainingNumbers,solution)
        toc

        
        resultsTransSpectral(kNbLabels,kTest) = classification_error;
        resultsTransSpectralPerc(kNbLabels,kTest) = classification_error_percentage;
        
        
        file = 'results_transductive_4moons.mat';
        save(file,'resultsTransCheeger','resultsTransCheegerPerc',...
            'resultsTransPotts','resultsTransPottsPerc','resultsTransSpectral','resultsTransSpectralPerc');
  

        
        
        
        
    end
   
    
end


TabNbLabels
meanresultsTransCheegerPerc = mean(resultsTransCheegerPerc')
meanresultsTransPottsPerc = mean(resultsTransPottsPerc')
meanresultsTransSpectralPerc = mean(resultsTransSpectralPerc')


end





