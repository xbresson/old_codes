

function [classification_error,classification_error_percentage] = ...
            transductive_cheeger_4p_comparison(VecParameters,w,indexTrainingNumbers,solution)


        
        
        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


rd=VecParameters(1);
rv=VecParameters(2);
rm=VecParameters(3);
ns=VecParameters(4);
nsi=VecParameters(5);
maxiter=VecParameters(6);
V2 = VecParameters(7);
p = VecParameters(8);
Maxdiffl = VecParameters(9);
Maxdiffinner = VecParameters(10);
Maxdiffu = VecParameters(11);
MaxdiffC = VecParameters(12);


tN = size(w,1);







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pre-computed function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rdinv = 1/rd;
rvinv = 1/rv;

w=triu(w,1);
[r c v]=find(w);
n=length(r);
Dr=[1:n 1:n];
Dc(1:n)=r;
Dc(n+1:2*n)=c;
Dv(1:n)=2*v;
Dv(n+1:2*n)=-2*v;
D=sparse(Dr,Dc,Dv,n,tN);
Dt=D';
md=@(x,type) rv*x+rd*(Dt*(D*x));





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initial function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

r=1; md2=@(x,type) r*x+1*r*(Dt*(D*x));

u1=zeros(tN,1); u1(indexTrainingNumbers{1})=1;
u2=zeros(tN,1); u2(indexTrainingNumbers{2})=1;
u3=zeros(tN,1); u3(indexTrainingNumbers{3})=1;
u4=zeros(tN,1); u4(indexTrainingNumbers{4})=1;
[u1 flag]=pcg(md2,u1,1e-6,50,[],[],u1); u1=u1-mean(u1); u1(u1>0)=1; u1(u1<=0)=0;
[u2 flag]=pcg(md2,u2,1e-6,50,[],[],u2); u2=u2-mean(u2); u2(u2>0)=1; u2(u2<=0)=0;
[u3 flag]=pcg(md2,u3,1e-6,50,[],[],u3); u3=u3-mean(u3); u3(u3>0)=1; u3(u3<=0)=0;
[u4 flag]=pcg(md2,u4,1e-6,50,[],[],u4); u4=u4-mean(u4); u4(u4>0)=1; u4(u4<=0)=0;
v1=u1; l1=sum(abs(D*u1))/sum(abs(u1-median(u1)));
v2=u2; l2=sum(abs(D*u2))/sum(abs(u2-median(u2)));
v3=u3; l3=sum(abs(D*u3))/sum(abs(u3-median(u3)));
v4=u4; l4=sum(abs(D*u4))/sum(abs(u4-median(u4)));
u=u1; C=double(u>0.5); C1=C';
u=u2; C=double(u>0.5); C2=C';
u=u3; C=double(u>0.5); C3=C';
u=u4; C=double(u>0.5); C4=C';   





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Cheeger transductive learning algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

C1old = C1; C2old = C2; C3old = C3; C4old = C4; 
diffl=1; k=-1; diffC=1; diffu=1;
while ( diffl>Maxdiffl && k<maxiter && diffC>0 && diffu>Maxdiffu )
    
    k=k+1;
    
    l1old = l1;
    l2old = l2;
    l3old = l3;
    l4old = l4;
    
    u1Outer = u1;
    u2Outer = u2;
    u3Outer = u3;
    u4Outer = u4;
    
    ad1 = zeros(size(D*u1)); av1 = zeros(size(u1)); am1 = 0;
    ad2 = zeros(size(D*u2)); av2 = zeros(size(u2)); am2 = 0;
    ad3 = zeros(size(D*u3)); av3 = zeros(size(u3)); am3 = 0;
    ad4 = zeros(size(D*u4)); av4 = zeros(size(u4)); am4 = 0;
    
    diffinner=1; j=0;
    while ( diffinner>Maxdiffinner && j<ns )
        
        j=j+1;
        u1old=u1; v1old=v1;
        u2old=u2; v2old=v2;
        u3old=u3; v3old=v3;
        u4old=u4; v4old=v4;
        
        
        % new d
        d1 = shrink(D*u1-rdinv*ad1,rdinv);
        d2 = shrink(D*u2-rdinv*ad2,rdinv);
        d3 = shrink(D*u3-rdinv*ad3,rdinv);
        d4 = shrink(D*u4-rdinv*ad4,rdinv);
        
        % new u
        [u1 flag]=pcg(md,rv*v1+av1 +rd*Dt*d1+Dt*ad1,1e-6,nsi,[],[],u1);
        [u2 flag]=pcg(md,rv*v2+av2 +rd*Dt*d2+Dt*ad2,1e-6,nsi,[],[],u2);
        [u3 flag]=pcg(md,rv*v3+av3 +rd*Dt*d3+Dt*ad3,1e-6,nsi,[],[],u3);
        [u4 flag]=pcg(md,rv*v4+av4 +rd*Dt*d4+Dt*ad4,1e-6,nsi,[],[],u4);
        

        % new v
        v1 = unshrink(u1-rvinv*av1-rvinv*am1,rvinv*l1); v1(v1>1)=1; v1(v1<0)=0; v1=(v1-min(v1))/(max(v1)-min(v1));
        v2 = unshrink(u2-rvinv*av2-rvinv*am2,rvinv*l2); v2(v2>1)=1; v2(v2<0)=0; v2=(v2-min(v2))/(max(v2)-min(v2));
        v3 = unshrink(u3-rvinv*av3-rvinv*am3,rvinv*l3); v3(v3>1)=1; v3(v3<0)=0; v3=(v3-min(v3))/(max(v3)-min(v3));
        v4 = unshrink(u4-rvinv*av4-rvinv*am4,rvinv*l4); v4(v4>1)=1; v4(v4<0)=0; v4=(v4-min(v4))/(max(v4)-min(v4));
        [v1 v2 v3 v4] = simplex_projection_4p_mex(single(v1),single(v2),single(v3),single(v4),single(tN));
        v1=double(v1); v2=double(v2); v3=double(v3); v4=double(v4);
        
        
        % training data
        i=1; u1(indexTrainingNumbers{i})=1; u2(indexTrainingNumbers{i})=0; 
        u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=1; v2(indexTrainingNumbers{i})=0; 
        v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0;
        i=2; u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=1; 
        u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=1; 
        v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0;
        i=3; u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; 
        u3(indexTrainingNumbers{i})=1; u4(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; 
        v3(indexTrainingNumbers{i})=1; v4(indexTrainingNumbers{i})=0;
        i=4; u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; 
        u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=1; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; 
        v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=1;
        
        % Lagrange multipliers
        ad1 = ad1+rd*(d1-D*u1); av1 = av1+rv*(v1-u1); am1 = max(0,am1+rm*(sum(v1)-V2));
        ad2 = ad2+rd*(d2-D*u2); av2 = av2+rv*(v2-u2); am2 = max(0,am2+rm*(sum(v2)-V2));
        ad3 = ad3+rd*(d3-D*u3); av3 = av3+rv*(v3-u3); am3 = max(0,am3+rm*(sum(v3)-V2));
        ad4 = ad4+rd*(d4-D*u4); av4 = av4+rv*(v4-u4); am4 = max(0,am4+rm*(sum(v4)-V2));
        
        % stopping condition
        diffu1 = sum((u1old-u1).^2)/tN; diffv1 = sum((v1old-v1).^2)/tN;
        diffu2 = sum((u2old-u2).^2)/tN; diffv2 = sum((v2old-v2).^2)/tN;
        diffu3 = sum((u3old-u3).^2)/tN; diffv3 = sum((v3old-v3).^2)/tN;
        diffu4 = sum((u4old-u4).^2)/tN; diffv4 = sum((v4old-v4).^2)/tN;
        diffinner = (diffu1+diffv1+diffu2+diffv2+diffu3+diffv3+diffu4+diffv4)/8;
        
        
    end % END inner iterations
    
    
    % new lagrange multiplier
    l1 = l1- p*(l1-sum(abs(D*u1))/sum(abs(u1)));
    l2 = l2- p*(l2-sum(abs(D*u2))/sum(abs(u2)));
    l3 = l3- p*(l3-sum(abs(D*u3))/sum(abs(u3)));
    l4 = l4- p*(l4-sum(abs(D*u4))/sum(abs(u4)));
    
    
    % find classes
    C1=zeros(1,tN);
    C2=zeros(1,tN);
    C3=zeros(1,tN);
    C4=zeros(1,tN);
    for i=1:tN
        U=[u1(i) u2(i) u3(i) u4(i)];
        [junk J] = find(U==max(U));
        if J(1)==1
            C1(i)=1; C2(i)=0; C3(i)=0; C4(i)=0;
        elseif J(1)==2
            C1(i)=0; C2(i)=1; C3(i)=0; C4(i)=0;
        elseif J(1)==3
            C1(i)=0; C2(i)=0; C3(i)=1; C4(i)=0;
        elseif J(1)==4
            C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=1;
        end
    end
    
    
    % stopping condition
    diffl1 = abs(l1old-l1); 
    diffl2 = abs(l2old-l2); 
    diffl3 = abs(l3old-l3); 
    diffl4 = abs(l4old-l4); 
    diffl = (diffl1+diffl2+diffl3+diffl4)/4;
    
    
    % stopping condition
    diffu1 = sum((u1Outer-u1).^2)/tN; 
    diffu2 = sum((u2Outer-u2).^2)/tN;
    diffu3 = sum((u3Outer-u3).^2)/tN;
    diffu4 = sum((u4Outer-u4).^2)/tN;
    diffu = (diffu1+diffu2+diffu3+diffu4)/4;
    
    
    % stopping condition
    if (rem(k,3)==0)
        diffC1 = sum(abs(C1old-C1));
        diffC2 = sum(abs(C2old-C2));
        diffC3 = sum(abs(C3old-C3));
        diffC4 = sum(abs(C4old-C4));
        diffC = (diffC1+diffC2+diffC3+diffC4)/4;
        C1old = C1;
        C2old = C2;
        C3old = C3;
        C4old = C4;
    end
    
    
    
    % classification error
    v = zeros(tN,4);
    v(:,1) = C1;
    v(:,2) = C2;
    v(:,3) = C3;
    v(:,4) = C4;
    mincent = zeros(1,tN);
    Np=4;
    for pp=1:Np
        mincent(v(:,pp)==1)=pp;
    end
    % confusion matrix
    x = confma(mincent,solution);
    for ki=1:Np
        [ju juu]=max(x(ki,:));
        tx=x(ki,:);
        tx(juu)=0;
        ern(ki)=sum(tx);
    end
    
    
    
end % END while ( diffl>1e-14 && k<maxiter )


kNbIterCheeger = k
classification_error = sum(ern);
classification_error_percentage = classification_error*100/tN;


end








function d = shrink(e,rinv)


s = abs(e);
ss = s-rinv;
ss = ss.*(ss>0);
s = s+(s<rinv);
ss = ss./s;
d = ss.*e;


end


function v=unshrink(e,r)


s = abs(e);
s = s+(s<1e-10);
ss = r./s;
v = e.*(1+ss);


end







