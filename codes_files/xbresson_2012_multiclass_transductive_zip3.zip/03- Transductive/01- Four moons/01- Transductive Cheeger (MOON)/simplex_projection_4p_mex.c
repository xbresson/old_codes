
/***************************************************************************/
/* Name:                                                                   */
/* Description:                                                            */
/* Date:          11-11-03                                                 */
/* Author:        Xavier Bresson (xbresson@cityu.edu.hk)                   */
/***************************************************************************/


//  mex simplex_projection_4p_mex.c 


#include <stdio.h>
#include <stdlib.h>
#include <mex.h>
#include <math.h>
#include <time.h>


 
#define YES 0
#define NO 1

#define X(ix,iy) (ix)*iNy+ (iy)


#define ABS(x) ( (x) > 0.0 ? x : -(x) )




/****************************************/
extern void mexFunction(int iNbOut, mxArray *pmxOut[],
int iNbIn, const mxArray *pmxIn[])
{
    
  /* iNbOut: number of outputs
     pmxOut: array of pointers to output arguments */
    
  /* iNbIn: number of inputs
     pmxIn: array of pointers to input arguments */
    
    
    float   *pfu1, *pfu2, *pfu3, *pfu4;
    float   *pfu1New, *pfu2New, *pfu3New, *pfu4New;
    float   *pfx, *pfxt, fNI, ft;
    float   *pfVecGeneralParameters;
    int     itN, iNdim, iDim[3], ix, i;
    int     *piI;
    
    
    time_t  start_time, end_time;
    
    
    start_time = clock();
    
    
    
    pfu1 = mxGetData(pmxIn[0]);
    
    pfu2 = mxGetData(pmxIn[1]);
    
    pfu3 = mxGetData(pmxIn[2]);
    
    pfu4 = mxGetData(pmxIn[3]);
    
    pfVecGeneralParameters = mxGetData(pmxIn[4]);
    
    
    
    itN = (int) pfVecGeneralParameters[0];
    //mexPrintf("iNy= %i, iNx= %i\n",iNy,iNx);
    
    
    
    iNdim = 2;
    iDim[0] = itN;
    iDim[1] = 1;
    
    pmxOut[0] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu1New = mxGetData(pmxOut[0]);
    pmxOut[1] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu2New = mxGetData(pmxOut[1]);
    pmxOut[2] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu3New = mxGetData(pmxOut[2]);
    pmxOut[3] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu4New = mxGetData(pmxOut[3]);
    
    
    piI = (int *) calloc( (unsigned)(4), sizeof(int) );
    if (!piI)
        mexPrintf("Memory allocation failure\n");
    
    pfx = (float *) calloc( (unsigned)(4), sizeof(float) );
    if (!pfx)
        mexPrintf("Memory allocation failure\n");
    pfxt = (float *) calloc( (unsigned)(4), sizeof(float) );
    if (!pfxt)
        mexPrintf("Memory allocation failure\n");
    


    
    
    
    for (ix=0; ix< itN; ix++){
        
        if (pfu1[ix]<0.0) pfx[0]=0.0; else pfx[0]=pfu1[ix];
        if (pfu2[ix]<0.0) pfx[1]=0.0; else pfx[1]=pfu2[ix];
        if (pfu3[ix]<0.0) pfx[2]=0.0; else pfx[2]=pfu3[ix];
        if (pfu4[ix]<0.0) pfx[3]=0.0; else pfx[3]=pfu4[ix];
        pfxt[0]=-1.0; pfxt[1]=-1.0; pfxt[2]=-1.0; pfxt[3]=-1.0;
        for (i=0; i< 4; i++) piI[i]=0;
        fNI=0;
        while (pfxt[0]<0 || pfxt[1]<0 || pfxt[2]<0 || pfxt[3]<0) {
            ft = (pfx[0]+pfx[1]+pfx[2]+pfx[3]-1.0)/(4.0-fNI);
            for (i=0; i< 4; i++)
                if (piI[i]==0)
                    pfxt[i]=pfx[i]-ft;
                else
                    pfxt[i]=0.0;
            for (i=0; i< 4; i++)
                if (pfxt[i]>=0.0)
                    pfx[i]=pfxt[i];
                else {
                pfx[i]=0.0;
                piI[i]=1;
                fNI+=1.0;
                }
        }
        pfu1New[ix]=pfxt[0];
        pfu2New[ix]=pfxt[1];
        pfu3New[ix]=pfxt[2];
        pfu4New[ix]=pfxt[3];
        
        }

    
    
    
    free( (int *) piI );
    free( (float *) pfx );
    free( (float *) pfxt );
    
    
    end_time = clock();
    //mexPrintf("\nComputing Time= %.3f sec\n \n",difftime(end_time,start_time)/1000);


}
/****************************************/






/**************************************** End of file ****************************************/
