
/***************************************************************************/
/* Name:                                                                   */
/* Description:                                                            */
/* Date:          11-11-13                                                 */
/* Author:        Xavier Bresson (xbresson@cityu.edu.hk)                   */
/***************************************************************************/


//  mex simplex_projection_10p_mex.c 


#include <stdio.h>
#include <stdlib.h>
#include <mex.h>
#include <math.h>
#include <time.h>


 
#define YES 0
#define NO 1




/****************************************/
extern void mexFunction(int iNbOut, mxArray *pmxOut[],
int iNbIn, const mxArray *pmxIn[])
{
    
  /* iNbOut: number of outputs
     pmxOut: array of pointers to output arguments */
    
  /* iNbIn: number of inputs
     pmxIn: array of pointers to input arguments */
    
    
    float   *pfu1, *pfu2, *pfu3, *pfu4, *pfu5;
    float   *pfu6, *pfu7, *pfu8, *pfu9, *pfu10;
    float   *pfu1New, *pfu2New, *pfu3New, *pfu4New, *pfu5New;
    float   *pfu6New, *pfu7New, *pfu8New, *pfu9New, *pfu10New;
    float   *pfx, *pfxt, fNI, ft;
    float   *pfVecGeneralParameters;
    int     itN, iNdim, iDim[3], ix, i;
    int     *piI;
    
    
    time_t  start_time, end_time;
    
    
    start_time = clock();
    
    
    
    pfu1 = mxGetData(pmxIn[0]);
    
    pfu2 = mxGetData(pmxIn[1]);
    
    pfu3 = mxGetData(pmxIn[2]);
    
    pfu4 = mxGetData(pmxIn[3]);
    
    pfu5 = mxGetData(pmxIn[4]);
    
    pfu6 = mxGetData(pmxIn[5]);
    
    pfu7 = mxGetData(pmxIn[6]);
    
    pfu8 = mxGetData(pmxIn[7]);
    
    pfu9 = mxGetData(pmxIn[8]);
    
    pfu10 = mxGetData(pmxIn[9]);
    
    pfVecGeneralParameters = mxGetData(pmxIn[10]);
    
    
    
    itN = (int) pfVecGeneralParameters[0];
    //mexPrintf("iNy= %i, iNx= %i\n",iNy,iNx);
    
    
    
    iNdim = 2;
    iDim[0] = itN;
    iDim[1] = 1;
    
    pmxOut[0] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu1New = mxGetData(pmxOut[0]);
    pmxOut[1] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu2New = mxGetData(pmxOut[1]);
    pmxOut[2] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu3New = mxGetData(pmxOut[2]);
    pmxOut[3] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu4New = mxGetData(pmxOut[3]);
    pmxOut[4] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu5New = mxGetData(pmxOut[4]);
    pmxOut[5] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu6New = mxGetData(pmxOut[5]);
    pmxOut[6] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu7New = mxGetData(pmxOut[6]);
    pmxOut[7] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu8New = mxGetData(pmxOut[7]);
    pmxOut[8] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu9New = mxGetData(pmxOut[8]);
    pmxOut[9] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
    pfu10New = mxGetData(pmxOut[9]);
    
    
    piI = (int *) calloc( (unsigned)(10), sizeof(int) );
    if (!piI)
        mexPrintf("Memory allocation failure\n");
    
    pfx = (float *) calloc( (unsigned)(10), sizeof(float) );
    if (!pfx)
        mexPrintf("Memory allocation failure\n");
    pfxt = (float *) calloc( (unsigned)(10), sizeof(float) );
    if (!pfxt)
        mexPrintf("Memory allocation failure\n");
    


    
    
    
    for (ix=0; ix< itN; ix++){
        
        if (pfu1[ix]<0.0) pfx[0]=0.0; else pfx[0]=pfu1[ix];
        if (pfu2[ix]<0.0) pfx[1]=0.0; else pfx[1]=pfu2[ix];
        if (pfu3[ix]<0.0) pfx[2]=0.0; else pfx[2]=pfu3[ix];
        if (pfu4[ix]<0.0) pfx[3]=0.0; else pfx[3]=pfu4[ix];
        if (pfu5[ix]<0.0) pfx[4]=0.0; else pfx[4]=pfu5[ix];
        if (pfu6[ix]<0.0) pfx[5]=0.0; else pfx[5]=pfu6[ix];
        if (pfu7[ix]<0.0) pfx[6]=0.0; else pfx[6]=pfu7[ix];
        if (pfu8[ix]<0.0) pfx[7]=0.0; else pfx[7]=pfu8[ix];
        if (pfu9[ix]<0.0) pfx[8]=0.0; else pfx[8]=pfu9[ix];
        if (pfu10[ix]<0.0) pfx[9]=0.0; else pfx[9]=pfu10[ix];
        pfxt[0]=-1.0; pfxt[1]=-1.0; pfxt[2]=-1.0; pfxt[3]=-1.0; pfxt[4]=-1.0;
        pfxt[5]=-1.0; pfxt[6]=-1.0; pfxt[7]=-1.0; pfxt[8]=-1.0; pfxt[9]=-1.0;
        for (i=0; i< 10; i++) piI[i]=0;
        fNI=0;
        while (pfxt[0]<0 || pfxt[1]<0 || pfxt[2]<0 || pfxt[3]<0 || pfxt[4]<0
                || pfxt[5]<0 || pfxt[6]<0 || pfxt[7]<0 || pfxt[8]<0 || pfxt[9]<0) {
            ft = (pfx[0]+pfx[1]+pfx[2]+pfx[3]+pfx[4]
                    +pfx[5]+pfx[6]+pfx[7]+pfx[8]+pfx[9]-1.0)/(10.0-fNI);
            for (i=0; i< 10; i++)
                if (piI[i]==0)
                    pfxt[i]=pfx[i]-ft;
                else
                    pfxt[i]=0.0;
            for (i=0; i< 10; i++)
                if (pfxt[i]>=0.0)
                    pfx[i]=pfxt[i];
                else {
                pfx[i]=0.0;
                piI[i]=1;
                fNI+=1.0;
                }
        }
        pfu1New[ix]=pfxt[0];
        pfu2New[ix]=pfxt[1];
        pfu3New[ix]=pfxt[2];
        pfu4New[ix]=pfxt[3];
        pfu5New[ix]=pfxt[4];
        pfu6New[ix]=pfxt[5];
        pfu7New[ix]=pfxt[6];
        pfu8New[ix]=pfxt[7];
        pfu9New[ix]=pfxt[8];
        pfu10New[ix]=pfxt[9];
        
        }

    
    
    
    free( (int *) piI );
    free( (float *) pfx );
    free( (float *) pfxt );
    
    
    end_time = clock();
    //mexPrintf("\nComputing Time= %.3f sec\n \n",difftime(end_time,start_time)/1000);


}
/****************************************/






/**************************************** End of file ****************************************/
