

function [classification_error,classification_error_percentage] = ...
            transductive_cheeger_10p_comparison(VecParameters,w,indexTrainingNumbers,solution)




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


rd=VecParameters(1);
rv=VecParameters(2);
rm=VecParameters(3);
ns=VecParameters(4);
nsi=VecParameters(5);
maxiter=VecParameters(6);
V2 = VecParameters(7);
p = VecParameters(8);
Maxdiffl = VecParameters(9);
Maxdiffinner = VecParameters(10);
Maxdiffu = VecParameters(11);
MaxdiffC = VecParameters(12);


tN = size(w,1);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pre-computed function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rdinv = 1/rd;
rvinv = 1/rv;

w=triu(w,1);
[r c v]=find(w);
n=length(r);
Dr=[1:n 1:n];
Dc(1:n)=r;
Dc(n+1:2*n)=c;
Dv(1:n)=2*v;
Dv(n+1:2*n)=-2*v;
D=sparse(Dr,Dc,Dv,n,tN);
Dt=D';
md=@(x,type) rv*x+rd*(Dt*(D*x));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initial function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

r=1; md2=@(x,type) r*x+1*r*(Dt*(D*x));

u1=zeros(tN,1); k=0+1; u1(indexTrainingNumbers{k})=1;
u2=zeros(tN,1); k=1+1; u2(indexTrainingNumbers{k})=1;
u3=zeros(tN,1); k=2+1; u3(indexTrainingNumbers{k})=1;
u4=zeros(tN,1); k=3+1; u4(indexTrainingNumbers{k})=1;
u5=zeros(tN,1); k=4+1; u5(indexTrainingNumbers{k})=1;
u6=zeros(tN,1); k=5+1; u6(indexTrainingNumbers{k})=1;
u7=zeros(tN,1); k=6+1; u7(indexTrainingNumbers{k})=1;
u8=zeros(tN,1); k=7+1; u8(indexTrainingNumbers{k})=1;
u9=zeros(tN,1); k=8+1; u9(indexTrainingNumbers{k})=1;
u10=zeros(tN,1); k=9+1; u10(indexTrainingNumbers{k})=1;
[u1 flag]=pcg(md2,u1,1e-6,50,[],[],u1); u1=u1-mean(u1); u1(u1>0)=1; u1(u1<=0)=0;
[u2 flag]=pcg(md2,u2,1e-6,50,[],[],u2); u2=u2-mean(u2); u2(u2>0)=1; u2(u2<=0)=0;
[u3 flag]=pcg(md2,u3,1e-6,50,[],[],u3); u3=u3-mean(u3); u3(u3>0)=1; u3(u3<=0)=0;
[u4 flag]=pcg(md2,u4,1e-6,50,[],[],u4); u4=u4-mean(u4); u4(u4>0)=1; u4(u4<=0)=0;
[u5 flag]=pcg(md2,u5,1e-6,50,[],[],u5); u5=u5-mean(u5); u5(u5>0)=1; u5(u5<=0)=0;
[u6 flag]=pcg(md2,u6,1e-6,50,[],[],u6); u6=u6-mean(u6); u6(u6>0)=1; u6(u6<=0)=0;
[u7 flag]=pcg(md2,u7,1e-6,50,[],[],u7); u7=u7-mean(u7); u7(u7>0)=1; u7(u7<=0)=0;
[u8 flag]=pcg(md2,u8,1e-6,50,[],[],u8); u8=u8-mean(u8); u8(u8>0)=1; u8(u8<=0)=0;
[u9 flag]=pcg(md2,u9,1e-6,50,[],[],u9); u9=u9-mean(u9); u9(u9>0)=1; u9(u9<=0)=0;
[u10 flag]=pcg(md2,u10,1e-6,50,[],[],u10); u10=u10-mean(u10); u10(u10>0)=1; u10(u10<=0)=0;
v1=u1; l1=sum(abs(D*u1))/sum(abs(u1-median(u1)));
v2=u2; l2=sum(abs(D*u2))/sum(abs(u2-median(u2)));
v3=u3; l3=sum(abs(D*u3))/sum(abs(u3-median(u3)));
v4=u4; l4=sum(abs(D*u4))/sum(abs(u4-median(u4)));
v5=u5; l5=sum(abs(D*u5))/sum(abs(u5-median(u5)));
v6=u6; l6=sum(abs(D*u6))/sum(abs(u6-median(u6)));
v7=u7; l7=sum(abs(D*u7))/sum(abs(u7-median(u7)));
v8=u8; l8=sum(abs(D*u8))/sum(abs(u8-median(u8)));
v9=u9; l9=sum(abs(D*u9))/sum(abs(u9-median(u9)));
v10=u10; l10=sum(abs(D*u10))/sum(abs(u10-median(u10)));


% init classification error
C1=zeros(1,tN);
C2=zeros(1,tN);
C3=zeros(1,tN);
C4=zeros(1,tN);
C5=zeros(1,tN);
C6=zeros(1,tN);
C7=zeros(1,tN);
C8=zeros(1,tN);
C9=zeros(1,tN);
C10=zeros(1,tN);
for i=1:tN
    U=[u1(i) u2(i) u3(i) u4(i) u5(i)...
        u6(i) u7(i) u8(i) u9(i) u10(i)];
    [junk J] = find(U==max(U));
    if J(1)==1
        C1(i)=1; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
    elseif J(1)==2
        C1(i)=0; C2(i)=1; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
    elseif J(1)==3
        C1(i)=0; C2(i)=0; C3(i)=1; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
    elseif J(1)==4
        C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=1; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
    elseif J(1)==5
        C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=1; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
    elseif J(1)==6
        C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=1; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
    elseif J(1)==7
        C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=1; C8(i)=0; C9(i)=0; C10(i)=0;
    elseif J(1)==8
        C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=1; C9(i)=0; C10(i)=0;
    elseif J(1)==9
        C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=1; C10(i)=0;
    elseif J(1)==10
        C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=1;
    end
end


    
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% transductive learning algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


C1old = C1; C2old = C2; C3old = C3; C4old = C4; C5old = C5; 
C6old = C6; C7old = C7; C8old = C8; C9old = C9; C10old = C10; 
diffl=1; k=-1; diffC=1; diffu=1;
while ( diffl>Maxdiffl && k<maxiter && diffC>0 && diffu>Maxdiffu )
    
    k=k+1;
    
    l1old = l1;
    l2old = l2;
    l3old = l3;
    l4old = l4;
    l5old = l5;
    l6old = l6;
    l7old = l7;
    l8old = l8;
    l9old = l9;
    l10old = l10;
    
    u1Outer = u1;
    u2Outer = u2;
    u3Outer = u3;
    u4Outer = u4;
    u5Outer = u5;
    u6Outer = u6;
    u7Outer = u7;
    u8Outer = u8;
    u9Outer = u9;
    u10Outer = u10;
    
    ad1 = zeros(size(D*u1)); av1 = zeros(size(u1)); am1 = 0;
    ad2 = zeros(size(D*u2)); av2 = zeros(size(u2)); am2 = 0;
    ad3 = zeros(size(D*u3)); av3 = zeros(size(u3)); am3 = 0;
    ad4 = zeros(size(D*u4)); av4 = zeros(size(u4)); am4 = 0;
    ad5 = zeros(size(D*u5)); av5 = zeros(size(u5)); am5 = 0;
    ad6 = zeros(size(D*u6)); av6 = zeros(size(u6)); am6 = 0;
    ad7 = zeros(size(D*u7)); av7 = zeros(size(u7)); am7 = 0;
    ad8 = zeros(size(D*u8)); av8 = zeros(size(u8)); am8 = 0;
    ad9 = zeros(size(D*u9)); av9 = zeros(size(u9)); am9 = 0;
    ad10 = zeros(size(D*u10)); av10 = zeros(size(u10)); am10 = 0;
    
    diffinner=1; j=0;
    while ( diffinner>1e-7 && j<ns )
        
        j=j+1;
        u1old=u1; v1old=v1;
        u2old=u2; v2old=v2;
        u3old=u3; v3old=v3;
        u4old=u4; v4old=v4;
        u5old=u5; v5old=v5;
        u6old=u6; v6old=v6;
        u7old=u7; v7old=v7;
        u8old=u8; v8old=v8;
        u9old=u9; v9old=v9;
        u10old=u10; v10old=v10;
        
        
        % new d
        d1 = shrink(D*u1-rdinv*ad1,rdinv);
        d2 = shrink(D*u2-rdinv*ad2,rdinv);
        d3 = shrink(D*u3-rdinv*ad3,rdinv);
        d4 = shrink(D*u4-rdinv*ad4,rdinv);
        d5 = shrink(D*u5-rdinv*ad5,rdinv);
        d6 = shrink(D*u6-rdinv*ad6,rdinv);
        d7 = shrink(D*u7-rdinv*ad7,rdinv);
        d8 = shrink(D*u8-rdinv*ad8,rdinv);
        d9 = shrink(D*u9-rdinv*ad9,rdinv);
        d10 = shrink(D*u10-rdinv*ad10,rdinv);
        
        
        % new u
        [u1 flag]=pcg(md,rv*v1+av1 +rd*Dt*d1+Dt*ad1,1e-6,nsi,[],[],u1);
        [u2 flag]=pcg(md,rv*v2+av2 +rd*Dt*d2+Dt*ad2,1e-6,nsi,[],[],u2);
        [u3 flag]=pcg(md,rv*v3+av3 +rd*Dt*d3+Dt*ad3,1e-6,nsi,[],[],u3);
        [u4 flag]=pcg(md,rv*v4+av4 +rd*Dt*d4+Dt*ad4,1e-6,nsi,[],[],u4);
        [u5 flag]=pcg(md,rv*v5+av5 +rd*Dt*d5+Dt*ad5,1e-6,nsi,[],[],u5);
        [u6 flag]=pcg(md,rv*v6+av6 +rd*Dt*d6+Dt*ad6,1e-6,nsi,[],[],u6);
        [u7 flag]=pcg(md,rv*v7+av7 +rd*Dt*d7+Dt*ad7,1e-6,nsi,[],[],u7);
        [u8 flag]=pcg(md,rv*v8+av8 +rd*Dt*d8+Dt*ad8,1e-6,nsi,[],[],u8);
        [u9 flag]=pcg(md,rv*v9+av9 +rd*Dt*d9+Dt*ad9,1e-6,nsi,[],[],u9);
        [u10 flag]=pcg(md,rv*v10+av10 +rd*Dt*d10+Dt*ad10,1e-6,nsi,[],[],u10);
        

        % new v
        v1 = unshrink(u1-rvinv*av1-rvinv*am1,rvinv*l1); v1(v1>1)=1; v1(v1<0)=0; v1=(v1-min(v1))/(max(v1)-min(v1));
        v2 = unshrink(u2-rvinv*av2-rvinv*am2,rvinv*l2); v2(v2>1)=1; v2(v2<0)=0; v2=(v2-min(v2))/(max(v2)-min(v2));
        v3 = unshrink(u3-rvinv*av3-rvinv*am3,rvinv*l3); v3(v3>1)=1; v3(v3<0)=0; v3=(v3-min(v3))/(max(v3)-min(v3));
        v4 = unshrink(u4-rvinv*av4-rvinv*am4,rvinv*l4); v4(v4>1)=1; v4(v4<0)=0; v4=(v4-min(v4))/(max(v4)-min(v4));
        v5 = unshrink(u5-rvinv*av5-rvinv*am5,rvinv*l5); v5(v5>1)=1; v5(v5<0)=0; v5=(v5-min(v5))/(max(v5)-min(v5));
        v6 = unshrink(u6-rvinv*av6-rvinv*am6,rvinv*l6); v6(v6>1)=1; v6(v6<0)=0; v6=(v6-min(v6))/(max(v6)-min(v6));
        v7 = unshrink(u7-rvinv*av7-rvinv*am7,rvinv*l7); v7(v7>1)=1; v7(v7<0)=0; v7=(v7-min(v7))/(max(v7)-min(v7));
        v8 = unshrink(u8-rvinv*av8-rvinv*am8,rvinv*l8); v8(v8>1)=1; v8(v8<0)=0; v8=(v8-min(v8))/(max(v8)-min(v8));
        v9 = unshrink(u9-rvinv*av9-rvinv*am9,rvinv*l9); v9(v9>1)=1; v9(v9<0)=0; v9=(v9-min(v9))/(max(v9)-min(v9));
        v10 = unshrink(u10-rvinv*av10-rvinv*am10,rvinv*l10); v10(v10>1)=1; v10(v10<0)=0; v10=(v10-min(v10))/(max(v10)-min(v10));
        [v1 v2 v3 v4 v5 v6 v7 v8 v9 v10] = simplex_projection_10p_mex(...
            single(v1),single(v2),single(v3),single(v4),single(v5),...
            single(v6),single(v7),single(v8),single(v9),single(v10),...
            single(tN));
        v1=double(v1); v2=double(v2); v3=double(v3); v4=double(v4); v5=double(v5);
        v6=double(v6); v7=double(v7); v8=double(v8); v9=double(v9); v10=double(v10);
        
        
        % training data
        i=0+1; 
        u1(indexTrainingNumbers{i})=1; u2(indexTrainingNumbers{i})=0; u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; u5(indexTrainingNumbers{i})=0; 
        u6(indexTrainingNumbers{i})=0; u7(indexTrainingNumbers{i})=0; u8(indexTrainingNumbers{i})=0; u9(indexTrainingNumbers{i})=0; u10(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=1; v2(indexTrainingNumbers{i})=0; v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0; v5(indexTrainingNumbers{i})=0; 
        v6(indexTrainingNumbers{i})=0; v7(indexTrainingNumbers{i})=0; v8(indexTrainingNumbers{i})=0; v9(indexTrainingNumbers{i})=0; v10(indexTrainingNumbers{i})=0; 
        i=1+1; 
        u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=1; u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; u5(indexTrainingNumbers{i})=0; 
        u6(indexTrainingNumbers{i})=0; u7(indexTrainingNumbers{i})=0; u8(indexTrainingNumbers{i})=0; u9(indexTrainingNumbers{i})=0; u10(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=1; v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0; v5(indexTrainingNumbers{i})=0; 
        v6(indexTrainingNumbers{i})=0; v7(indexTrainingNumbers{i})=0; v8(indexTrainingNumbers{i})=0; v9(indexTrainingNumbers{i})=0; v10(indexTrainingNumbers{i})=0; 
        i=2+1; 
        u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; u3(indexTrainingNumbers{i})=1; u4(indexTrainingNumbers{i})=0; u5(indexTrainingNumbers{i})=0; 
        u6(indexTrainingNumbers{i})=0; u7(indexTrainingNumbers{i})=0; u8(indexTrainingNumbers{i})=0; u9(indexTrainingNumbers{i})=0; u10(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; v3(indexTrainingNumbers{i})=1; v4(indexTrainingNumbers{i})=0; v5(indexTrainingNumbers{i})=0; 
        v6(indexTrainingNumbers{i})=0; v7(indexTrainingNumbers{i})=0; v8(indexTrainingNumbers{i})=0; v9(indexTrainingNumbers{i})=0; v10(indexTrainingNumbers{i})=0; 
        i=3+1; 
        u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=1; u5(indexTrainingNumbers{i})=0; 
        u6(indexTrainingNumbers{i})=0; u7(indexTrainingNumbers{i})=0; u8(indexTrainingNumbers{i})=0; u9(indexTrainingNumbers{i})=0; u10(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=1; v5(indexTrainingNumbers{i})=0; 
        v6(indexTrainingNumbers{i})=0; v7(indexTrainingNumbers{i})=0; v8(indexTrainingNumbers{i})=0; v9(indexTrainingNumbers{i})=0; v10(indexTrainingNumbers{i})=0; 
        i=4+1; 
        u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; u5(indexTrainingNumbers{i})=1; 
        u6(indexTrainingNumbers{i})=0; u7(indexTrainingNumbers{i})=0; u8(indexTrainingNumbers{i})=0; u9(indexTrainingNumbers{i})=0; u10(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0; v5(indexTrainingNumbers{i})=1; 
        v6(indexTrainingNumbers{i})=0; v7(indexTrainingNumbers{i})=0; v8(indexTrainingNumbers{i})=0; v9(indexTrainingNumbers{i})=0; v10(indexTrainingNumbers{i})=0; 
        i=5+1; 
        u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; u5(indexTrainingNumbers{i})=0; 
        u6(indexTrainingNumbers{i})=1; u7(indexTrainingNumbers{i})=0; u8(indexTrainingNumbers{i})=0; u9(indexTrainingNumbers{i})=0; u10(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0; v5(indexTrainingNumbers{i})=0; 
        v6(indexTrainingNumbers{i})=1; v7(indexTrainingNumbers{i})=0; v8(indexTrainingNumbers{i})=0; v9(indexTrainingNumbers{i})=0; v10(indexTrainingNumbers{i})=0; 
        i=6+1; 
        u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; u5(indexTrainingNumbers{i})=0; 
        u6(indexTrainingNumbers{i})=0; u7(indexTrainingNumbers{i})=1; u8(indexTrainingNumbers{i})=0; u9(indexTrainingNumbers{i})=0; u10(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0; v5(indexTrainingNumbers{i})=0; 
        v6(indexTrainingNumbers{i})=0; v7(indexTrainingNumbers{i})=1; v8(indexTrainingNumbers{i})=0; v9(indexTrainingNumbers{i})=0; v10(indexTrainingNumbers{i})=0; 
        i=7+1; 
        u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; u5(indexTrainingNumbers{i})=0; 
        u6(indexTrainingNumbers{i})=0; u7(indexTrainingNumbers{i})=0; u8(indexTrainingNumbers{i})=1; u9(indexTrainingNumbers{i})=0; u10(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0; v5(indexTrainingNumbers{i})=0; 
        v6(indexTrainingNumbers{i})=0; v7(indexTrainingNumbers{i})=0; v8(indexTrainingNumbers{i})=1; v9(indexTrainingNumbers{i})=0; v10(indexTrainingNumbers{i})=0; 
        i=8+1; 
        u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; u5(indexTrainingNumbers{i})=0; 
        u6(indexTrainingNumbers{i})=0; u7(indexTrainingNumbers{i})=0; u8(indexTrainingNumbers{i})=0; u9(indexTrainingNumbers{i})=1; u10(indexTrainingNumbers{i})=0; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0; v5(indexTrainingNumbers{i})=0; 
        v6(indexTrainingNumbers{i})=0; v7(indexTrainingNumbers{i})=0; v8(indexTrainingNumbers{i})=0; v9(indexTrainingNumbers{i})=1; v10(indexTrainingNumbers{i})=0; 
        i=9+1; 
        u1(indexTrainingNumbers{i})=0; u2(indexTrainingNumbers{i})=0; u3(indexTrainingNumbers{i})=0; u4(indexTrainingNumbers{i})=0; u5(indexTrainingNumbers{i})=0; 
        u6(indexTrainingNumbers{i})=0; u7(indexTrainingNumbers{i})=0; u8(indexTrainingNumbers{i})=0; u9(indexTrainingNumbers{i})=0; u10(indexTrainingNumbers{i})=1; 
        v1(indexTrainingNumbers{i})=0; v2(indexTrainingNumbers{i})=0; v3(indexTrainingNumbers{i})=0; v4(indexTrainingNumbers{i})=0; v5(indexTrainingNumbers{i})=0; 
        v6(indexTrainingNumbers{i})=0; v7(indexTrainingNumbers{i})=0; v8(indexTrainingNumbers{i})=0; v9(indexTrainingNumbers{i})=0; v10(indexTrainingNumbers{i})=1; 
        
        
        % Lagrange multipliers
        ad1 = ad1+rd*(d1-D*u1); av1 = av1+rv*(v1-u1); am1 = max(0,am1+rm*(sum(v1)-V2));
        ad2 = ad2+rd*(d2-D*u2); av2 = av2+rv*(v2-u2); am2 = max(0,am2+rm*(sum(v2)-V2));
        ad3 = ad3+rd*(d3-D*u3); av3 = av3+rv*(v3-u3); am3 = max(0,am3+rm*(sum(v3)-V2));
        ad4 = ad4+rd*(d4-D*u4); av4 = av4+rv*(v4-u4); am4 = max(0,am4+rm*(sum(v4)-V2));
        ad5 = ad5+rd*(d5-D*u5); av5 = av5+rv*(v5-u5); am5 = max(0,am5+rm*(sum(v5)-V2));
        ad6 = ad6+rd*(d6-D*u6); av6 = av6+rv*(v6-u6); am6 = max(0,am6+rm*(sum(v6)-V2));
        ad7 = ad7+rd*(d7-D*u7); av7 = av7+rv*(v7-u7); am7 = max(0,am7+rm*(sum(v7)-V2));
        ad8 = ad8+rd*(d8-D*u8); av8 = av8+rv*(v8-u8); am8 = max(0,am8+rm*(sum(v8)-V2));
        ad9 = ad9+rd*(d9-D*u9); av9 = av9+rv*(v9-u9); am9 = max(0,am9+rm*(sum(v9)-V2));
        ad10 = ad10+rd*(d10-D*u10); av10 = av10+rv*(v10-u10); am10 = max(0,am10+rm*(sum(v10)-V2));
        
        
        % stopping condition
        diffu1 = sum((u1old-u1).^2)/tN; diffv1 = sum((v1old-v1).^2)/tN;
        diffu2 = sum((u2old-u2).^2)/tN; diffv2 = sum((v2old-v2).^2)/tN;
        diffu3 = sum((u3old-u3).^2)/tN; diffv3 = sum((v3old-v3).^2)/tN;
        diffu4 = sum((u4old-u4).^2)/tN; diffv4 = sum((v4old-v4).^2)/tN;
        diffu5 = sum((u5old-u5).^2)/tN; diffv5 = sum((v5old-v5).^2)/tN;
        diffu6 = sum((u6old-u6).^2)/tN; diffv6 = sum((v6old-v6).^2)/tN;
        diffu7 = sum((u7old-u7).^2)/tN; diffv7 = sum((v7old-v7).^2)/tN;
        diffu8 = sum((u8old-u8).^2)/tN; diffv8 = sum((v8old-v8).^2)/tN;
        diffu9 = sum((u9old-u9).^2)/tN; diffv9 = sum((v9old-v9).^2)/tN;
        diffu10 = sum((u10old-u10).^2)/tN; diffv10 = sum((v10old-v10).^2)/tN;
        diffinner = (diffu1+diffv1+diffu2+diffv2+diffu3+diffv3+diffu4+diffv4+diffu5+diffv5+...
            diffu6+diffv6+diffu7+diffv7+diffu8+diffv8+diffu9+diffv9+diffu10+diffv10)/20;
        
        
    end % END inner iterations
    
    
    % new lagrange multiplier
    l1 = l1- p*(l1-sum(abs(D*u1))/sum(abs(u1)));
    l2 = l2- p*(l2-sum(abs(D*u2))/sum(abs(u2)));
    l3 = l3- p*(l3-sum(abs(D*u3))/sum(abs(u3)));
    l4 = l4- p*(l4-sum(abs(D*u4))/sum(abs(u4)));
    l5 = l5- p*(l5-sum(abs(D*u5))/sum(abs(u5)));
    l6 = l6- p*(l6-sum(abs(D*u6))/sum(abs(u6)));
    l7 = l7- p*(l7-sum(abs(D*u7))/sum(abs(u7)));
    l8 = l8- p*(l8-sum(abs(D*u8))/sum(abs(u8)));
    l9 = l9- p*(l9-sum(abs(D*u9))/sum(abs(u9)));
    l10 = l10- p*(l10-sum(abs(D*u10))/sum(abs(u10)));
    
    
    % find classes
    C1=zeros(1,tN);
    C2=zeros(1,tN);
    C3=zeros(1,tN);
    C4=zeros(1,tN);
    C5=zeros(1,tN);
    C6=zeros(1,tN);
    C7=zeros(1,tN);
    C8=zeros(1,tN);
    C9=zeros(1,tN);
    C10=zeros(1,tN);
    for i=1:tN
        U=[u1(i) u2(i) u3(i) u4(i) u5(i)...
           u6(i) u7(i) u8(i) u9(i) u10(i)];
        [junk J] = find(U==max(U));
        if J(1)==1
            C1(i)=1; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
        elseif J(1)==2
            C1(i)=0; C2(i)=1; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
        elseif J(1)==3
            C1(i)=0; C2(i)=0; C3(i)=1; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
        elseif J(1)==4
            C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=1; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
        elseif J(1)==5
            C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=1; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
        elseif J(1)==6
            C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=1; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=0;
        elseif J(1)==7
            C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=1; C8(i)=0; C9(i)=0; C10(i)=0;
        elseif J(1)==8
            C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=1; C9(i)=0; C10(i)=0;
        elseif J(1)==9
            C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=1; C10(i)=0;
        elseif J(1)==10
            C1(i)=0; C2(i)=0; C3(i)=0; C4(i)=0; C5(i)=0; C6(i)=0; C7(i)=0; C8(i)=0; C9(i)=0; C10(i)=1;
        end
    end
    
    
    % stopping condition
    diffl1 = abs(l1old-l1); 
    diffl2 = abs(l2old-l2); 
    diffl3 = abs(l3old-l3); 
    diffl4 = abs(l4old-l4); 
    diffl5 = abs(l5old-l5); 
    diffl6 = abs(l6old-l6); 
    diffl7 = abs(l7old-l7); 
    diffl8 = abs(l8old-l8); 
    diffl9 = abs(l9old-l9); 
    diffl10 = abs(l10old-l10); 
    diffl = (diffl1+diffl2+diffl3+diffl4+diffl5+...
        diffl6+diffl7+diffl8+diffl9+diffl10)/10;
    
    
    
    % stopping condition
    diffu1 = sum((u1Outer-u1).^2)/tN; 
    diffu2 = sum((u2Outer-u2).^2)/tN;
    diffu3 = sum((u3Outer-u3).^2)/tN;
    diffu4 = sum((u4Outer-u4).^2)/tN;
    diffu5 = sum((u5Outer-u5).^2)/tN;
    diffu6 = sum((u6Outer-u6).^2)/tN;
    diffu7 = sum((u7Outer-u7).^2)/tN;
    diffu8 = sum((u8Outer-u8).^2)/tN;
    diffu9 = sum((u9Outer-u9).^2)/tN;
    diffu10 = sum((u10Outer-u10).^2)/tN;
    diffu = (diffu1+diffu2+diffu3+diffu4+diffu5+...
        diffu6+diffu7+diffu8+diffu9+diffu10)/10;
    
    
    % stopping condition
    if (rem(k,3)==0)
        diffC1 = sum(abs(C1old-C1));
        diffC2 = sum(abs(C2old-C2));
        diffC3 = sum(abs(C3old-C3));
        diffC4 = sum(abs(C4old-C4));
        diffC5 = sum(abs(C5old-C5));
        diffC6 = sum(abs(C6old-C6));
        diffC7 = sum(abs(C7old-C7));
        diffC8 = sum(abs(C8old-C8));
        diffC9 = sum(abs(C9old-C9));
        diffC10 = sum(abs(C10old-C10));
        diffC = (diffC1+diffC2+diffC3+diffC4+diffC5+...
            diffC6+diffC7+diffC8+diffC9+diffC10)/10;
        C1old = C1;
        C2old = C2;
        C3old = C3;
        C4old = C4;
        C5old = C5;
        C6old = C6;
        C7old = C7;
        C8old = C8;
        C9old = C9;
        C10old = C10;
    end
    
    
    
    
    
    
    
    % classification error
    v = zeros(tN,10);
    v(:,1) = C1;
    v(:,2) = C2;
    v(:,3) = C3;
    v(:,4) = C4;
    v(:,5) = C5;
    v(:,6) = C6;
    v(:,7) = C7;
    v(:,8) = C8;
    v(:,9) = C9;
    v(:,10) = C10;
    mincent = zeros(1,tN);
    Np=10;
    for pp=1:Np
        mincent(v(:,pp)==1)=pp;
    end
    % confusion matrix
    x = confma(mincent,solution);
    for ki=1:Np
        [ju juu]=max(x(ki,:));
        tx=x(ki,:);
        tx(juu)=0;
        ern(ki)=sum(tx);
    end

    
end % END while ( diffl>1e-14 && k<maxiter )



kNbIterCheeger = k
classification_error = sum(ern);
classification_error_percentage = classification_error*100/tN;



end








function d = shrink(e,rinv)


s = abs(e);
ss = s-rinv;
ss = ss.*(ss>0);
s = s+(s<rinv);
ss = ss./s;
d = ss.*e;


end


function v=unshrink(e,r)


s = abs(e);
s = s+(s<1e-10);
ss = r./s;
v = e.*(1+ss);


end







