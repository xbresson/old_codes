

function [classification_error,classification_error_percentage] = ...
    transductive_spectral_comparison(w,indexTrainingNumbers,solution)


tN = size(w,1);

wv=dn(w+w','gph');

opts.disp=0;
[Vv Ee]=eigs(wv,100,'LM',opts);


L=zeros(10,tN); for k=1:tN; L(solution(k)+1,k)=1; end
ne=[5 10 15 25 35 50 75 100];
% L is an indicator function, L(x)=1 for x in C_i, o otherwise
for s=1:size(ne,2)
    Neig=ne(s);
    pid = [indexTrainingNumbers{1} indexTrainingNumbers{2}...
        indexTrainingNumbers{3} indexTrainingNumbers{4}...
        indexTrainingNumbers{5} indexTrainingNumbers{6}...
        indexTrainingNumbers{7} indexTrainingNumbers{8}...
        indexTrainingNumbers{9} indexTrainingNumbers{10}];
    A=Vv(pid,2:Neig)\L(:,pid)';
    M=Vv(:,2:Neig)*A;
    [ju juu]=max(M,[],2);
    er(s)=1-length(find(juu==solution'+1))/tN;
end
%er

classification_error_percentage = 100* min(er);
classification_error = classification_error_percentage*tN/100;


end










