

% addpath('01- Transductive Cheeger (MNIST)');
% addpath('02- Transductive Potts (MNIST)');
% addpath('03- Transductive spectral (MNIST)');


function transductive_mnist_comparison

clear








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check results: post-processing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

check_results = 2;
if check_results == 1
    
    file = 'results_transductive_mnist.mat';
    load(file,'resultsTransCheeger','resultsTransCheegerPerc',...
        'resultsTransPotts','resultsTransPottsPerc',...
        'resultsTransSpectral','resultsTransSpectralPerc');
    
    
    
    meanresultsTransCheegerPerc = mean(resultsTransCheegerPerc')
    meanresultsTransPottsPerc = mean(resultsTransPottsPerc')
    meanresultsTransSpectralPerc = mean(resultsTransSpectralPerc')
    
    return
    
end











%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test transductive learning algorithms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

TabNbLabels = [1 5 10 25 50 100 250 10000]; 
sizeTabNbLabels = size(TabNbLabels,2);
nbTestsPerLabel = 10;




resultsTransCheeger = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransCheegerPerc = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransPotts = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransPottsPerc = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransSpectral = zeros(sizeTabNbLabels,nbTestsPerLabel);
resultsTransSpectralPerc = zeros(sizeTabNbLabels,nbTestsPerLabel);



for kNbLabels=1:sizeTabNbLabels
    
    
    for kTest=1:nbTestsPerLabel
        
        
        kNbLabels
        kTest
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % extract a small set of labels for classification
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        nbTrainingPts = TabNbLabels(kNbLabels);
        
        file = 'file_mnist.mat';
        load(file,'T','trainingT','labels','traininglabels');
        
        % Reorganize 60,000 data points (contiguous re-organization)
        for k=1:10
            id{k}=find(labels==k-1);
        end
        % select the sets for classification
        uid = [id{1} id{2} id{3} id{4} id{5} id{6} id{7} id{8} id{9} id{10}];
        T = T(uid,:);
        labels = labels(uid);
        
        % Reorganize 10,000 training points (contiguous re-organization)
        for k=1:10
            id{k}=find(traininglabels==k-1);
        end
        % select the sets for classification
        uid = [id{1} id{2} id{3} id{4} id{5} id{6} id{7} id{8} id{9} id{10}];
        trainingT = trainingT(uid,:);
        traininglabels = traininglabels(uid);
        
        % Select a set of training points
        % extract a small set of labels for classification among the 10,000 training data
        for k=1:10
            id{k}=find(traininglabels==k-1);
        end
        
        %%% Random selection
        % Kp = selected random sets for classification
        Kp = [0+1 1+1 2+1 3+1 4+1 5+1 6+1 7+1 8+1 9+1];
        nbTrainingPtsTemp = nbTrainingPts;
        for k=1:size(Kp,2)
            idc=id{Kp(k)};
            sizeIdc=size(idc,2);
            junk = randperm(sizeIdc);
            nbTrainingPts = nbTrainingPtsTemp;
            if nbTrainingPts>sizeIdc
                nbTrainingPts=sizeIdc;
            end
            id2{Kp(k)} = idc(junk(1:nbTrainingPts));
        end
        id = id2;
        
        % select the sets for classification
        uid = [id{1} id{2} id{3} id{4} id{5} id{6} id{7} id{8} id{9} id{10}];
        
        trainingT = trainingT(uid,:);
        traininglabels = traininglabels(uid);
        nbTrainingPts = size(uid,2) % total number of labels used for classification
        nbTrainingPtsPerClass = size(uid,2)/10
        
        % Data + Training points (concatenate data)
        allT = cat(1, double(T), double(trainingT));
        allLabels = [labels traininglabels];
        
        % index of training data for 10 phases
        for k=1:10
            id{k}=find(traininglabels==k-1);
            indexTrainingNumbers{k} = size(T,1) + id{k}; % size(T,1)=60000 for 10 phases
        end
        
        
        solution = allLabels;
        
        display = 2;
        if display == 1
            figure(1); clf; s2=3; A=T'; N=size(A); % MOONS
            title('graph'); v=solution;
            scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');
            pause
        end




        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % construct the graph of data
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        opts.kNN=10;
        opts.kNNdelta=10;
        opts.alpha=1;
        
        tic
        fprintf('building weights... \n');
        [w NNIdxs]=fgf(allT,opts);
        toc
        
        tN = size(w,2);
        
        
        
        
        
        
        
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Cheeger
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        disp(' ');
        disp('---------------------------');
        disp('Cheeger');
        disp('---------------------------');
        
        
        rd=1e1;
        rv=1e2;
        K=10; rm=6*K/tN;
        ns=150;
        nsi=10;
        maxiter=50;
        V2 = tN/K;
        p = 0.4;
        Maxdiffl = 1e-3;
        Maxdiffinner = 1e-7;
        Maxdiffu = 1e-6;
        MaxdiffC = 0;
        
        
        VecParameters = [rd rv rm ns nsi maxiter V2 p Maxdiffl Maxdiffinner Maxdiffu MaxdiffC];
        
        
        tic
        [classification_error,classification_error_percentage] = ...
            transductive_cheeger_10p_comparison(VecParameters,w,indexTrainingNumbers,solution)
        toc
        
        classification_error
        classification_error_percentage
        
        resultsTransCheeger(kNbLabels,kTest) = classification_error;
        resultsTransCheegerPerc(kNbLabels,kTest) = classification_error_percentage;
        
        
        file = 'results_transductive_mnist.mat';
        save(file,'resultsTransCheeger','resultsTransCheegerPerc',...
            'resultsTransPotts','resultsTransPottsPerc','resultsTransSpectral','resultsTransSpectralPerc');
        
    
        
        
        
        
        
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Potts
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        disp(' ');
        disp('---------------------------');
        disp('Potts');
        disp('---------------------------');
        
        
        
        rd=1e1;
        rv=1e2;
        nsi=10;
        maxiter=500;
        p = 0.4;
        Maxdiffu = 1e-6;
        MaxdiffC = 0;
        
        
        VecParameters = [rd rv nsi maxiter p Maxdiffu MaxdiffC];
        
        
        tic
        [classification_error,classification_error_percentage] = ...
            transductive_Potts_10p_comparison(VecParameters,w,indexTrainingNumbers,solution)
        toc
        
        
        resultsTransPotts(kNbLabels,kTest) = classification_error;
        resultsTransPottsPerc(kNbLabels,kTest) = classification_error_percentage;
        
        
        file = 'results_transductive_mnist.mat';
        save(file,'resultsTransCheeger','resultsTransCheegerPerc',...
            'resultsTransPotts','resultsTransPottsPerc','resultsTransSpectral','resultsTransSpectralPerc');
        
        
        
        
        
        
        
        
        
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Spectral
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        disp(' ');
        disp('---------------------------');
        disp('Spectral');
        disp('---------------------------');
        
        
        
        
        tic
        [classification_error,classification_error_percentage] = ...
            transductive_spectral_10p_comparison(w,indexTrainingNumbers,solution)
        toc

        resultsTransSpectral(kNbLabels,kTest) = classification_error;
        resultsTransSpectralPerc(kNbLabels,kTest) = classification_error_percentage;
        
        
        file = 'results_transductive_mnist.mat';
        save(file,'resultsTransCheeger','resultsTransCheegerPerc',...
            'resultsTransPotts','resultsTransPottsPerc','resultsTransSpectral','resultsTransSpectralPerc');
  
        
        
        
    end
   
    
end


TabNbLabels
meanresultsTransCheegerPerc = mean(resultsTransCheegerPerc')
meanresultsTransPottsPerc = mean(resultsTransPottsPerc')
meanresultsTransSpectralPerc = mean(resultsTransSpectralPerc')


end





