To run the example code just compile the mex function FMReDistSDF_mex.c used in the initialization of the contour and then run example_public.
>mex FMReDistSDF_mex.c
>example_public
