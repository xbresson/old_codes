
/***************************************************************************/                                           
/* Description: Code to redistance a level set function as an SDF from its zero level set
  Based on "The fast construction of extension Velocities in Level St methods" by Adalsteinsson and Sethian*/
/***************************************************************************/

#include <mex.h>
#include <math.h>
#include <time.h>

#define TRUE 1

#define YES 0
#define NO 1

#define MAX(a,b) ( a > b ? a : b )
#define MIN(a,b) ( a < b ? a : b )

#define MAX5(a,b,c,d,e) MAX( MAX(MAX(a,b), MAX(c,d)), e )
#define MIN5(a,b,c,d,e) MIN( MIN(MIN(a,b), MIN(c,d)), e )

#define SIGN(x) ( x > 0.0 ? 1.0 : -1.0 )

#define INF 1024.0
#define EPS 0.001


/****************************************/
/**  Declaration of structures         **/
/****************************************/

typedef struct{
  float *pfPhiValue;
  int   *pix;
  int   *piy;
  int   *piFlagNarrowBand;
  int   iLength;
} sNarrowBand;


/****************************************/



/****************************************/
/**  Declaration of static procedures  **/
/****************************************/

/****************************************/
static int iFM2D_SDF
(
 float  *pfSDF,
 float  *pfNewSDF,
 int    iDim[2],
 float  fMaxDistanceComputations
 );
/****************************************/

/****************************************/
static void vAddElement2NarrowBand
(
 sNarrowBand  *psNarBand,
 float        fPhiValue,
 int          ix,
 int          iy
);
/****************************************/

/****************************************/
static void vRemoveFirstElementOfNarrowBand
(
 sNarrowBand  *psNarBand
);
/****************************************/

/****************************************/
static void vRemovePixelFromNarrowBand
(
 sNarrowBand  *psNarBand,
 int          ix,
 int          iy
);
/****************************************/


/****************************************/





/****************************************/
/**  Definition of static procedures   **/
/****************************************/


/****************************************/
static void vAddElement2NarrowBand
(
 sNarrowBand  *psNarBand,
 float        fPhiValue,
 int          ix,
 int          iy
)

{
  int index;
  
  index = psNarBand->iLength;

  if( index> 0 )
    {
      while ( fabs(fPhiValue)< fabs(psNarBand->pfPhiValue[index-1])  &&  index> 0 )
	{
	  psNarBand->pfPhiValue[index] = psNarBand->pfPhiValue[index-1];
	  psNarBand->pix[index] = psNarBand->pix[index-1];
	  psNarBand->piy[index] = psNarBand->piy[index-1];
	  index--;
	}
    }

  psNarBand->pfPhiValue[index] = fPhiValue;
  psNarBand->pix[index] = ix;
  psNarBand->piy[index] = iy;
  psNarBand->iLength++;

}
/****************************************/


/****************************************/
static void vRemoveFirstElementOfNarrowBand
(
 sNarrowBand  *psNarBand
)

{
  int i;

  for (i=0; i< psNarBand->iLength-1; i++)
    {
      psNarBand->pfPhiValue[i] = psNarBand->pfPhiValue[i+1];
      psNarBand->pix[i] = psNarBand->pix[i+1];
      psNarBand->piy[i] = psNarBand->piy[i+1];
    }

  psNarBand->iLength--;
  
}
/****************************************/


/****************************************/
static void vRemovePixelFromNarrowBand
(
 sNarrowBand  *psNarBand,
 int          ix,
 int          iy
)

{

  int  index, i;
  
  for(i=0; i< psNarBand->iLength; i++)
    if ( (psNarBand->pix[i] == ix) && (psNarBand->piy[i] == iy) )
      {
	index = i;
	i = psNarBand->iLength;
      }

  for(i=index; i< psNarBand->iLength-1; i++)
    {
      psNarBand->pfPhiValue[i] = psNarBand->pfPhiValue[i+1];
      psNarBand->pix[i] = psNarBand->pix[i+1];
      psNarBand->piy[i] = psNarBand->piy[i+1];
    }

  psNarBand->iLength--;

}
/****************************************/


/****************************************/
static int iFM2D_SDF
(
 float  *pfDistSDF,
 float  *pfNewSDF,
 int    iDim[2],
 float  fMaxDistanceComputations
 )

{

  float   fPhi00, fPhi0p, fPhi0m, fPhip0, fPhim0, fd, fa, fb, fPhi1, fPhi2;
  float   fd1, fd2, fd3, fd4;
  int     iNy, iNx, iy, ix, iy2, ix2, iCpt;
  int     *piBurntPixels, iNbInter;
  sNarrowBand   sNarBand;


  /* Get the size of the image */
  iNy = iDim[0]; 
  iNx = iDim[1]; 
/*   mexPrintf("iNy = %i, iNx = %i\n",iNy,iNx); */

/*   mexPrintf("MaxDistanceComputations = %.2f\n",fMaxDistanceComputations); */


  /*****************************************************************/
  /* Memory allocations */

  sNarBand.pfPhiValue = (float *) calloc( iNy* iNx,sizeof(float) );
  if (!sNarBand.pfPhiValue)
    {
      mexPrintf("Memory allocation failure for sNarBand.pfPhiValue\n");
      return(0);
    }

  sNarBand.pix = (int *) calloc( iNy* iNx,sizeof(int) );
  if (!sNarBand.pix)
    {
      mexPrintf("Memory allocation failure for sNarBand.pix\n");
      return(0);
    }

  sNarBand.piy = (int *) calloc( iNy* iNx,sizeof(int) );
  if (!sNarBand.piy)
    {
      mexPrintf("Memory allocation failure for sNarBand.piy\n");
      return(0);
    }

  sNarBand.piFlagNarrowBand = (int *) calloc( iNy* iNx,sizeof(int) );
  if (!sNarBand.piFlagNarrowBand)
    {
      mexPrintf("Memory allocation failure for sNarBand.piFlagNarrowBand\n");
      return(0);
    }

  sNarBand.iLength = 0;

  piBurntPixels = (int *) calloc( iNy* iNx,sizeof(int) );
  if (!piBurntPixels)
    {
      mexPrintf("Memory allocation failure for piBurntPixels\n");
      return(0);
    }

  /*****************************************************************/



  for(ix=0; ix< iNx; ix++)
    for(iy=0; iy< iNy; iy++) 
      {   
	piBurntPixels[ix*iNy+ iy] = 0;
	sNarBand.piFlagNarrowBand[ix*iNy+ iy] = 0;
      }


  for(ix=0; ix< iNx; ix++)
    for(iy=0; iy< iNy; iy++) 
      if ( pfDistSDF[ix*iNy + iy] >= 0.0 )
	pfNewSDF[ix*iNy + iy] = INF;
      else
	pfNewSDF[ix*iNy + iy] = -INF;
  

  for(ix=1; ix< iNx-1; ix++)
    for(iy=1; iy< iNy-1; iy++) 
      {   

	fPhi00 = pfDistSDF[ix*iNy + iy];
	fPhip0 = pfDistSDF[(ix+1)*iNy + iy];
	fPhim0 = pfDistSDF[(ix-1)*iNy + iy];
	fPhi0p = pfDistSDF[ix*iNy + iy+1];
	fPhi0m = pfDistSDF[ix*iNy + iy-1];

	if ( fabs(fPhi00) < EPS )  pfNewSDF[ix*iNy + iy] = 0.0;

	else if ( MAX5(fPhi00,fPhip0,fPhim0,fPhi0p,fPhi0m)>= 0.0  &&  MIN5(fPhi00,fPhip0,fPhim0,fPhi0p,fPhi0m)<= 0.0 )
	  {

	    iNbInter = 0;

	    if ( fabs(fPhi00-fPhip0) > EPS )  fd = fPhi00/ (fPhi00-fPhip0);
	    else  fd = -INF;
	    if ( fd>= 0.0 && fd<= 1.0 )  { fd1 = fabs(fd); iNbInter++; }
	    else  fd1 = -INF;

	    if ( fabs(fPhi00-fPhi0p) > EPS )  fd = fPhi00/ (fPhi00-fPhi0p);
	    else  fd = -INF;
	    if ( fd>= 0.0 && fd<= 1.0 )  { fd2 = fabs(fd); iNbInter++; }
	    else  fd2 = -INF;
	    
	    if ( fabs(fPhim0-fPhi00) > EPS )  fd = fPhi00/ (fPhim0-fPhi00);
	    else  fd = INF;
	    if ( fd>= -1.0 && fd<= 0.0 )  { fd3 = fabs(fd); iNbInter++; }
	    else  fd3 = -INF;
	    
	    if ( fabs(fPhi0m-fPhi00) > EPS )  fd = fPhi00/ (fPhi0m-fPhi00);
	    else  fd = INF;
	    if ( fd>= -1.0 && fd<= 0.0 )  { fd4 = fabs(fd); iNbInter++; }
	    else  fd4 = -INF;
	  

	    if ( iNbInter == 1 )
	      {
		if ( fd1>= 0.0 )       pfNewSDF[ix*iNy + iy] = SIGN(fPhi00)* fd1;
		else if ( fd2>= 0.0 )  pfNewSDF[ix*iNy + iy] = SIGN(fPhi00)* fd2;
		else if ( fd3>= 0.0 )  pfNewSDF[ix*iNy + iy] = SIGN(fPhi00)* fd3;
		else if ( fd4>= 0.0 )  pfNewSDF[ix*iNy + iy] = SIGN(fPhi00)* fd4;
	      }


	    else if ( iNbInter == 2 )
	      {
		if ( fd1>= 0.0  &&  fd3>= 0.0 )
		  pfNewSDF[ix*iNy + iy] = MIN(fd1,fd3);
		else if ( fd2>= 0.0  &&  fd4>= 0.0 )
		  pfNewSDF[ix*iNy + iy] = MIN(fd2,fd4);
		else 
		  {
		    iCpt = 0;
		    if ( fd1>= 0.0 ) { fa = fd1; iCpt++; }
		    if ( fd2>= 0.0 )
		      {
			if (iCpt==0)  fa = fd2;
			else  fb = fd2;
			iCpt++;
		      }
		    if ( fd3>= 0.0 )
		      {
			if (iCpt==0)  fa = fd3;
			else  fb = fd3;
		      }
		    if ( fd4>= 0.0 )  fb = fd4;
		     
		    pfNewSDF[ix*iNy + iy] = SIGN(fPhi00)* fa* fb/ pow(pow(fa,2.)+ pow(fb,2.),0.5);
		  }
	      }


	    else if ( iNbInter == 3 )
	      {
		if ( fd1>= 0.0  &&  fd3>= 0.0 )
		  {
		    fa = MIN(fd1,fd3);
		    if ( fd2>= 0.0 )  fb = fd2;
		    else  fb = fd4;
		  }
		else 
		  {
		    fa = MIN(fd2,fd4);
		    if ( fd1>= 0.0 )  fb = fd1;
		    else  fb = fd3;
		  }
		pfNewSDF[ix*iNy + iy] = SIGN(fPhi00)* fa* fb/ pow(pow(fa,2.)+ pow(fb,2.),0.5);
	      }


	    else if ( iNbInter == 4 )
	      {
		fa = MIN(fd1,fd3);
		fb = MIN(fd2,fd4);
		pfNewSDF[ix*iNy + iy] = SIGN(fPhi00)* fa* fb/ pow(pow(fa,2.)+ pow(fb,2.),0.5);
	      }

	  }

      }


  for(ix=1; ix< iNx-1; ix++)
    for(iy=1; iy< iNy-1; iy++) 
      {   
	if ( fabs(pfNewSDF[ix*iNy+ iy])< INF )
	  {

	    sNarBand.piFlagNarrowBand[ix*iNy+ iy] = 1;
	    vAddElement2NarrowBand(&sNarBand,pfNewSDF[ix*iNy+ iy],ix,iy);
	    piBurntPixels[ix*iNy+ iy] = 1;

	  }

      }



  while ( sNarBand.iLength > 0 )
    {

      /* Take the point in "narrowband" that has the smallest value */
      ix = sNarBand.pix[0]; 
      iy = sNarBand.piy[0];
     
      /* Add the point to "burnt" and remove it from "narrowband" */
      piBurntPixels[ix*iNy+ iy] = 1;
      vRemoveFirstElementOfNarrowBand(&sNarBand);
      sNarBand.piFlagNarrowBand[ix*iNy+ iy] = 0;

      for(ix2=ix-1; ix2<= ix+1; ix2++)
	for(iy2=iy-1; iy2<= iy+1; iy2++)
	  if ( ix2>0  &&  ix2<iNx-1  &&  iy2>0  &&  iy2<iNy-1 )
	    if ( piBurntPixels[ix2*iNy+ iy2] == 0 )
	      {

		if ( pfNewSDF[ix2*iNy+ iy2]> 0.0 )
		  {
		    fPhi1 = MIN(pfNewSDF[(ix2+1)*iNy+ iy2],pfNewSDF[(ix2-1)*iNy+ iy2]);
		    fPhi2 = MIN(pfNewSDF[ix2*iNy+ iy2+1],pfNewSDF[ix2*iNy+ iy2-1]);
		  }
		else
		  {
		    fPhi1 = MIN(fabs(pfNewSDF[(ix2+1)*iNy+ iy2]),fabs(pfNewSDF[(ix2-1)*iNy+ iy2]));
		    fPhi2 = MIN(fabs(pfNewSDF[ix2*iNy+ iy2+1]),fabs(pfNewSDF[ix2*iNy+ iy2-1]));
		  }

		if ( fabs(fPhi1- fPhi2) <= 1.0 )
		  if ( pfNewSDF[ix2*iNy+ iy2]> 0.0 )
		    pfNewSDF[ix2*iNy+ iy2] = 0.5* ( fPhi1+ fPhi2+ sqrt(2.0- pow(fPhi1- fPhi2,2.)) );
		  else
		    pfNewSDF[ix2*iNy+ iy2] = -0.5* ( fPhi1+ fPhi2+ sqrt(2.0- pow(fPhi1- fPhi2,2.)) );
		else 
		  if ( pfNewSDF[ix2*iNy+ iy2]> 0.0 )
		    pfNewSDF[ix2*iNy+ iy2] = MIN(fPhi1,fPhi2) + 1.0;
		  else
		    pfNewSDF[ix2*iNy+ iy2] = -MIN(fabs(fPhi1),fabs(fPhi2)) - 1.0;

		if ( fabs(pfNewSDF[ix2*iNy+ iy2]) <= fMaxDistanceComputations )
		  {

		    if ( sNarBand.piFlagNarrowBand[ix2*iNy+ iy2] == 0 )
		      {
			sNarBand.piFlagNarrowBand[ix2*iNy+ iy2] = 1;
			vAddElement2NarrowBand(&sNarBand,pfNewSDF[ix2*iNy+ iy2],ix2,iy2);
		      }
		    else
		      {
			vRemovePixelFromNarrowBand(&sNarBand,ix2,iy2);
			vAddElement2NarrowBand(&sNarBand,pfNewSDF[ix2*iNy+ iy2],ix2,iy2);
		      }

		  }


	      }
    
    }


  for(ix=0; ix< iNx; ix++)
    for(iy=0; iy< iNy; iy++) 
      if ( fabs(pfNewSDF[ix*iNy+ iy]) == INF )
	pfNewSDF[ix*iNy+ iy] = pfDistSDF[ix*iNy + iy];


  /* Neumann bondaries condition */
  for (ix=0; ix< iNx; ix++)
    {
      pfNewSDF[ix*iNy] = pfNewSDF[ix*iNy+ 1];
      pfNewSDF[ix*iNy+ iNy-1] = pfNewSDF[ix*iNy+ iNy-2];
    }
  for (iy=0; iy< iNy; iy++)
    {
      pfNewSDF[iy] = pfNewSDF[iNy+ iy];
      pfNewSDF[(iNx-1)*iNy+ iy] = pfNewSDF[(iNx-2)*iNy+ iy];
    }
	   


  /*****************************************************************/
  /* Free memory  */

  free((float*) sNarBand.pfPhiValue);
  free((int*)   sNarBand.pix); 
  free((int*)   sNarBand.piy); 
  free((int*)   sNarBand.piFlagNarrowBand); 
  free((int*)   piBurntPixels);

  /*****************************************************************/

  return(1);
 
}
/****************************************/


/****************************************/




/*********************************************************************************************/
/*********************************************************************************************/
extern void mexFunction(int iNbOut, mxArray *pmxOut[],
		 int iNbIn, const mxArray *pmxIn[])
{

  /* iNbOut: number of outputs
     pmxOut: array of pointers to output arguments */

  /* iNbIn: number of inputs
     pmxIn: array of pointers to input arguments */

  
   float   *pfDistSDF, *pfNewSDF, *pfTemp, *pfMaxDistanceComputations, fMaxDistanceComputations;
   int     iNbRows, iNbCols, iNx, iNy, ix, iy, i, iDim[3], iNdim;
   int     *piDisplay, iDisplay, iSignInsideZeroLS;
   time_t  start_time, end_time;


  start_time = clock();


  /* Get the initial signed distance function (SDF) */
  pfDistSDF = mxGetData(pmxIn[0]);
  iNbRows = mxGetM(pmxIn[0]);     /* number of rows */
  iNbCols = mxGetN(pmxIn[0]);     /* number of columns */
  iNx = iNbCols;                  /* = Nx */
  iNy = iNbRows;                  /* = Ny */


  /* Get the maximal distance of computations */
  pfMaxDistanceComputations = mxGetData(pmxIn[1]);
  fMaxDistanceComputations = *pfMaxDistanceComputations;



  iNdim = 2;
  iDim[0] = iNy;
  iDim[1] = iNx;
  
  pmxOut[0] = mxCreateNumericArray(iNdim,(const int*)iDim,mxSINGLE_CLASS,mxREAL);
  pfNewSDF = mxGetData(pmxOut[0]);


	
  if ( !iFM2D_SDF(pfDistSDF,pfNewSDF,iDim,fMaxDistanceComputations) )
    {
      mexPrintf("\n\nError in SDF_FM: return an Array with null elements\n");
      for (i=0; i< iDim[0]* iDim[1]; i++)  pfNewSDF[i] = 0.0;
    }
  else
    {
      end_time = clock();      
	  /*mexPrintf("\nReDist FM: Dist_extension=%.1f & Computing Time= %.5f sec\n\n",fMaxDistanceComputations,difftime(end_time,start_time)/1000);	*/
    }

}
/*********************************************************************************************/
/*********************************************************************************************/

/**************************************** End of file ****************************************/
