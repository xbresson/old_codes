



function pre_process_mnist

clear




% T: 60,000 data, trainingT:10,000 training data
% labels: the class for the 60,000 data, traininglabels: the class for the 10,000 training data




NN=60000;
m=zeros(28);
numbers=LoadMNistImages('numbers');
labels=LoadMNistLabels('labels');
A=zeros(NN,784);
for k=1:NN
    clear m    
    m(:,:)=numbers(k,:,:);
    m=double(m);
    v=reshape(real(m),prod(size(m)),1);
    A(k,:)=v;
end
clear numbers;


npc=50;

[B e Va mt]=pcp(A,npc,0);

clear A

for k=1:NN
    B(k,:)=B(k,:)/norm(B(k,:));
end

T=B;
clear B






NNT=10000;
testnumbers=LoadMNistImages('testnumbers');
traininglabels=LoadMNistLabels('testlabels');
At=zeros(NNT,784);
for k=1:NNT
    clear tm    
    tm(:,:)=testnumbers(k,:,:);
    v=reshape(real(tm),prod(size(tm)),1);
    At(k,:)=v;
end

At=At*Va(:,1:npc);

for k=1:NNT
    At(k,:)=At(k,:)/norm(At(k,:));
end

trainingT=At;
clear At







file = 'file_mnist.mat';
tic
save(file,'T','trainingT','labels','traininglabels');
toc






solution = labels;




figure(1); clf; s=3; A=T'; N=size(A); z=solution;
scatter(A(1,1:N(2)),A(2,1:N(2)),s*ones(1,N(2)),z,'o', 'filled'); title('ground truth');
axis off;




end









