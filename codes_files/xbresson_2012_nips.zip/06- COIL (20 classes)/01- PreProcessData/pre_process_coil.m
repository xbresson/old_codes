

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COIL20
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function pre_process_coil

clear




file = 'COIL20.mat';
load(file,'fea','gnd');



size(fea)
%pause


size(gnd)
%pause

length(unique(gnd))


T = fea;

labels = gnd;


K = length(unique(labels))
%pause

tN = size(T,1)



npc=5; % 53
npc=25; % 26
npc=50; % 26
%npc=10; % 36
%npc=100; % 26
[B e Va mt]=pcp(T,npc,0);
clear A
for k=1:size(T,1)
    B(k,:)=B(k,:)/norm(B(k,:));
end
T=B;
clear B



file = 'file_coil.mat';
save(file,'T','labels');






solution = labels;




figure(1); clf; s=3; A=T'; N=size(A); z=solution;
scatter(A(1,1:N(2)),A(2,1:N(2)),s*ones(1,N(2)),z,'o', 'filled'); title('ground truth');
axis off;




end









