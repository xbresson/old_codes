


function test_L1cheeger_usps










clear


file_solution = '../02- ComputeW/solution_usps.mat'; 
file_weight = '../02- ComputeW/weight_usps.mat'; 
file_computed_solution = 'computed_solution_usps.mat';


load(file_solution,'T','solution','K');
load(file_weight,'w');

Adisplay = T';
tN = size(w,1);

option_display_eigen = 2;
option_display_eigen = 1; % display data in basis of eigenvectors

size_point = 15;


save_operators_worig = 2;
save_operators_worig = 1;
file_operators_worig = 'operators_worig_usps.mat';


display = 1;
if display == 1
    figure(2); clf; s2=size_point; A=Adisplay; N=size(A);
    v=solution;
    scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o','filled');
    title('solution'); 
    pause(1)
    %pause
end


worig = w;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% D operator for difference of energies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if save_operators_worig==1
    
    tic
    
    tN = size(worig,2)
    
    w=triu(worig,1);
    [r c v]=find(w);
    n=length(r);
    Dr=[1:n 1:n];
    Dc(1:n)=r;
    Dc(n+1:2*n)=c;
    Dv(1:n)=v;
    Dv(n+1:2*n)=-v;
    D=sparse(Dr,Dc,Dv,n,tN);
    Dt=D';
    
    toc
    
    save(file_operators_worig,'D');
    
else
    
    load(file_operators_worig,'D');
    
end








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compare unsupervised learning algorithms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nbTests = 10;


errorOursTab = zeros(nbTests,1);
errorHeinTab = zeros(nbTests,1);
speedOursTab = zeros(nbTests,1);
speedHeinTab = zeros(nbTests,1);
cutOursTab = zeros(nbTests,1);
cutHeinTab = zeros(nbTests,1);




for kTest=1:nbTests
    
    
    kTest
    pause(1.5)
    
    
    
    
    
    [errorOurs speedOurs cutOurs] = clusteringL1Cheeger(tN,worig,Adisplay,option_display_eigen,size_point,solution,K,D);
    
    
    
    errorOurs
    speedOurs
    cutOurs
    pause(5)
    
    
    errorOursTab(kTest) = errorOurs;
    speedOursTab(kTest) = speedOurs;
    cutOursTab(kTest) = cutOurs;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % save results
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    file = 'results.mat';
    save(file,'errorOursTab','speedOursTab','cutOursTab');
    
    
    
end



mean_errorOursTab = mean(errorOursTab)
mean_speedOursTab = mean(speedOursTab)
mean_cutOursTab = mean(cutOursTab)



end



































%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% clusteringL1Cheeger
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [error speed cut] = clusteringL1Cheeger(tN,worig,Adisplay,option_display_eigen,size_point,solution,K,D)





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% recursive classification
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



mincent=ones(tN,1);
nc=1;
tNorig=size(worig,2);

split=1;
cr=0;
firstpass=1;

Tstart = tic;
while nc<K
    
    for j=1:nc
        
        if split(j)==1
            
            
            % extract sub-graph
            tid=find(mincent==j);
            ntid=setdiff([1:tNorig],tid);
            tN=length(tid);
            tw=worig(tid,tid);
            
            
            % lambda
            lambda=1;
            
            
            % compute cheeger cut
            bestcheegerEn = 1e10;
            bestC = zeros(tN,1);
            indexBestSolution = 0;
            
            
            % compute cheeger solution
            model_cheeger=0; NRandTests=1; % number of rand inits
            [bestC,bestcheegerEn,V] = computeCheegerSolution(tw,Adisplay(1:2,tid),option_display_eigen,size_point,NRandTests,lambda,model_cheeger);
            
            
            % compute cheeger solution with 2nd eigenvector as init
            model_cheeger=1; NRandTests=1;
            [bestC2ndInit,bestcheegerEn2ndInit,V] = computeCheegerSolution(tw,Adisplay(1:2,tid),option_display_eigen,size_point,NRandTests,lambda,model_cheeger);
            if bestcheegerEn>bestcheegerEn2ndInit
                bestcheegerEn=bestcheegerEn2ndInit;
                bestC=bestC2ndInit;
                indexBestSolution=1;
            end
            
            
            % compute cheeger solution with 2nd eigenvector
            model_cheeger=2;
            [bestC2nd,bestcheegerEn2nd,V] = computeCheegerSolution(tw,Adisplay(1:2,tid),option_display_eigen,size_point,NRandTests,lambda,model_cheeger);
            if bestcheegerEn>bestcheegerEn2nd
                bestcheegerEn=bestcheegerEn2nd;
                bestC=bestC2nd;
                indexBestSolution=2;
            end
            
            
            % show best solution
            if (indexBestSolution==0); title_image = 'Best cut given by RANDOM INIT';
            elseif (indexBestSolution==1); title_image = 'Best cut given by 2ND EIGENVECTOR AS INIT';
            elseif (indexBestSolution==2); title_image = 'Best cut given by 2ND EIGENVECTOR';
            end
            if (option_display_eigen==1); Adisplayt=V(:,2:4)'; else; Adisplayt=Adisplay(1:2,tid); end;
            figure(100); clf; s2=size_point; A=Adisplayt; N=size(A);
            v=bestC; scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o','filled'); colorbar;
            title([title_image, '\newline cut value=', num2str(bestcheegerEn), ...
                ' C1=',num2str(sum(bestC)),' / C2=',num2str(sum(1-bestC))]);
            pause(1)
            
            
            % compute difference of energies
            yid1=tid(find(bestC));
            nyid1=setdiff([1:tNorig],yid1);
            yid2=tid(find(1-bestC));
            nyid2=setdiff([1:tNorig],yid2);
            
            if firstpass~=1
                
                % symmetric
                u=zeros(tNorig,1); u(yid1)=1;
                cheegerEn11=sum(abs(D*u))/sum(sign_asymmetric(u,1).*u);
                u=zeros(tNorig,1); u(yid2)=1;
                cheegerEn12=sum(abs(D*u))/sum(sign_asymmetric(u,1).*u);
                u=zeros(tNorig,1); u(tid)=1;
                cheegerEn1=sum(abs(D*u))/sum(sign_asymmetric(u,1).*u);
                cr(j)= -cheegerEn1 + cheegerEn11+cheegerEn12;
                
            end
            
            kyid1{j}=yid1;
            kyid2{j}=yid2;
            split(j)=0;
            
        end
        
    end
    
    [ju juu]=min(cr);
    mincent(kyid2{juu})=nc+1;
    split(juu)=1;
    split(nc+1)=1;
    
    firstpass=0;
    
    nc=length(unique(mincent));
    
end
computational_time_sec = toc(Tstart)
computational_time_min = computational_time_sec/60
pause(1)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% misclassfication error
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% show result
figure(4); clf;
s2=3; A=Adisplay; N=size(A); v=mincent;
scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled');
title('clusters'); 


% confusion matrix
x = confma(mincent,solution) % solution in [0 1 ... K-1]
sumx = sum(sum(x))
for ki=1:K
    [ju juu]=max(x(ki,:));
    tx=x(ki,:);
    tx(juu)=0;
    ern(ki)=sum(tx);
end
tNorig=size(worig,2)
classification_error = sum(ern)+(tNorig-sumx)
classification_error_percentage = classification_error*100/tNorig


% energy value
EnCheeger=0;
for k=1:K
    u=zeros(tNorig,1); u(mincent==k)=1;
    cut=sum(abs(D*u));
    A=sum(u==1);
    Ac=sum(u==0);
    Enk=cut/min(A,Ac);
    EnCheeger = EnCheeger + Enk;
end

EnCheeger
    

error = classification_error_percentage;
speed = computational_time_sec;
cut = EnCheeger;



end



    





function [cheeger_solution,cheegerEn_solution,V] = computeCheegerSolution(worig,Adisplay,option_display_eigen,size_point,NRandTests,lambda,model_cheeger)





tic
tN = size(worig,2)

w=triu(worig,1);
[r c v]=find(w);
n=length(r);
Dr=[1:n 1:n];
Dc(1:n)=r;
Dc(n+1:2*n)=c;
Dv(1:n)=v;
Dv(n+1:2*n)=-v;
D=sparse(Dr,Dc,Dv,n,tN);
Dt=D';



wNormLaplac=dn(worig,'gph');
opts.disp=0;
[V E]=eigs(wNormLaplac,4,'LM',opts);
toc


if option_display_eigen == 1
    Adisplay = V(:,2:4)';
end




%%% parameters PD %%%
NormD = normest(D);
acceleration = 1; % no acceleration
acceleration = 2; % acceleration
if acceleration == 1
    % no acceleration
    ct=1; taun = ct/NormD; sigman = 1/ct/NormD;
    thetan=1;
else
    % acceleration
    ct=0.9; taun = ct/NormD; sigman = 1/ct/NormD;
    taunInit = taun; sigmanInit=sigman;
    gamma = 1e-3*4;
end

maxK = 10;
maxJ = 2000;

MaxdiffJ = 1e-10;
MaxdiffK = 1e-10;
MaxdiffC = 1e-2;
Maxdiffl = 1e-2;
MaxdiffC = -1;


% constant c
cGradFlow = 1;
cGradFlowInv = 1/cGradFlow;




if (model_cheeger==0) || (model_cheeger==1) % Asymmetric Cheeger
    
    
    
    %%%%%%%%%%%%%%%%%%%%%
    % test random inits
    %%%%%%%%%%%%%%%%%%%%%
    random_cheeger_value = 1e10;
    random_cheeger_C1 = zeros(tN,1);
    iRand=0; %NRandTests=10;
    while ( iRand<NRandTests )
        
        iRand=iRand+1;
        
        
        if model_cheeger==0
            
            
            title_image = 'Cheeger solution (RANDOM INIT)';
            
            
            % random init 1
            i=round(1+(tN-1)*rand);
            f1=-ones(tN,1); f1(i)=1;
            [r c v] = find(worig(i,:));
            n=length(r);
            for j=1:n; f1(c(j))=1; end;
            w=triu(worig,1);
            [r c v]=find(w);
            n=length(r);
            Dr=[1:n 1:n];
            Dc(1:n)=r;
            Dc(n+1:2*n)=c;
            Dv(1:n)=v;
            Dv(n+1:2*n)=-v;
            D=sparse(Dr,Dc,Dv,n,tN);
            Dt=D';
            r=1; md=@(x,type) r*x+1*r*(Dt*(D*x)); % 10-100
            [f1 flag]=pcg(md,f1,1e-6,50,[],[],f1); f1=f1-mean(f1); f1(f1>0)=1; f1(f1<=0)=0;
            
            
            
%             % random init 2
%             f1 = rand(tN,1);
%             f1(f1>=0.5)=1; f1(f1<0.5)=-1;
            
            
        elseif model_cheeger==1
            
            
            title_image = 'Cheeger solution (2ND EIGENVECTOR AS INIT)';
            
            
            % 2nd eigenvector init
            f1=squeeze(V(:,2)); f1=(f1-min(f1))/(max(f1)-min(f1)); f1=2*f1-1;
            
            
        end
        
        
        f1 = f1-asymMedian(f1,lambda); % lambda times more points in Omega than in Omega^c
        f1 = f1./ norm(f1);
        l1 = sum(abs(D*f1))/sum( sign_asymmetric(f1,lambda).*f1 )
        %pause
        
        
        
        
        tab_l = [];
        X = [];
        
        E1Prevk=l1; stopCond=-1;
        k=0;
        while ( k<3 || (k<maxK && stopCond<0 && abs(stopCond)>1e-3) )
            
            k=k+1;
            
            
            % v^{k+1}
            f1zero=find(f1==0);
            if length(f1zero)>0
                v1 = zeros(tN,1);
                v1(f1>0) = 1;
                v1(f1<0) = -lambda;
                n0 = length(f1zero);
                nm = sum(f1<0);
                np = sum(f1>0);
                v1(f1zero) = (lambda*nm-np)/n0;
            else
                disp('f1 has no zero element');
            end
            
            
            
            % g^{k+1}
            g1 = f1 + cGradFlow*v1;
            
            
            
            
            % h^{k+1} = argmin ||Dh||_1 - lambda^k/(2c)|h-g^{k+1}|^2
            if acceleration == 2  % acceleration
                taun = taunInit; sigman = sigmanInit;
            end
            d1 = D*g1;
            h1 = g1;
            ht1 = g1;
            h1Pre = g1;
            j=0; diffHj=1;
            %tic
            while ( j<15 || (j<maxJ && diffHj>MaxdiffJ) )
                
                j=j+1;
                
                % new d^{j+1}
                d1 = d1 + sigman* D*ht1;
                d1 = d1./max(1,abs(d1));
                
                % new h^{j+1}
                h1Pre = h1;
                h1 = h1 - taun*Dt*d1 + taun*cGradFlowInv*l1*g1;
                h1 = h1./(1+taun*cGradFlowInv*l1);
                
                % acceleration
                if acceleration == 2
                    % new theta, tau, sigma
                    thetan = 1/sqrt(1+2*gamma*taun);
                    taun = taun* thetan;
                    sigman = sigman/ thetan;
                end
                
                % new ht^{j+1}
                ht1 = h1 + thetan* (h1-h1Pre);
                
                % stopping condition
                diffHj = sum(abs((h1-h1Pre)))/tN;
                h1Pre = h1;
                
            end
            %toc
            
            
            % h^{k+1}
            h1 = h1 - asymMedian(h1,lambda);
            
            
            % f^{k+1}
            f1 = h1./ sqrt(sum(h1.^2));
            
            
            % l^{k+1} = ||Df^{k+1}||_1 / ||f^{k+1}||_1
            l1 = sum(abs(D*f1))/sum( sign_asymmetric(f1,lambda).*f1 )
            
            
            
           
            
            stopCond = l1-E1Prevk;
            E1Prevk=l1;
            
            
            if k>=2
                if stopCond>0
                    f1=f1Prevk;
                else
                    f1Prevk=f1;
                end
            else
                f1Prevk=f1;
            end
            
            
            
            k
            j
            diffHj
            stopCond
            %stopCond=-1
            
            
            
            if k>=1
                X = [X; k;];
                tab_l = [tab_l l1];
            end
            
            
            
        end
        
        
        
        
        % thresholding with energy
        %tic
        Nthresh=1000;
        u=f1; rangeu = max(u)-min(u); deltarangeu = rangeu/Nthresh;
        thresh=linspace(min(u)+deltarangeu,max(u)-deltarangeu,Nthresh);
        cheegerEn = zeros(Nthresh,1);
        for s=1:Nthresh;
            uthresh=zeros(size(f1)); uthresh(f1>thresh(s))=1;
            uthresh = uthresh-asymMedian(uthresh,lambda);
            cheegerEn(s)=sum(abs(D*uthresh))/sum(sign_asymmetric(uthresh,lambda).*uthresh);
        end
        %toc
        %pause
        [bestThresh sbestThresh]=min(cheegerEn);
        C=double(f1>thresh(sbestThresh)); C1=C;
        
        
        
        sizeC1 = sum(C1);
        sizeC2 = sum(1-C1);
        

        
        
        
        figure(1000); clf;
        plot(X,tab_l); title(['Cheeger energy w.r.t. iterations'] );
        
        
        figure(1001); clf; s2=size_point; A=Adisplay; N=size(A);
        subplot(121);
        v=f1; scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o','filled'); colorbar;
        title(['k= ',num2str(k), ' / l1=', num2str(l1), ' / diffEn(k)=', num2str(stopCond) ]);
        %set(gca,'DataAspectRatio',[1 1 1]);
        subplot(122);
        v=C1; scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o','filled'); colorbar;
        title(['k= ',num2str(k), ...
            ' / bestThresh=', num2str(bestThresh), ' \newline C1=',num2str(sizeC1),' / C2=',num2str(sizeC2)]);
        %set(gca,'DataAspectRatio',[1 1 1]);
        %pause
        
        
        pause(0.2)
        %pause
        
        
        
        
        
        if bestThresh<random_cheeger_value
            random_cheeger_value=bestThresh;
            random_cheeger_C1=C1;
            
            %%%%%%
            %iRand=NRandTests;
            %%%%%%
            
        end
        
        
    end
    
    
    
    
    
    cheeger_solution = random_cheeger_C1;
    cheegerEn_solution = random_cheeger_value;
    
    
    
    
elseif model_cheeger==2
    
    title_image = 'Cheeger solution (2ND EIGENVECTOR)';
    
    % 2nd eigenvector init
    f1=squeeze(V(:,2)); f1=(f1-min(f1))/(max(f1)-min(f1)); f1=2*f1-1;
    
    
    % thresholding with energy
    %tic
    Nthresh=1000;
    u=f1; rangeu = max(u)-min(u); deltarangeu = rangeu/Nthresh;
    thresh=linspace(min(u)+deltarangeu,max(u)-deltarangeu,Nthresh);
    cheegerEn = zeros(Nthresh,1);
    for s=1:Nthresh;
        uthresh=zeros(size(f1)); uthresh(f1>thresh(s))=1;
        uthresh = uthresh-asymMedian(uthresh,lambda);
        cheegerEn(s)=sum(abs(D*uthresh))/sum(sign_asymmetric(uthresh,lambda).*uthresh);
    end
    %toc
    %pause
    [bestThresh sbestThresh]=min(cheegerEn);
    C=double(f1>thresh(sbestThresh)); C1=C;
    
    
    cheeger_solution = C1;
    cheegerEn_solution = bestThresh;
    
    
end




figure(1004); clf; s2=3; A=Adisplay; N=size(A);
v=cheeger_solution; scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o', 'filled'); colorbar;
title(title_image);
pause(1)


end



















function s=sign_asymmetric(u,lambda)

s = zeros(size(u));
s(u>0) = 1;
s(u<0) = -lambda;

end



    
    

function amedian = asymMedian(u,lambda)

us=sort(u,'ascend');
tN=size(u,1);
amedian = us(ceil(tN/(1+lambda)));

end


