


function test_L1cheeger_two_moons








option_display_eigen = 2;
%option_display_eigen = 1;

size_point = 15;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MOONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 2 moons
tN=2000;
sig=.02;
dim=100;
solution(1:tN/2)=0;
solution(tN/2+1:tN)=1;
x=linspace(0,pi,tN/2)';
T=[cos(x) sin(x)];
T=cat(1,T,[cos(x)+1 0.5-sin(x)]);
T(:,3:dim)=0;
T=T+sqrt(sig)*randn(tN,dim);
solution = zeros(tN,1);
solution(1:tN/2,1) = 1;
lambda = 1;


Adisplay = T';



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construct the graph of data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% parameters no ZP
opts.kNN=5;
opts.kNNdelta=opts.kNN;
opts.alpha=1;

tN = size(T,1)
number_zz = tN/2000

tic
fprintf('building weights... \n');
[w]=fgf1(T,opts);
toc

tN = size(w,2)
worig = w;



% file_data = 'data_twomoons.mat';
% save(file_data,'T','w','solution','tN','Adisplay','lambda');

    


file_data = 'data_twomoons.mat';
load(file_data,'T','w','solution','tN','Adisplay','lambda');

    

worig = w;


    




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test unsupervised learning algorithms
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


nbTests = 10;



errorOursTab = zeros(nbTests,1);
speedOursTab = zeros(nbTests,1);
cutOursTab = zeros(nbTests,1);






for kTest=1:nbTests
    
    
    kTest
    pause(1.5)
    
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % initial function
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
            
            % random init 1
            i=round(1+(tN-1)*rand);
            f1=-ones(tN,1); f1(i)=1;
            [r c v] = find(worig(i,:));
            n=length(r);
            for j=1:n; f1(c(j))=1; end;
            w=triu(worig,1);
            [r c v]=find(w);
            n=length(r);
            Dr=[1:n 1:n];
            Dc(1:n)=r;
            Dc(n+1:2*n)=c;
            Dv(1:n)=v;
            Dv(n+1:2*n)=-v;
            D=sparse(Dr,Dc,Dv,n,tN);
            Dt=D';
            r=1; md=@(x,type) r*x+1*r*(Dt*(D*x)); % 10-100
            [f1 flag]=pcg(md,f1,1e-6,50,[],[],f1); f1=f1-mean(f1); f1(f1>0)=1; f1(f1<=0)=0;
            
                        
%             % random init 2
%             f1 = rand(tN,1);
%             f1(f1>=0.5)=1; f1(f1<0.5)=-1;
            
            
    

    file = 'init_twomoons.mat';
    save(file,'f1');
    
    
    file = 'init_twomoons.mat';
    load(file,'f1');
    
    
    
    display = 2;
    if display == 1
        figure(2); clf; s2=size_point; A=Adisplay; N=size(A);
        v=solution;
        scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o','filled');
        title('solution');
        figure(3); clf; s2=size_point; A=Adisplay; N=size(A);
        v=f1;
        scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o','filled');
        title('init');
        pause(1)
        pause
    end
    
    
    
    
    tolROF = 1e-10;
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % clustering algo
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [errorOurs speedOurs cutOurs] = clusteringL1Cheeger(worig,T,solution,Adisplay,size_point,lambda,f1,tolROF,option_display_eigen);
    
    
    
    
    errorOurs
    speedOurs
    cutOurs
    
    
    errorOursTab(kTest) = errorOurs;
    speedOursTab(kTest) = speedOurs;
    cutOursTab(kTest) = cutOurs;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % save results
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    file = 'results.mat';
    save(file,'errorOursTab','speedOursTab','cutOursTab');
    
    
    
end



mean_errorOursTab = mean(errorOursTab)
mean_speedOursTab = mean(speedOursTab)
mean_cutOursTab = mean(cutOursTab)



end
































%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% clustering algo
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [error speed cut] = clusteringL1Cheeger(worig,T,solution,Adisplay,size_point,lambda,f1_init,tolROF,option_display_eigen)




tic
tN = size(worig,2)

w=triu(worig,1);
[r c v]=find(w);
n=length(r);
Dr=[1:n 1:n];
Dc(1:n)=r;
Dc(n+1:2*n)=c;
Dv(1:n)=v;
Dv(n+1:2*n)=-v;
D=sparse(Dr,Dc,Dv,n,tN);
Dt=D';
toc


wNormLaplac=dn(worig,'gph');
opts.disp=0;
[V E]=eigs(wNormLaplac,4,'LM',opts);
toc



if option_display_eigen == 1
    Adisplay = V(:,2:4)';
end




%%% parameters PD %%%
NormD = normest(D);
acceleration = 1; % no acceleration
acceleration = 2; % acceleration
if acceleration == 1
    % no acceleration
    ct=1; taun = ct/NormD; sigman = 1/ct/NormD;
    thetan=1;
else
    % acceleration
    ct=0.9; taun = ct/NormD; sigman = 1/ct/NormD;
    taunInit = taun; sigmanInit=sigman;
    gamma = 1e-3*4;
end

maxK = 20;
maxJ = 2000; %

MaxdiffJ = tolROF;

MaxdiffK = 1e-10;
MaxdiffC = 1e-2;
Maxdiffl = 1e-2;
MaxdiffC = -1;


% constant c
cGradFlow = 1;
cGradFlowInv = 1/cGradFlow;



f1 = f1_init;
f1 = f1-asymMedian(f1,lambda); % lambda times more points in Omega than in Omega^c
f1 = f1./ norm(f1);
l1 = sum(abs(D*f1))/sum( sign_asymmetric(f1,lambda).*f1 )
%pause




tab_l = [];
X = [];

E1Prevk=l1; stopCond=-1;
k=0;
Tstart = tic;
while ( k<3 || (k<maxK && stopCond<0 && abs(stopCond)>1e-3) )
    
    k=k+1;
    
    
    
    
    % v^{k+1}
    f1zero=find(f1==0);
    if length(f1zero)>0
        v1 = zeros(tN,1);
        v1(f1>0) = 1;
        v1(f1<0) = -lambda;
        n0 = length(f1zero);
        nm = sum(f1<0);
        np = sum(f1>0);
        v1(f1zero) = (lambda*nm-np)/n0;
    else
        disp('f1 has no zero element');
    end
    
    
    
    % g^{k+1}
    g1 = f1 + cGradFlow*v1;
    
    
    
    % h^{k+1} = argmin ||Dh||_1 - lambda^k/(2c)|h-g^{k+1}|^2
    if acceleration == 2  % acceleration
        taun = taunInit; sigman = sigmanInit;
    end
    d1 = D*g1;
    h1 = g1;
    ht1 = g1;
    h1Pre = g1;
    j=0; diffHj=1;
    %tic
    while ( j<15 || (j<maxJ && diffHj>MaxdiffJ) )
        
        j=j+1;
        
        % new d^{j+1}
        d1 = d1 + sigman* D*ht1;
        d1 = d1./max(1,abs(d1));
        
        % new h^{j+1}
        h1Pre = h1;
        h1 = h1 - taun*Dt*d1 + taun*cGradFlowInv*l1*g1;
        h1 = h1./(1+taun*cGradFlowInv*l1);
        
        % acceleration
        if acceleration == 2
            % new theta, tau, sigma
            thetan = 1/sqrt(1+2*gamma*taun);
            taun = taun* thetan;
            sigman = sigman/ thetan;
        end
        
        % new ht^{j+1}
        ht1 = h1 + thetan* (h1-h1Pre);
        
        % stopping condition
        %diffHj = sum(sum((h1-h1Pre).^2))/tN;
        diffHj = sum(abs((h1-h1Pre)))/tN;
        h1Pre = h1;
        
    end
    %toc
    
    
    % h^{k+1}
    h1 = h1 - asymMedian(h1,lambda);
    
    
    % f^{k+1}
    f1 = h1./ sqrt(sum(h1.^2));
    
    
    % l^{k+1} = ||Df^{k+1}||_1 / ||f^{k+1}||_1
    l1 = sum(abs(D*f1))/sum( sign_asymmetric(f1,lambda).*f1 )
    
    
    
    
    
    
    stopCond = l1-E1Prevk;
    E1Prevk=l1;
    
    
    if k>=2
        if stopCond>0
            f1=f1Prevk;
        else
            f1Prevk=f1;
        end
    else
        f1Prevk=f1;
    end
    
    
    k
    j
    diffHj
    stopCond
    %stopCond=-1
    %pause
    
    
    
    if k>=1
        X = [X; k;];
        tab_l = [tab_l l1];
    end
    
    
    
end
computational_time_sec = toc(Tstart)





% thresholding with energy
%tic
Nthresh=1000;
u=f1; rangeu = max(u)-min(u); deltarangeu = rangeu/Nthresh;
thresh=linspace(min(u)+deltarangeu,max(u)-deltarangeu,Nthresh);
cheegerEn = zeros(Nthresh,1);
for s=1:Nthresh;
    uthresh=zeros(size(f1)); uthresh(f1>thresh(s))=1;
    uthresh = uthresh-asymMedian(uthresh,lambda);
    cheegerEn(s)=sum(abs(D*uthresh))/sum(sign_asymmetric(uthresh,lambda).*uthresh);
end
%toc
%pause
[bestThresh sbestThresh]=min(cheegerEn);
C=double(f1>thresh(sbestThresh)); C1=C;



sizeC1 = sum(C1);
sizeC2 = sum(1-C1);




figure(1000); clf;
plot(X,tab_l); title(['Energy w.r.t. iterations (OURS)'] );


figure(1001); clf; s2=size_point; A=Adisplay; N=size(A);
subplot(121);
v=f1; scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o','filled'); colorbar;
title(['u1(k)= ',num2str(k), ' / l1=', num2str(l1), ' / diffEn(k)=', num2str(stopCond) ]);
%set(gca,'DataAspectRatio',[1 1 1]);
subplot(122);
v=C1; scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o','filled'); colorbar;
title(['k= ',num2str(k), ...
    ' / bestThresh=', num2str(bestThresh), ' \newline C1=',num2str(sizeC1),' / C2=',num2str(sizeC2)]);
%set(gca,'DataAspectRatio',[1 1 1]);
%pause


pause(0.2)
%pause






% confusion matrix
mincent = C1;
K = lambda+1;
x = confma(mincent,solution) % solution in [0 1 ...]
sumx = sum(sum(x))
for ki=1:K
    [ju juu]=max(x(ki,:));
    tx=x(ki,:);
    tx(juu)=0;
    ern(ki)=sum(tx);
end
tNorig=size(worig,2);
classification_error = sum(ern)+(tNorig-sumx)
classification_error_percentage = classification_error*100/tNorig




speed = computational_time_sec;
cut = bestThresh;
error = classification_error_percentage;


bestC=C1;
bestcheegerEn = bestThresh;

title_image = 'Result';
figure(100); clf; s2=size_point; A=Adisplay(1:2,:); N=size(A);
v=bestC; scatter(A(1,1:N(2)),A(2,1:N(2)),s2*ones(1,N(2)),v,'o','filled'); colorbar;
title([title_image, '\newline cut value=', num2str(bestcheegerEn), ...
    ' C1=',num2str(sum(bestC)),' / C2=',num2str(sum(1-bestC))]);
pause(1)





end



    





function s=sign_asymmetric(u,lambda)

s = zeros(size(u));
s(u>0) = 1;
s(u<0) = -lambda;

end



    
    

function amedian = asymMedian(u,lambda)

us=sort(u,'ascend');
tN=size(u,1);
amedian = us(ceil(tN/(1+lambda)));

end
























    
